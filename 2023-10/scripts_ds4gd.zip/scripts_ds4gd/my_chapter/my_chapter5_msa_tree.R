#' ---
#' title: "Little Book of R for Bioinformatics"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---

# clear the decks
rm(list = ls())

# load the packages
#+ warning = FALSE
#+ message = FALSE
library(seqinr)
library(Biostrings)
library(msa)
library(microseq)
library(ape)

#' ## [多重整列と系統樹](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#multiple-alignment-and-phylogenetic-trees)
#' ## [Multiple Alignment and Phylogenetic trees](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html)
#' **多重整列と系統樹**
#' 
#' ![https://bioinf.comav.upv.es/courses/biotech3/theory/phylogeny.html](https://bioinf.comav.upv.es/courses/biotech3/static/phylogeny/phylo_msa.png)
#' 
#' ### [Retrieving a list of sequences from UniProt](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#retrieving-a-list-of-sequences-from-uniprot)
#' **UniProtから複数の配列を取得**
#' 
#' [狂犬病ウイルス](https://ja.wikipedia.org/wiki/狂犬病ウイルス) Rabies virus, Mokola virus, Lagos bat virus, West Caucasian bat virus の 
#' Phosphoprotein のタンパク質配列（UniProt accession: 
#' [P06747](http://www.uniprot.org/uniprot/P06747), 
#' [P0C569](http://www.uniprot.org/uniprot/P0C569), 
#' [O56773](http://www.uniprot.org/uniprot/O56773), 
#' [Q5VKP1](http://www.uniprot.org/uniprot/Q5VKP1)）を取得し、FASTA形式で保存する:  

# create a function to retrieve several sequences from UniProt
read.fasta.uniprot <- function(ACCESSION) seqinr::read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]

seqnames <- c("P06747", "P0C569", "O56773", "Q5VKP1") # Make a vector containing the names of the sequences
seqs <- lapply(seqnames, read.fasta.uniprot) # Retrieve the sequences and store them in list variable "seqs"
length(seqs)      # Print out the number of sequences retrieved
seq1 <- seqs[[1]] # Get the 1st sequence
seq1[1:20]        # Print out the first 20 letters of the 1st sequence
seq2 <- seqs[[2]] # Get the 2nd sequence
seq2[1:20]        # Print out the first 20 letters of the 2nd sequence

# write out the sequences to a FASTA file
write.fasta(sequences=seqs, names=seqnames, file.out="mySeq.fasta")

#' ### [Creating a multiple alignment of protein, DNA or mRNA sequences using CLUSTAL](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#creating-a-multiple-alignment-of-protein-dna-or-mrna-sequences-using-clustal)
#' **CLUSTALを用いたタンパク質/DNA/mRNA配列の多重アラインメントの作成**

#library(Biostrings)
# Read an XStringSet object from a file
myAAStringSet <- readAAStringSet(file = "mySeq.fasta")

#library(msa)
# Multiple Sequence Alignment using ClustalW
myMsaAAMultipleAlignment <- msa(inputSeqs=myAAStringSet, method="ClustalW")
myMsaAAMultipleAlignment

# write an XStringSet object to a file
writeXStringSet(x = unmasked(myMsaAAMultipleAlignment), filepath = "myAln.fasta")

#' ### [Viewing a long multiple alignment](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#viewing-a-long-multiple-alignment)
#' **多重アラインメントの表示**

print(myMsaAAMultipleAlignment, show="complete")

#' ### [Reading a multiple alignment file into R](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#reading-a-multiple-alignment-file-into-r)
#' **多重アラインメントのファイルをRに読み込む**

myAln <- seqinr::read.alignment(file = "myAln.fasta", format = "fasta")
names(myAln)
unlist(myAln$seq)

#' ### [Discarding very poorly conserved regions from an alignment](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#discarding-very-poorly-conserved-regions-from-an-alignment)
#' **アラインメントから保存度の低い領域を破棄する**
#' 
#' Trimming a multiple sequence alignment by discarding columns with too many gaps.
#' 
#' 多重配列アラインメントからギャップの多い列を破棄する

#library(microseq)
msa.untrimmed <- readFasta(in.file = "myAln.fasta")
print(nchar(msa.untrimmed$Sequence))
msa.trimmed <- msaTrim(msa = msa.untrimmed, gap.end = 0.5, gap.mid = 0.9)
print(nchar(msa.trimmed$Sequence))
writeFasta(fdta = msa.trimmed, out.file = "myAlnTrim.fasta", width = 80)
#myAln <- seqinr::read.alignment(file = "myAlnTrim.fasta", format = "fasta")

#' ### [Calculating genetic distances between protein sequences](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#calculating-genetic-distances-between-protein-sequences)
#' **タンパク質配列間の遺伝的距離を計算する**

mydist <- seqinr::dist.alignment(x = myAln, matrix = "similarity") # Calculate the genetic distances
mydist # Print out the genetic distance matrix

#' The genetic distance between O56773 and P0C569 is the smallest (about 0.414).  
#' The genetic distance between Q5VKP1 and O56773 is the biggest (about 0.507).  
#' 遺伝的距離は、"O56773"と"P0C569"との間で最小（0.4142670）、"Q5VKP1"と"O56773"との間で最大（0.5067117）。
#' 
#' ### [Building an unrooted phylogenetic tree for protein sequences](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#building-an-unrooted-phylogenetic-tree-for-protein-sequences)
#' **タンパク質配列の無根系統樹の構築**
#' 
#' 距離行列に基づいて、[近隣結合法 NJ (Neighbor-Joining)](https://ja.wikipedia.org/wiki/近隣結合法) により系統樹を構築する。  
#' 系統樹で、"O56773"と"P0C569"が群を形成し、"Q5VKP1"と"P06747"が群を形成した。  
#' In the tree, Q5VKP1 and P06747 are grouped together, and O56773 and P0C569 are grouped together.
#' 
#library(ape)
# construct a phylogenetic tree with the neighbor joining algorithm
mytree <- nj(mydist)
# plot the tree:
plot.phylo(mytree, type="unrooted")
unlist(getAnnot(seqs)) # get sequence annotations

#' ### [Building a rooted phylogenetic tree for protein sequences](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#building-a-rooted-phylogenetic-tree-for-protein-sequences)
#' **タンパク質配列の有根系統樹の構築**
#' 
#' To convert the unrooted tree into a rooted tree, we need to add an outgroup sequence. 
#' The outgroup sequence is a sequence that we know from some prior knowledge to be 
#' more distantly related to the other sequences under study than they are to each other.
#' 
#' The Zika virus is related to Dengue viruses, but is not a Dengue virus, and so therefore 
#' can be used as an outgroup in phylogenetic trees of Dengue virus sequences.
#' Build a rooted phylogenetic tree of the Dengue NS1 proteins, 
#' using the Zika virus protein as the outgroup.
#' 
#' フラビウイルス属に属するジカウイルス (Zika virus) とデングウイルス (Dengue virus) 
#' の非構造タンパク質 (Nonstructural protein 1; NS1) の相同タンパク質配列を取得し、
#' 多重配列アラインメントに基づく有根系統樹を構築する。
#' [外群](https://ja.wikipedia.org/wiki/外群)としてジカウイルスを選択し、系統樹に根をつける。
#' 
# retrieve several sequences from UniProt
# Make a vector containing the names of the sequences
myIngroup <- c("Q9YRR4", "Q9YP96", "B0LSS3", "Q6TFL5") # Dengue virus
myOutgroup <- c("Q32ZE1") # Zika virus
seqnames <- c(myIngroup, myOutgroup)
seqnames

# Retrieve the sequences and store them in list variable "seqs"
seqs <- lapply(seqnames, read.fasta.uniprot)

getLength(seqs) # get the length of sequences
unlist(getAnnot(seqs)) # get sequence annotations

# write out the sequences to a FASTA file
write.fasta(sequences=seqs, names=seqnames, file.out="mySeq.fasta")

# Read an XStringSet object from a file
myAAStringSet <- readAAStringSet(file = "mySeq.fasta")

# Multiple Sequence Alignment using ClustalW
myMsaAAMultipleAlignment <- msa(inputSeqs=myAAStringSet, method="ClustalW")
myMsaAAMultipleAlignment

# write an XStringSet object to a file
writeXStringSet(x = unmasked(myMsaAAMultipleAlignment), filepath = "myAln.fasta")

# Trimming a multiple sequence alignment by discarding columns with too many gaps.
msa <- readFasta(in.file = "myAln.fasta")
print(nchar(msa$Sequence))
msa.trimmed <- msaTrim(msa, gap.end = 0.3, gap.mid = 0.9)
print(nchar(msa.trimmed$Sequence))
writeFasta(fdta = msa.trimmed, out.file = "myAlnTrim.fasta", width = 80)

# read the FASTA-format alignment into R
myAln <- read.alignment(file = "myAlnTrim.fasta", format = "fasta")
unlist(myAln$seq)

# Calculating pairwise distances from aligned sequences
mydist <- dist.alignment(x = myAln, matrix = "similarity") # Calculate the genetic distance matrix
mydist # Print out the genetic distance matrix

# construct a phylogenetic tree with the neighbor joining algorithm
mytree <- nj(mydist) # infer a tree
mytree <- root(phy=mytree, outgroup=myOutgroup) # roots the tree
plot.phylo(mytree, type="phylogram") # plot the tree

#' ### [Saving a phylogenetic tree as a Newick-format tree file](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#saving-a-phylogenetic-tree-as-a-newick-format-tree-file)
#' **系統樹をNewick形式ファイルとして保存する**

write.tree(phy = mytree, file = "myNJ.tre")

#' ### [Calculating genetic distances between DNA/mRNA sequences](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#calculating-genetic-distances-between-dna-mrna-sequences)
#' **DNA/mRNA配列間の遺伝的距離を計算する**
#' 
#' Duvenhage virus, Mokola virus, Lagos bat virus v006株, Lagos bat virus V267株 の Phosphoprotein の mRNA配列（NCBI accession: 
#' [AF049115](https://www.ncbi.nlm.nih.gov/nuccore/AF049115), 
#' [AF049118](https://www.ncbi.nlm.nih.gov/nuccore/AF049118), 
#' [AF049114](https://www.ncbi.nlm.nih.gov/nuccore/AF049114), 
#' [AF049119](https://www.ncbi.nlm.nih.gov/nuccore/AF049119)）を取得し、FASTA形式で保存する:  
#' 
# create a function to retrieve several nucleotide sequences from NCBI
read.fasta.ncbi_nuccore <- function(ACCESSION) seqinr::read.fasta(file = paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text"), seqtype="DNA", strip.desc=TRUE)[[1]]

# retrieve several nucleotide sequences from NCBI
seqnames <- c("AF049115", "AF049118", "AF049114", "AF049119") # Make a vector containing the names of the sequences
seqs <- lapply(seqnames, read.fasta.ncbi_nuccore) # Retrieve the sequences and store them in list variable "seqs"

# write out the sequences to a FASTA-format file
write.fasta(seqs, seqnames, file="mySeqNT.fasta")

# Read an XStringSet object from a file
myDNAStringSet <- readDNAStringSet(file = "mySeqNT.fasta")

# Multiple Sequence Alignment using ClustalW
myMsaDNAMultipleAlignment <- msa(myDNAStringSet)
myMsaDNAMultipleAlignment

# convert msa for the seqinr package
seqinr_alignment <- msaConvert(myMsaDNAMultipleAlignment, type="seqinr::alignment")

# calculate a genetic distance for DNA/mRNA sequences
myDNAbin <- as.DNAbin(seqinr_alignment)   # Convert the alignment to "DNAbin" format
mydist <- dist.dna(myDNAbin, model="K80") # Calculate the genetic distance matrix
mydist                                    # Print out the genetic distance matrix

#' ### [Building a phylogenetic tree for DNA or mRNA sequences](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#building-a-phylogenetic-tree-for-dna-or-mrna-sequences)
#' **DNA/mRNA配列の系統樹の構築**

# construct a phylogenetic tree with the neighbor joining algorithm
mytree <- nj(mydist) # infer a tree
plot.phylo(mytree, type="unrooted") # plot the tree
unlist(getAnnot(seqs)) # get sequence annotations

#' ### [Summary](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#summary)
#' 
#' ### [Links and Further Reading](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#links-and-further-reading)
#' 
#' ### [Exercises](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#exercises)
#' **演習**
#' [回答例](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#multiple-alignment-and-phylogenetic-trees)
#'  
sessionInfo()
