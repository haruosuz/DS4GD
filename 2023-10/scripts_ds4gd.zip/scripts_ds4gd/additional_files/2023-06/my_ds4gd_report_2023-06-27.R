#' ---
#' title: "My report `r Sys.Date()`"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

# clear the decks
rm(list = ls())

# load the packages
#+ warning = FALSE
#+ message = FALSE
library(seqinr)
library(zoo)
library(Biostrings)
library(msa)
library(ape)
library(microseq)

#' - https://r-pkgs.org/namespace.html
?count
?dplyr::count
?seqinr::count

?translate
?microseq::translate
?Biostrings::translate
?seqinr::translate

?as.alignment
?seqinr::as.alignment
?ape::as.alignment

#' # [Little Book of R for Bioinformatics](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan)
#' ## 1. DNA Sequence Statistics (1)
#source("my_assignment_chapter1_dna1.R")

#' http://www.ncbi.nlm.nih.gov/genome/browse/
#' 
#' Download the DNA sequence of your genome of interest. 
#' Answer the following questions. 
#' For each question, please record your answer, and what you typed to get this answer.

# Retrieving a DNA sequence from NCBI
ACCESSION <- "NC_000908" # Mycoplasma genitalium G37
ACCESSION <- "NC_001477" # Dengue virus 1
ACCESSION <- "NC_045512" # SARS-CoV-2
ACCESSION <- "NC_001318" # Borreliella burgdorferi B31 chromosome
filename <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text")
#filename <- paste0("http://togows.org/entry/nucleotide/",ACCESSION,".fasta")

seqs <- read.fasta(file=filename, seqtype="DNA", strip.desc=TRUE)
#write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=paste0(ACCESSION,".fasta") )

seq1 <- seqs[[1]]
getLength(seq1) # get the length of sequences
getAnnot(seq1) # get sequence annotations

#' ### 1-1. 
#' What are the last 30 nucleotides of the genome sequence?

tail(seq1, 30)

#' ### 1-2. 
#' What is the length in nucleotides of the genome sequence?

length(seq1)

#' ### 1-3. 
#' How many of each of the four nucleotides A, C, T and G, 
#' and any other symbols, are there in the genome sequence?

table(seq1)

#' [Borreliella burgdorferi B31](https://www.ncbi.nlm.nih.gov/genome/738?genome_assembly_id=168382)
#' chromosome does contain non-A/C/G/T nucleotides.
#' 
#' DDBJ 
#' [Codes Used in Sequence Description](https://www.ddbj.nig.ac.jp/ddbj/code-e.html)
#' [配列の記載に用いる略号](https://www.ddbj.nig.ac.jp/ddbj/code.html)
#' 
#' ### 1-4. 
#' What is the GC content of the genome sequence, when 
#' (i) all non-A/C/T/G nucleotides are included, 
#' (ii) non-A/C/T/G nucleotides are discarded?
#help("GC")
GC(seq1)
GC(seq1, exact=FALSE)
GC(seq1, exact=TRUE)

#' ### 1-5. 
#' How many of each of the four nucleotides A, C, T and G 
#' are there in the complement of the genome sequence?

#help.search("complement")
#help("comp")
table(comp(seq1))

#' ### 1-6. 
#' How many occurrences of the DNA words CC, CG and GC occur in the genome sequence?

#count(seq=seq1, wordsize=2)
seqinr::count(seq=seq1, wordsize=2)
  
#' ### 1-7. 
#' How many occurrences of the DNA words CC, CG and GC occur in the 
#' (i) first 1000 and (ii) last 1000 nucleotides of the genome sequence?
#' How can you check that the subsequence that you have looked at is 1000 nucleotides long?

seqinr::count(seq=head(seq1, 1000), wordsize=2)
seqinr::count(seq=tail(seq1, 1000), wordsize=2)

#' ## 2. DNA Sequence Statistics (2)
#source("my_assignment_chapter2_dna2.R")

#' ### 2-1. 
#' Write a function to calculate the AT content of a DNA sequence 
#' (ie. the fraction of the nucleotides in the sequence that are As or Ts). 
#' What is the AT content of the genome?

# Here is a function to calculate the AT content of a genome sequence:
AT <- function(x){ library("seqinr"); 1 - GC(x) }

# use the function to calculate the AT content of the genome:
AT(seq1)

# AT = 1 - GC, ie. (AT + GC = 1):
GC(seq1)
AT(seq1) + GC(seq1)

#' ### 2-2. 
#' Draw a sliding window plot of GC content in the genome sequence, 
#' using different window sizes; e.g. 500, 1000, 5000, 10000 nucleotides. 
#' Do you see any regions of unusual DNA content in the genome (eg. a high peak or low trough)?

# write a function to make a sliding window plot:
slidingwindowplotGC <- function(windowsize, inputseq)
{
  # this function requires the 'zoo' R package #install.packages("zoo")
  require("zoo")
  x <- seq(from = 1, to = length(inputseq)-windowsize, by = windowsize)
  y <- rollapply(data = inputseq, width = windowsize, by = windowsize, FUN = GC)
  plot(x, y, type="l", xlab="Position (bp)", ylab="GC content")
}

# make a sliding window plot of GC content using a window size of 2000 nucleotides:
window_size <- 2000
#window_size <- 500
slidingwindowplotGC(windowsize = window_size, inputseq = seq1)

#' [*Mycoplasma genitalium* G37 genome](https://www.ncbi.nlm.nih.gov/genome/474?genome_assembly_id=300158) 
#' has a very distinctive variation in GC content.
#'
#' ### 2-3. 
#' Write a function to draw a sliding window plot of AT content.

# write a function to make a sliding window plot:
slidingwindowplotAT <- function(windowsize, inputseq)
{
  require("zoo")
  x <- seq(from = 1, to = length(inputseq)-windowsize, by = windowsize)
  AT <- function(x){ library("seqinr"); 1 - GC(x) }
  y <- rollapply(data = inputseq, width = windowsize, by = windowsize, FUN = AT)
  plot(x, y, type="l", xlab="Position (bp)", ylab="AT content")
}

#' Use it to make a sliding window plot of AT content along the genome, 
#' using a window size of 2000 nucleotides. 
par(mfrow=c(2,1), mgp=c(1.7, 0.5, 0), mar=c(3, 3, 1, 1), cex=0.9) # c(bottom, left, top, right)
# make a sliding window plot of AT content:
slidingwindowplotAT(windowsize = window_size, inputseq = seq1)
# This is the mirror image of the plot of GC content (because AT equals 1 minus GC):
slidingwindowplotGC(windowsize = window_size, inputseq = seq1)

#' ### 2-4. 
#' Is the 3-nucleotide word GAC over-represented or under-represented in the genome sequence?
# rho > 1: over-represented
# rho < 1: under-represented

# calculate Rho for words of length 3 in the genome
rho(sequence = seq1, wordsize=3)

#' ## 3. Dotplot
#source("my_assignment_chapter4_align_dotplot.R")

#' ### 3-1. 
#' Download FASTA-format files of two protein sequences from UniProt.

# Chorismate pyruvate-lyase OS=Mycobacterium
accession1 <- "Q9CD83" # PHBS_MYCLE
accession2 <- "A0PQ23" # A0PQ23_MYCUA
chars1 <- read.fasta(file=paste0("http://www.uniprot.org/uniprot/",accession1,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
chars2 <- read.fasta(file=paste0("http://www.uniprot.org/uniprot/",accession2,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
#write.fasta(sequences=chars1, names=getAnnot(chars1), file.out=paste0("./",accession1,".fasta") )
#write.fasta(sequences=chars2, names=getAnnot(chars2), file.out=paste0("./",accession2,".fasta") )

# get sequence length and annotation
length(chars1); getAnnot(chars1)
length(chars2); getAnnot(chars2)

#' ### 3-2. 
#' Create a dotplot for two sequences.
#' In the dotplot, the 1st sequence is plotted along the x-axis (horizontal axis), 
#' and the 2nd sequence is plotted along the y-axis (vertical axis). 
#' The dotplot displays a dot at points where there is an identical amino acid in the two sequences.

par(mfrow=c(1,2))
dotPlot(seq1 = chars1, seq2 = chars2)
dotPlot(seq1 = chars1, seq2 = chars2, wsize = 2, wstep = 2, nmatch = 2)

#' ### 3-3. 
#' Create a self-similarity dot-plot. i.e. Compare the sequence against itself.
#' Sequences may contain regions of self-similarity (internal repeats).

par(mfrow=c(1,2))
dotPlot(chars1, chars1)
dotPlot(chars2, chars2)

#' ## 4. Pairwise Sequence Alignment
#source("my_assignment_chapter4_align_pairwise.R")

#' ### 4-1. 
#' Download FASTA-format files of two protein sequences of interest from UniProt.

# conversion of a vector of chars into a string
string1 <- c2s(chars1)
string2 <- c2s(chars2)

# convert strings to uppercase 
STRING1 <- toupper(string1)
STRING2 <- toupper(string2)

#' ### 4-2. 
#' What is the alignment score for the optimal global alignment between the two proteins, 
#' when you use the BLOSUM62 scoring matrix (substitution matrix), 
#' a gap opening penalty of -9.5 and a gap extension penalty of -0.5?
data(BLOSUM62) # load the BLOSUM62 scoring matrix
AlignGlobal_BLOSUM62 <- pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM62", 
                                          gapOpening = 9.5, gapExtension = 0.5) # align the two sequences
AlignGlobal_BLOSUM62

#' The alignment score is 557.
#' 
#' ### 4-3. 
#' Use the writePairwiseAlignments() function to view the optimal global alignment.

writePairwiseAlignments(AlignGlobal_BLOSUM62)

#' The two sequences had alignment length of 220, with 121 (55.0%) identities and 18 (8.2%) gaps.
#' The position in the protein of the amino acid that is at the end of 
#' each line of the printed alignment is shown after the end of the line. 
#' For example, the first line of the alignment above finishes at amino acid position 40 
#' in the P1 sequence and also at amino acid position 50 in the S1 sequence.
#' Since we are printing out an alignment that contained gaps in the first 50 alignment columns, 
#' the first 50 alignment columns ends before the 50th amino acid in the P1 sequence.
#' 
#' ### 4-4. 
#' Check if the alignment made using the BLOSUM80 or BLOSUM45 scoring matrix 
#' (substitution matrix) is different from that when BLOSUM62 is used.
#' BLOSUM62 is the default matrix for protein BLAST.
#' BLOSUM80 is used for more closely related alignments, and 
#' BLOSUM45 is used for more distantly related alignments.
#data(package="Biostrings")

data(BLOSUM80) # load the BLOSUM80 scoring matrix
AlignGlobal_BLOSUM80 <- pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM80", 
                                          gapOpening = 9.5, gapExtension = 0.5) # align the two sequences
AlignGlobal_BLOSUM80
#writePairwiseAlignments(AlignGlobal_BLOSUM80)

data(BLOSUM45) # load the BLOSUM45 scoring matrix
AlignGlobal_BLOSUM45 <- pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM45", 
                                          gapOpening = 9.5, gapExtension = 0.5) # align the two sequences
AlignGlobal_BLOSUM45
#writePairwiseAlignments(AlignGlobal_BLOSUM45)

#' The alignment made using BLOSUM45 or BLOSUM80 is actually the same as that made using BLOSUM62, 
#' so it doesn’t matter which scoring matrix we use in this case.
#' 
#' ### 4-5. 
#' Change gap penalties to adjust alignment scores based on the number and length of gaps 
#' (e.g., set “gapOpening” to be 1.5 and “gapExtension” to be 0.5).

AlignGlobal_BLOSUM62_gap <- pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM62", 
                                              gapOpening = 1.5, gapExtension = 0.5) # align the two sequences
AlignGlobal_BLOSUM62_gap
#writePairwiseAlignments(AlignGlobal_BLOSUM62_gap)

#' ### 4-6. 
#' Check if the optimal local alignment is different from the optimal global alignment.
AlignLocal_BLOSUM62 <- pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM62", 
                                         gapOpening = 9.5, gapExtension = 0.5, type="local")
AlignLocal_BLOSUM62
#writePairwiseAlignments(AlignLocal_BLOSUM62)

#' We see that the optimal local alignment is quite similar to the optimal global alignment 
#' in this case, except that it excludes a short region of poorly aligned sequence 
#' at the start and at the ends of the two proteins.
#' 
#' ## 5. Multiple Alignment and Phylogenetic trees
#source("my_assignment_chapter5_msa_tree.R")
#' - [Exercises](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#exercises)
#' - [Answers to the exercises on Multiple Alignment and Phylogenetic Trees](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#multiple-alignment-and-phylogenetic-trees)
#' 
#' ### 5-1.
#' Calculate the genetic distances between >3 protein sequences of interest. 
#' Which has the smallest/greatest genetic distance?

# Retrieve several sequences from UniProt
# Make a vector containing the names of the sequences
myIngroup <- c("Q9YRR4", "Q9YP96", "B0LSS3", "Q6TFL5") # Dengue virus
myOutgroup <- c("Q32ZE1") # Zika virus
ACCESSIONs <- c(myIngroup, myOutgroup)
ACCESSIONs

# Create a function to retrieve several sequences from UniProt
read.fasta.uniprot <- function(ACCESSION) seqinr::read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]

# Retrieve the sequences and store them in list variable "seqs"
seqs <- lapply(ACCESSIONs, read.fasta.uniprot)

# Get the number of elements
length(seqs)

# Get the length of sequences
seqinr::getLength(seqs)

# Get sequence annotations
unlist(seqinr::getAnnot(seqs))

# write out the sequences to a FASTA file
seqinr::write.fasta(sequences=seqs, names=ACCESSIONs, file.out="mySeq.fasta")

# Read an XStringSet object from a file
myAAStringSet <- Biostrings::readAAStringSet(file = "mySeq.fasta")

# Multiple Sequence Alignment using ClustalW
library(msa)
myMsaAAMultipleAlignment <- msa::msa(inputSeqs=myAAStringSet, method="ClustalW")
myMsaAAMultipleAlignment
print(myMsaAAMultipleAlignment, show="complete")

#' The alignment contains a lot of columns with gaps in them. 
#' This could possibly be adding noise to the phylogenetic analysis.

# write an XStringSet object to a file
Biostrings::writeXStringSet(x = unmasked(myMsaAAMultipleAlignment), filepath = "myAln.fasta")

# read the FASTA-format alignment into R
myAln <- seqinr::read.alignment(file = "myAln.fasta", format = "fasta")

# calculate the genetic distances between the protein sequences
mydist <- seqinr::dist.alignment(x = myAln, matrix = "similarity")
mydist
#as.matrix(mydist)
#as.dist(as.matrix(mydist))

#' Based on the distance matrix,
#' B0LSS3 and Q9YP96 has the smallest genetic distance (0.2268713), and
#' Q6TFL5 and Q9YP96 has the greatest genetic distance (0.3328595),
#' excluding Q32ZE1 (outgroup).
#' 
#' ### 5-2. 
#' Build an unrooted phylogenetic tree of the proteins, using the neighbour-joining algorithm. 
#' Which are grouped together in the tree?

# construct a phylogenetic tree with the neighbor joining algorithm
mytree <- ape::nj(mydist)
ape::plot.phylo(mytree, type = "unrooted")

#' In the tree, 
#' B0LSS3 and Q9YP96 are grouped together.
#' 
#' ### 5-3. 
#' Build an unrooted phylogenetic tree of the proteins, based on a trimmed alignment of the proteins. 
#' Does this differ from the tree based on the untrimmed alignment (in Q2)?

# Trimming a multiple sequence alignment by discarding columns with too many gaps.
#library(microseq)
msa.untrimmed <- microseq::readFasta(in.file = "myAln.fasta")
print(nchar(msa.untrimmed$Sequence))
msa.trimmed <- microseq::msaTrim(msa = msa.untrimmed, gap.end = 0.3, gap.mid = 0.9)
print(nchar(msa.trimmed$Sequence))
microseq::writeFasta(fdta = msa.trimmed, out.file = "myAlnTrim.fasta", width = 80)

# read the FASTA-format alignment into R
myAln <- seqinr::read.alignment(file = "myAlnTrim.fasta", format = "fasta")
unlist(myAln$seq)

# calculate the genetic distances between the protein sequences
mydist <- seqinr::dist.alignment(x = myAln, matrix = "similarity")
mydist

# construct a phylogenetic tree
mytree <- ape::nj(mydist)
ape::plot.phylo(mytree, type = "unrooted", main="unrooted tree")

#' We find that B0LSS3 and Q9YRR4 are grouped together. 
#' This disagrees with what we found in the phylogenetic tree 
#' based on the unfiltered alignment (in Q2), 
#' in which B0LSS3 was grouped with Q9YP96.
#' 
#' It is likely that the gappy columns in the original unfiltered alignment were adding noise to the phylogenetic analysis.
#' 
#' ### 5-4. 
#' Build a rooted phylogenetic tree of the proteins, based on a trimmed alignment, using an outgroup. 
#' Which are the most closely related proteins, based on the tree? 
#' What extra information does this tree tell you, compared to the unrooted tree in Q3?
mytree <- ape::root(phy = mytree, outgroup = myOutgroup, r=T)
mytree <- ape::ladderize(mytree, right = FALSE)
ape::plot.phylo(mytree, type="phylogram", main="rooted tree")

#' **Figure. Evolutionary relationships of the four Dengue virus NS1 proteins.**
#' The phylogenetic tree was inferred with the Neighbor-Joining algorithm using the "nj" function of the "ape" package (version 5.5). 
#' The evolutionary distances were computed using "dist.alignment" function of the "seqinr" package (version 4.2-8). 
#' The analysis was carried out in the R version 4.0.5.
#' The phylogeny indicated that B0LSS3 and Q9YRR4 formed a monophyletic group or clade, joined by Q9YP96, followed by Q6TFL5, and finally Q32ZE1 (outgroup).
#' 
#' -----
#' 
#' We see in this tree that B0LSS3 and Q9YRR4 are grouped together. 
#' The next closest sequence is Q9YP96.
#' The Q6TFL5 sequence diverged earliest of the four proteins.
#' 
#' Note that in Q3, Q32ZE1 (outgroup) and Q6TFL5 were grouped together in an unrooted tree.
#' 
#' Thus, the rooted tree tells you 
#' which of the proteins branched off the earliest from the ancestors of the other proteins, 
#' and which branched off next, and so on... We were not able to tell this from the unrooted tree.
#' 
# Saving a phylogenetic tree as a Newick-format tree file
ape::write.tree(phy = mytree, file = "myNJ.tre")

#' # Print R version, OS and loaded packages.
sessionInfo()
Sys.time()
