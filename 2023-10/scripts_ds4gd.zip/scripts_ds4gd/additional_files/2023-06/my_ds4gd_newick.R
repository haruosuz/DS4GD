#' ---
#' title: "DS4GD_newick"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

rm(list = ls())
library(ape)

#' # newick
#' - https://en.wikipedia.org/wiki/Newick_format
#' - http://evolution.genetics.washington.edu/phylip/newicktree.html
#' The Newick tree format

layout(matrix(1:4, 2, 2))

txt <- "((A,B,C),D);"
tr <- read.tree(text = txt); tr; plot(tr, main = txt)

txt <- "((,,),);"
tr <- read.tree(text = txt); tr; plot(tr, main = txt)

txt <- "((A:0.05,B:0.2,C:0.1):0.3,D:0.4);"
tr <- read.tree(text = txt); tr; plot(tr, main = txt)

txt <- "((A:0.05,B:0.2,C:0.1)Ancestor:0.3,D:0.4)R;"
tr <- read.tree(text = txt); tr
plot.phylo(tr, main = txt)
nodelabels(tr$node.label)
add.scale.bar()

names(tr)
write.tree(tr)
write.tree(tr, file = "myNewick.tre")

#' - http://tree.bio.ed.ac.uk/software/figtree/
#' FigTree is designed as a graphical viewer of phylogenetic trees and as a program for producing publication-ready figures. 
#library(ape)
#?ape::ladderize
layout(matrix(1:4, 2, 2))
txt <- "(E, ((C, (A, B)), D));"
txt <- "(Fishes, ((Lizards, (Chimps, Humans)), Frogs));"
tr <- read.tree(text = txt); write.tree(tr); plot(tr, main = "normal")
tr <- ladderize(tr, right=T); write.tree(tr); plot(tr, main="right-ladderized")
tr <- ladderize(tr, right=F); write.tree(tr); plot(tr, main="left-ladderized")
#layout(matrix(1, 1))
txt <- "(Humans, ((Lizards, Snakes), (Crocodiles, Birds)));"
tr <- read.tree(text = txt); plot(tr, type="cladogram", main="Reptiles are monophyletic?")
#ape::is.monophyletic(phy = tr, tips = c("Lizards", "Snakes", "Crocodiles"))
#' 
#' - https://en.wikipedia.org/wiki/Monophyly

# Print R version, OS and loaded packages.
sessionInfo()
Sys.time()

