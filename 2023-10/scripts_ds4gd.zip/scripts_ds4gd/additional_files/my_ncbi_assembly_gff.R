
#+ echo = TRUE
rm(list = ls())
#+ message = FALSE
library(tidyverse)
#' - https://github.com/haruosuz/books/tree/master/r4ds
#' - https://r4ds.had.co.nz/tibbles.html
options(tibble.print_min = Inf) #to always show all rows.
options(tibble.width = Inf) #to always print all columns

url <- ""
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/README.txt"
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/GCA_000005845.2_ASM584v2_genomic.gff.gz" # Escherichia coli str. K-12 # 14 # 0.465093 # 0.03322093 
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/001/922/385/GCA_001922385.1_ASM192238v1/GCA_001922385.1_ASM192238v1_genomic.gff.gz" # Sphingomonas koreensis # 4 # 0.1327334 # 0.03318334 
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/010/305/GCA_000010305.1_ASM1030v1/GCA_000010305.1_ASM1030v1_genomic.gff.gz" # Gemmatimonas aurantiaca T-27 # 2 # 0.06586206 # 0.03293103 
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/020/546/685/GCA_020546685.1_ASM2054668v1/GCA_020546685.1_ASM2054668v1_genomic.gff.gz" # Deinococcus radiodurans R1 # 6 # 0.3416847 # 0.05694746
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)
#if(!file.exists(filename)){ download.file(url = url, destfile = filename); untar(tarfile = filename, exdir = "APER2_Online_Material") }

#' - https://heavywatal.github.io/rstats/readr.html
# Loading Data into R
d <- read_tsv(file=filename, col_names=FALSE, comment="#")
dim(d)
TF <- grepl(pattern="16S ribosomal RNA", x=unlist(d[,9])); summary(TF)
( length_sequence_pattern <- unlist(d[TF,5] - d[TF,4] + 1) )
( length_sequence_total <- unlist(d[1,5] - d[1,4] + 1) )
100 * median(length_sequence_pattern) / length_sequence_total

#' # References
#' 
#' - https://github.com/haruosuz/introBI/blob/master/2020/CaseStudy.md#ncbi-genome-list
#' 
#' 
#' - Escherichia coli str. K-12 substr. MG1655
#' - https://www.ncbi.nlm.nih.gov/assembly/GCA_000005845.2
#' - https://www.ncbi.nlm.nih.gov/nuccore/U00096.3
#' - https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/
#' 
#' - https://www.ncbi.nlm.nih.gov/genome/browse/#!/prokaryotes/Sphingomonas
#' - Sphingomonas koreensis
#' - https://www.ncbi.nlm.nih.gov/assembly/GCA_001922385.1
#' - https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/001/922/385/GCA_001922385.1_ASM192238v1/
#' 
#' - https://www.ncbi.nlm.nih.gov/genome/browse/#!/prokaryotes/Gemmatimonas
#' - Gemmatimonas aurantiaca T-27
#' - https://www.ncbi.nlm.nih.gov/assembly/GCA_000010305.1
#' - https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/010/305/GCA_000010305.1_ASM1030v1/
#' 
#' - https://www.ncbi.nlm.nih.gov/genome/browse/#!/prokaryotes/Deinococcus
#' - Deinococcus radiodurans R1 = ATCC 13939 = DSM 20539
#' - https://www.ncbi.nlm.nih.gov/assembly/GCA_020546685.1
#' 

#getwd()
#list.files()
#sessionInfo()
#Sys.time()

