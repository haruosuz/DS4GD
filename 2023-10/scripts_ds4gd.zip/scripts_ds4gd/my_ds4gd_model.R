#' ---
#' title: "DS4GD_model"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

rm(list = ls())
#library(ape)

#' # model
#' ## references
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/188bto4/alma99159251504031
#' Computational Molecular Evolution / Yang, Ziheng. 2006 | 
#' Part I: Modeling Molecular Evolution |
#' CHAPTER 1 Models of Nucleotide Substitution |
#' 1.1 Introduction |
#' 1.2 Markov Models of Nucleotide Substitution and Distance Estimation |
#' 1.2.1 The JC69 Model |
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/fb8nrm/alma99186639204031
#' Analysis of Phylogenetics and Evolution with R / Paradis, Emmanuel. 2012 | 
#' 5 Phylogeny Estimation | 
#' 5.1 Distance Methods | 
#' 5.1.1 Calculating Distances |
#' Table 5.1. Functions for computing distances in R | 
#' 5.1.2 Exploring and Assessing Distances |
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/fb8nrm/alma9926580096704034
#' よくわかるバイオインフォマティクス入門 / 藤博幸編. 2018.11 | 
#' 2章 分子系統解析 21 | 
#' 2.3.2 I配列聞の相違度の計算 | 
#' 2.3.3 I進化距離の推定 | 
#' 22 | 図 2.3 多重置換 | 同じ座位で2回以上の置換が生じることを多重置換と呼ぶ
#' 
#' ## multiple substitutions
#' - https://www.oxfordreference.com/display/10.1093/oi/authority.20110803100215990
#' - https://users.ugent.be/~avierstr/principles/phylogeny.html
#' ![https://users.ugent.be/~avierstr/principles/phylogeny.html](https://users.ugent.be/~avierstr/principles/mutation.gif)
#' 
#' ## Transitions_vs_Transversions
#' - https://www.mun.ca/biology/scarr/Transitions_vs_Transversions.html
#' ![https://en.wikipedia.org/wiki/Transversion](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/All_transitions_and_transversions.svg/600px-All_transitions_and_transversions.svg.png)
#' 
#' - [Codes Used in Sequence Description](https://www.ddbj.nig.ac.jp/ddbj/code-e.html)
#' Nucleotide Base Codes
#' ```
#' r	a or g	purine
#' y	c or t	pyrimidine
#' ```
#' 
#' ## Evolutionary Distances
# vector of chars
chars1 <- c("a","c","g","t", "a","c","g","t", "a","a","c","c","g","g","t","t")
chars2 <- c("a","c","g","t", "g","t","a","c", "c","t","a","g","c","t","a","g")
############################ #-transitions-#  #--------transversions--------#
chars1 <- c("a","c","g","t", "a","c",         "a","a","g","g")
chars2 <- c("a","c","g","t", "g","t",         "c","t","c","t")
mat <- rbind(chars1, chars2)
myDNAbin <- ape::as.DNAbin(mat)
as.character(myDNAbin)
ape::dist.dna(x = myDNAbin, model = "TS") # transitions
ape::dist.dna(x = myDNAbin, model = "TV") # transversions
ape::dist.dna(x = myDNAbin, model = "N")
( p <- ape::dist.dna(x = myDNAbin, model = "raw") )
( d <- -3/4 * log(1 - 4/3 * p) )
ape::dist.dna(x = myDNAbin, model = "JC69") # Jukes and Cantor (1969)
#' - https://en.wikipedia.org/wiki/Substitution_model JC69
#' - https://en.wikipedia.org/wiki/Models_of_DNA_evolution#JC69_model_(Jukes_and_Cantor_1969)
#' ![](https://wikimedia.org/api/rest_v1/media/math/render/svg/0e78cfbdcb0ae0efaaf136d9a1f7856a617de5f3)

# Print R version, OS and loaded packages.
sessionInfo()
Sys.time()

