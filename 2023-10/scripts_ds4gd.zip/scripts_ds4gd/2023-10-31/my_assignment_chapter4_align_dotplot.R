#' # assignment
#' ## [ドットプロットで2つの配列を比較](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#comparing-two-sequences-using-a-dotplot)
#' ## [Comparing two sequences using a dotplot](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#comparing-two-sequences-using-a-dotplot)

rm(list = ls()) # Clear R's environment
library(seqinr) # Loading the "seqinr" package 

#' Answer the following questions. 
#' For each question, please record your answer, and what you typed to get this answer.
#' 
#' ### Q1. 
#' Download FASTA-format files of two protein sequences from databases.

# Download FASTA-format files of two protein sequences from NCBI.
#accession1 <- "NP_001393" # elongation factor 1-alpha 1 [Homo sapiens]
#accession2 <- "WP_011012522" # translation elongation factor EF-1 subunit alpha [Pyrococcus furiosus]
#chars1 <- read.fasta(file=paste0("http://togows.dbcls.jp/entry/protein/",accession1,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
#chars2 <- read.fasta(file=paste0("http://togows.dbcls.jp/entry/protein/",accession2,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]

# Download FASTA-format files of two protein sequences from UniProt.
accession1 <- "Q9CD83" # Modify the accession number
accession2 <- "A0PQ23" # Modify the accession number
chars1 <- read.fasta(file=paste0("http://www.uniprot.org/uniprot/",accession1,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
chars2 <- read.fasta(file=paste0("http://www.uniprot.org/uniprot/",accession2,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]

# Write sequence(s) into a file in fasta format
#write.fasta(sequences=chars1, names=getAnnot(chars1), file.out=paste0("./",accession1,".fasta") )
#write.fasta(sequences=chars2, names=getAnnot(chars2), file.out=paste0("./",accession2,".fasta") )

# get sequence length and annotation
length(chars1); getAnnot(chars1)
length(chars2); getAnnot(chars2)

#' ### Q2. 
#' Create a dotplot for two sequences.
#' In the dotplot, the 1st sequence is plotted along the x-axis (horizontal axis), 
#' and the 2nd sequence is plotted along the y-axis (vertical axis). 
#' The dotplot displays a dot at points where there is an identical amino acid in the two sequences.

par(mfrow=c(1,2))
dotPlot(seq1 = chars1, seq2 = chars2)
dotPlot(seq1 = chars1, seq2 = chars2, wsize = 2, wstep = 2, nmatch = 2)

#' ### Q3. 
#' Create a self-similarity dot-plot. i.e. Compare the sequence against itself.
#' Sequences may contain regions of self-similarity (internal repeats).

par(mfrow=c(1,2))
dotPlot(chars1, chars1)
dotPlot(chars2, chars2)

# Print R version and packages
sessionInfo()
Sys.time()
