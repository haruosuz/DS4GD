#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#over-represented-and-under-represented-dna-words

# Loading Package "seqinr"
library(seqinr)
# Create test data of a DNA sequence
myseq <- s2c("aatgc")
count(myseq, 1) # Get the number of occurrences of 1-nucleotide DNA words
1/(2+1+1+1) # Get fG
1/(2+1+1+1) # Get fC
count(myseq, 2) # Get the number of occurrences of 2-nucleotide DNA words
1/(1+0+0+1+0+0+0+0+0+1+0+0+0+0+1+0) # Get fGC
0.25/(0.2*0.2) # Get rho(GC)

#' 2連続塩基 "aa" "ac" "ag" "at" "ca" "cc" "cg" "ct" "ga" "gc" "gg" "gt" "ta" "tc" "tg" "tt" のρ値（観測値/期待値）を計算する:  
# the ratio of the observed to expected frequency of dinucleotides
( af1 <- count(myseq, wordsize = 1) ) # absolute frequencies of 1-mer
( rf1 <- af1 / sum(af1) )             # relative frequencies of 1-mer
( af2 <- count(myseq, wordsize = 2) ) # absolute frequencies of 2-mer
( rf2 <- af2 / sum(af2) )             # relative frequencies of 2-mer
( oe.2 <- rf2 / apply(expand.grid(rf1, rf1), 1, prod) ) # observed / expected

#' `rho`関数を使う:  
# The rho statistic can be computed on each of the 16 dinucleotides
rho(sequence = myseq, wordsize = 2)
