#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#dna-sequence-statistics-1

# load the "SeqinR" R package
library("seqinr")
# Create test data of a DNA sequence
myseq <- s2c("acgt")
myseq
# Length of a DNA sequence
length(myseq)
# Base composition of a DNA sequence
table(myseq)
# GC Content of DNA
GC(myseq)
# DNA words
count(myseq, wordsize = 2)

