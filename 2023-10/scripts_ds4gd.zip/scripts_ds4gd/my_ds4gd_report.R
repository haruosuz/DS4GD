#' ---
#' title: "My report"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

# clear the decks
rm(list = ls())

# load the packages
#+ warning = FALSE
#+ message = FALSE
library(seqinr)
library(zoo)
library(Biostrings)
library(msa)
library(ape)
library(microseq)

#' - https://r-pkgs.org/namespace.html
?count
?dplyr::count
?seqinr::count

?translate
?microseq::translate
?Biostrings::translate
?seqinr::translate

?as.alignment
?seqinr::as.alignment
?ape::as.alignment

#' # 
#' ## DNA Sequence Statistics (1)
#' ## DNA Sequence Statistics (2)
#' ## Dotplot
#' ## Pairwise Sequence Alignment
#' 
#' # Print R version, OS and loaded packages.
sessionInfo()
Sys.time()
