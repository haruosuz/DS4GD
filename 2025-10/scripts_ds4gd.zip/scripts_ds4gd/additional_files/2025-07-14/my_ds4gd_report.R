#' ---
#' title: "DATA SCIENCE FOR GENOME DYNAMICS"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

# Clear R's environment
rm(list = ls())

# Load the packages into R
#+ warning = FALSE
#+ message = FALSE
library(seqinr)
library(zoo)
library(Biostrings)
library(pwalign)
library(ape)

#' # 1. 
#' ## 1-1. 
#' ### 1-1-1. 
#' 
#' # 1. DNA Sequence Statistics (1)
#source("./2025-04-22/my_assignment_chapter1_dna1.R")

#' # 2. DNA Sequence Statistics (2)
#source("./2025-04-29/my_assignment_chapter2_dna2.R")

#' # 3. Dotplot
#' ## 3-1. Download FASTA
#' ## 3-2. dotplot
#' ## 3-1. self-similarity dot-plot
#source("./2025-05-13/my_assignment_chapter4_align_dotplot.R")

#' # 4. Pairwise Sequence Alignment
#' ## 4-2. AlignGlobal_BLOSUM62
#' ## 4-3. writePairwiseAlignments
#' ## 4-4. AlignGlobal BLOSUM80 BLOSUM45
#' ## 4-5. AlignGlobal_BLOSUM62_gap
#' ## 4-6. AlignLocal_BLOSUM62
#source("./2025-05-20/my_assignment_chapter4_align_pairwise.R")

#' # 5. Multiple Alignment and Phylogenetic trees
#' ## 5-1. genetic distances
#' ## 5-2. unrooted tree
#' ## 5-3. unrooted tree from trimmed alignment
#' ## 5-4. rooted tree from trimmed alignment
#source("./2025-07-01/my_assignment_chapter5_msa_tree.R")

#' # [R Packages (2e)](https://r-pkgs.org/)
#' ## [10.2 Namespace](https://r-pkgs.org/namespace.html)
#?count
#?dplyr::count
#?seqinr::count

#?translate
#?microseq::translate
#?Biostrings::translate
#?seqinr::translate

#?as.alignment
#?seqinr::as.alignment
#?ape::as.alignment

#' # References
#' - https://github.com/haruosuz/DS4GD/tree/master
#' - https://github.com/haruosuz/DS4GD/blob/master/CaseStudy.md
#' - [R Packages (2e)](https://r-pkgs.org/)
#'   - [10.2 Namespace](https://r-pkgs.org/dependencies-mindset-background.html#sec-dependencies-namespace)
#' - [Chapter 11 Namespace | R Packages](https://bookdown.dongzhuoer.com/hadley/r-pkgs/namespace)
#' 
#' # Print R version, OS and loaded packages.
sessionInfo()
Sys.time()
