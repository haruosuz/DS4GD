# Haruo Suzuki
# 2023-12-25
# This script utilizes E-utilities to retrieve FASTA files (extensions: .fna, .ffn, .faa).
#' - https://en.wikipedia.org/wiki/FASTA_format
#' - https://github.com/haruosuz/DS4GD/blob/master/2019giga/CaseStudy.md#e-utilities
#' - https://github.com/haruosuz/bioinfo/blob/master/references/README.bioinfo.tools.md#e-utilities

rm(list = ls()) # Clear R's environment
library(seqinr) # Loading the "seqinr" package 
ACCESSION <- "M28829" # Modify the accession number
# read FASTA formatted files
## FASTA nucleic acid
fna.seqs <- read.fasta(file = paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text"), seqtype="DNA", strip.desc=TRUE)
## FASTA nucleotide of gene regions
ffn.seqs <- read.fasta(file = paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta_cds_na&retmode=text"), seqtype="DNA", strip.desc=TRUE)
## FASTA amino acid
faa.seqs <- read.fasta(file = paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta_cds_aa&retmode=text"), seqtype="AA", strip.desc=TRUE)

# creates a directory
dir.create(path="data", recursive=TRUE)
# Writing sequence data out as a FASTA file
write.fasta(sequences=fna.seqs, names=getAnnot(fna.seqs), file.out=paste0("data/",ACCESSION,".fna"))
write.fasta(sequences=ffn.seqs, names=getAnnot(ffn.seqs), file.out=paste0("data/",ACCESSION,".ffn"))
write.fasta(sequences=faa.seqs, names=getAnnot(faa.seqs), file.out=paste0("data/",ACCESSION,".faa"))

# Get the number of elements
length(fna.seqs)
length(ffn.seqs)
length(faa.seqs)

# Extract the 1st element from a list
ffn.seqs[[1]]
faa.seqs[[1]]

#' - https://www.ncbi.nlm.nih.gov/Taxonomy/Utils/wprintgc.cgi
#tablecode(numcode=11)
# Translate nucleic acid sequences into proteins
AA11 <- sapply(ffn.seqs, translate, numcode=11)
AA01 <- getTrans(ffn.seqs, numcode = 1)
AA01[[1]]

# Apply a Function over a List
Length <- sapply(ffn.seqs, length) # Length of a DNA sequence
GCcontent <- sapply(ffn.seqs, GC) # Global G+C content
GCpos1 <- sapply(ffn.seqs, GCpos, pos=1) # G+C in the 1st position of the codon bases
GCpos2 <- sapply(ffn.seqs, GCpos, pos=2) # G+C in the 2nd position of the codon bases
GCpos3 <- sapply(ffn.seqs, GCpos, pos=3) # G+C in the 3rd position of the codon bases
# Get sequence annotations
Annotation <- unlist(getAnnot(ffn.seqs)) # get sequence annotations
protein <- sub(pattern=".+\\[protein=([^\\[]+)\\] \\[.+", replacement="\\1", Annotation)
location <- sub(pattern=".+\\[location=(.+)\\] \\[gbkey=.+", replacement="\\1", Annotation)

# Creates data frame (table)
d.f <- data.frame(Length, GCcontent, GCpos1, GCpos2, GCpos3, Annotation, protein, location)
#View(d.f)

# Exporting Data
write.table(d.f, file="myTable.tsv", sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
write.csv(d.f, file="myTable.csv", quote=TRUE, row.names=TRUE)

d.f. <- d.f[,c(2:5)]
summary(d.f.) # Generic function for Object Summaries
plot(d.f.) # Generic function for plotting of R objects

# histograms and correlations for a data matrix
#install.packages("psych") #library(psych)
#psych::pairs.panels(d.f.)

#getwd()
#list.files()
sessionInfo()
Sys.time()
