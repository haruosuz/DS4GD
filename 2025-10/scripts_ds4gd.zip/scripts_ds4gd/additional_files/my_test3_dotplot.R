#' # dotplot
#' 
#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#comparing-two-sequences-using-a-dotplot
#' Comparing two sequences using a dotplot
#' ドットプロットで2本の配列を比較
#' - https://www.kspub.co.jp/book/detail/5138212.html
#' よくわかるバイオインフォマティクス入門 | 6.2.2 | ドットプロット (dotplot)
#' - https://www.jsbi.org/activity/nintei/sankou_mondai_kako/
#' バイオインフォマティクス技術者認定試験 参考問題・過去問題
#' 2019年度（平成31年度） 問題 解説
#'   - https://www.jsbi.org/media/files/activity/nintei/sankou_mondai_kako/2019_mondai.pdf
#' 問 44
#' ドットプロット

# seqinr パッケージを R に読み込む
# Load the seqinr package into R
library("seqinr")

# DNA配列のテストデータを作成する（`seqinr`パッケージの`s2c`関数は文字列を文字ベクトルに変換する）
# Create test data for a DNA sequence (convert a single string into a vector of characters using the `s2c` function of the `seqinr` package)
s2c("tgca")

# グラフィカルパラメータ、2行3列の枠を準備
# Graphical Parameters, prepare a 2x3 frame
par(mfrow=c(2,3))

# 両軸に全く同じ配列をとれば、対角線が現れる
# Identity is detected on the main diagonal
dotPlot(s2c("tgca"), s2c("tgca"))

# 2番目（y軸）の配列に挿入があると、縦のジャンプが発生する
# Insertion in the 2nd sequence yields a vertical jump
dotPlot(s2c("tgca"), s2c("tgnca"))

# 1番目（x軸）の配列に挿入があると、横のジャンプが発生する
# Insertion in the 1st sequence yields a horizontal jump
dotPlot(s2c("tgnca"), s2c("tgca"))

# 相補鎖
# complementary strand
dotPlot(s2c("tgca"), comp(s2c("tgca")))

# 逆相補鎖
# reverse complementary strand
dotPlot(s2c("tgca"), rev(comp(s2c("tgca"))))

# 配列内のリピートは、対角線から外れる
# Internal repeats are off the main diagonal:
dotPlot(rep(s2c("tgca"),2), rep(s2c("tgca"),2))

#' [回文配列](https://ja.wikipedia.org/wiki/回文配列)
#' [Palindromic sequence](https://en.wikipedia.org/wiki/Palindromic_sequence)
#' 
