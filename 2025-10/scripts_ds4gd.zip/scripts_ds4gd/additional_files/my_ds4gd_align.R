# 2024-09-16
# This script is for comparing two protein sequences using a `dotPlot` and `pairwiseAlignment`
#' - https://github.com/haruosuz/DS4GD/blob/master/CaseStudy.md#blast_2_sequences
#' - https://www.ncbi.nlm.nih.gov/IEB/ToolBox/CPP_DOC/lxr/source/include/algo/blast/core/blast_options.h
#' - https://www.ncbi.nlm.nih.gov/books/NBK279684/
#' Table C3:
#' blastp application options.
#' option	task	type	default value	description and notes
#' gapopen	blastp	integer	11	Cost to open a gap.
#' gapextend	blastp	integer	1	Cost to extend a gap.

#+ echo = FALSE
# Clear R's environment
rm(list = ls())
#+ message = FALSE
# Load the packages
library(seqinr)
library(Biostrings)

#' ## Read FASTA-format files of two homologous sequences.

# Generate URLs to access NCBI protein data.
accession1 <- "NP_001393"    # Modify the accession number
accession2 <- "WP_011012522" # Modify the accession number
path1 <- paste0("http://togows.org/entry/protein/",accession1,".fasta")
path2 <- paste0("http://togows.org/entry/protein/",accession2,".fasta")

# Generate URLs to access UniProt data.
accession1 <- "Q9CD83" # Modify the accession number
accession2 <- "A0PQ23" # Modify the accession number
#path1 <- paste0("http://www.uniprot.org/uniprot/",accession1,".fasta")
#path2 <- paste0("http://www.uniprot.org/uniprot/",accession2,".fasta")

# Generate paths to access files on the local computer.
#path1 <- "Q9CD83.fasta"
#path2 <- "A0PQ23.fasta"

# Print out the content of R objects
path1
path2

# read FASTA formatted files
chars1 <- read.fasta(file=path1, seqtype="AA", strip.desc=TRUE)[[1]]
chars2 <- read.fasta(file=path2, seqtype="AA", strip.desc=TRUE)[[1]]

# Write sequence(s) into a file in fasta format
#write.fasta(sequences=chars1, names=getAnnot(chars1), file.out=paste0("./",accession1,".fasta") )
#write.fasta(sequences=chars2, names=getAnnot(chars2), file.out=paste0("./",accession2,".fasta") )

# get sequence length and annotation
length(chars1); getAnnot(chars1)
length(chars2); getAnnot(chars2)

#' ## dotplot
dotPlot(chars1, chars2)

# conversion of a vector of chars into a string
string1 <- c2s(chars1)
string2 <- c2s(chars2)

# convert strings to uppercase 
STRING1 <- toupper(string1)
STRING2 <- toupper(string2)

#' ## pairwiseAlignment
#' ### gapOpening = 11, gapExtension = 1
data(BLOSUM62) # load the BLOSUM62 scoring matrix
AlignGlobal_BLOSUM62 <- pwalign::pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM62", 
                         gapOpening = 11, gapExtension = 1) # align the two sequences
AlignGlobal_BLOSUM62
pwalign::writePairwiseAlignments(AlignGlobal_BLOSUM62)

#' ### type="local"
#' Check if the optimal local alignment is different from the optimal global alignment.
AlignLocal_BLOSUM62 <- pwalign::pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM62", 
                        gapOpening = 11, gapExtension = 1, type="local")
AlignLocal_BLOSUM62
pwalign::writePairwiseAlignments(AlignLocal_BLOSUM62)

sessionInfo() # Print information about the R session, including the version and loaded packages
Sys.time() # Get the current system time
