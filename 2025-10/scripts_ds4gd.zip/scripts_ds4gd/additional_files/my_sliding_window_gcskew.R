# Haruo Suzuki
# 2025-05-28
# This script performs a sliding window analysis of base composition,
# including GC content, GC skew, and the cumulative GC skew.

# Clear R's environment
rm(list = ls())

# Load the packages into R:
library(seqinr)
library(zoo)

# Retrieving a DNA sequence from NCBI
ACCESSION <- "L43967.2" # Mycoplasma genitalium G37
ACCESSION <- "AE000783" # Borreliella burgdorferi B31
filename <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text")
#filename <- paste0("http://togows.org/entry/nucleotide/",ACCESSION,".fasta")

seqs <- read.fasta(file=filename, seqtype="DNA", strip.desc=TRUE)
#write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=paste0(ACCESSION,".fasta") )

seq1 <- seqs[[1]]
getLength(seq1) # Get the length of sequences
getAnnot(seq1) # Get sequence annotations

#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#local-variation-in-gc-content
# Local variation in GC content
# A sliding window analysis of GC content
# A sliding window plot of GC content

windowsize <- 10000
stepsize <- 1000

# x-axis: Position
x <- seq(from = 1, to = length(seq1)-windowsize, by = stepsize) / 10^6
xlab <- "Position (Mb)"

# y-axis: GC content
y <- rollapply(data = seq1, width = windowsize, by = stepsize, FUN = GC)
plot(x, y, type="l", xlab=xlab, ylab="GC content")

# y-axis: GC skew
GCskew <- function(x){ y <- table(x); (y["g"] - y["c"]) / (y["g"] + y["c"]) }
y <- rollapply(data = seq1, width = windowsize, by = stepsize, FUN = GCskew)
plot(x, y, type="l", xlab=xlab, ylab="GC skew"); abline(h = 0)

# y-axis: Cumulative GC skew
plot(x, cumsum(y), type="l", xlab=xlab, ylab="Cumulative GC skew")

#' # References
#' - https://en.wikipedia.org/wiki/GC-content
#' - https://ja.wikipedia.org/wiki/GC含量
#' - https://en.wikipedia.org/wiki/GC_skew
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/fb8nrm/alma9926580096704034
#' よくわかるバイオインフォマティクス入門
#' p. 86: GC skew
#' - [Ermolaeva 2001 "Synonymous codon usage in bacteria"](https://pubmed.ncbi.nlm.nih.gov/11719972/)
#' https://www.mdpi.com/1467-3045/3/4/13/pdf?version=1623381005
#' - Figure 1. GC composition of M.genitalium genome. Window size 10000 nucleotides and step size 1000 nucleotides.
#' - Figure 3. GC skew for the main chromosome of the B. burgoferri genome. GC skew was calculated as (G-C)/(G+C) with window size 10000 nucleotides and step size 1000. Switch in GC skew sign corresponds to the origin of replication.
#'
#getwd()
#list.files()
sessionInfo()
Sys.time()
