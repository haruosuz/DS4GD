
# Clear R's environment
rm(list = ls())

# Load the required packages
library(rentrez)
library(seqinr)

# Download FASTA-format files of two protein sequences from NCBI.
accession1 <- "NP_001393" # elongation factor 1-alpha 1 [Homo sapiens]
accession2 <- "WP_011012522" # translation elongation factor EF-1 subunit alpha [Pyrococcus furiosus]
chars1 <- read.fasta(file=paste0("http://togows.dbcls.jp/entry/protein/",accession1,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
chars2 <- read.fasta(file=paste0("http://togows.dbcls.jp/entry/protein/",accession2,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
write.fasta(sequences=chars1, names=getAnnot(chars1), file.out=paste0("./",accession1,".fasta") )
write.fasta(sequences=chars2, names=getAnnot(chars2), file.out=paste0("./",accession2,".fasta") )

# Download FASTA-format files of two protein sequences from UniProt.
accession1 <- "Q9CD83" # Modify the accession number
accession2 <- "A0PQ23" # Modify the accession number
chars1 <- read.fasta(file=paste0("http://www.uniprot.org/uniprot/",accession1,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
chars2 <- read.fasta(file=paste0("http://www.uniprot.org/uniprot/",accession2,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
write.fasta(sequences=chars1, names=getAnnot(chars1), file.out=paste0("./",accession1,".fasta") )
write.fasta(sequences=chars2, names=getAnnot(chars2), file.out=paste0("./",accession2,".fasta") )

database <- "uniprot"
#database <- "ncbi_protein"

file.fasta <- "myAA.fasta" # FASTA file of protein (amino acid) sequences
# Retrieve the sequences and store them in list variable "seqs"
if (database == "ncbi_protein") {
  ACCESSIONs <- c("NP_001393", "WP_011012522") # elongation factor
  seqs <- lapply(ACCESSIONs, function(x) rentrez::entrez_fetch(db="protein", id=x, rettype="fasta"))
  write(unlist(seqs), file=file.fasta)
} else if (database == "uniprot") {
  ACCESSIONs <- c("Q9CD83", "A0PQ23") # Modify the accession number
  # Create a function to retrieve several sequences from UniProt
  read.fasta.uniprot <- function(ACCESSION) seqinr::read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
  seqs <- lapply(ACCESSIONs, read.fasta.uniprot)
  # Write sequence(s) in FASTA formatted files
  write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=file.fasta, nbchar=max(getLength(seqs)))
}
seqs <- read.fasta(file=file.fasta, seqtype="AA", strip.desc=TRUE)
length(seqs)
getLength(seqs)
unlist(getAnnot(seqs))

# Print R version and packages
sessionInfo()
Sys.time()
