# Haruo Suzuki
# 2025-05-02
# This script is for the k-mer (oligonucleotide relative abundance) analysis.
#+ echo = TRUE
rm(list = ls())
#+ message = FALSE
library(tidyverse)
library(seqinr)
library(ape)
library(Biostrings)
library(DECIPHER)
file.fasta <- "mySequences.fna" # FASTA file of nucleotide sequences
download <- ifelse(!file.exists(file.fasta), TRUE, FALSE)
# Retrieve the sequences and store them in list variable "fna.seqs"
if(download){
  ACCESSIONs <- c("BN000925", "U67194", "AB231906", "AM157767", "GQ983559", "AM261282", "AY950444", "KC170283", "CP006601") # IncP-1 plasmids
  ACCESSIONs <- c("AP018710", "CP014764", "CP015073", "CP020602") # pSN1216-29 and related plasmids
  ACCESSIONs <- c("JX869059", "KY352407", "MN908947") # MERS-CoV, SARS-CoV, SARS-CoV-2
  # Create a function to retrieve several nucleotide sequences from NCBI
  retrieve_ncbi_fna <- function(ACCESSION) seqinr::read.fasta(file = paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text"), seqtype="DNA", strip.desc=TRUE)[[1]]
  # Retrieve the sequences and store them in list variable
  fna.seqs <- lapply(ACCESSIONs, retrieve_ncbi_fna)
  # Write sequence(s) in FASTA formatted files
  write.fasta(sequences=fna.seqs, names=getAnnot(fna.seqs), file.out=file.fasta, nbchar=max(getLength(fna.seqs)))
}
#' Read sequences from a file in FASTA format.
fna.seqs <- read.fasta(file=file.fasta, seqtype="DNA", strip.desc=TRUE)
length(fna.seqs)

# Apply a Function over a List
#lapply(fna.seqs, summary)
#sapply(fna.seqs, summary)
Length <- seqinr::getLength(fna.seqs) # get the length of sequences
GCcontent <- round( sapply(fna.seqs, seqinr::GC) , digits=3) # Global G+C content
Annotation <- unlist(seqinr::getAnnot(fna.seqs)) # sequence annotations
# Creates data frame (table)
d.f <- data.frame(Length, GCcontent, Annotation)
#View(d.f)
knitr::kable(d.f, caption = "Table. DNA Sequence Statistics.")

# Exporting Data
#write_tsv(x=d.f, file="myTable.tsv") # w/o rownames
write.table(d.f, file="R.fna.table.tsv", sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
#write.csv(d.f, file="R.fna.table.csv", quote=TRUE, row.names=TRUE)

#' - https://github.com/haruosuz/DS4GD/blob/master/2017/hclust.md
#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#over-represented-and-under-represented-dna-words
myfun_rho <- function(x,k) seqinr::rho(x, wordsize=k) # for ssDNA
#myfun_rho <- function(x,k) seqinr::rho(c(x, ' ', rev(seqinr::comp(x))), wordsize=k) # for dsDNA

#mycex <- 1.0 # Graphical Parameters
pdf("R.fna.seqinr_rho.heatmap.pdf", pointsize=10, width=15, height=9)
#par(mfrow=c(1,1), mgp=c(1.7, 0.5, 0), mar=c(1.5, 0.5, 1, 2.5), cex=mycex) # c(bottom, left, top, right)

for(k in 2:4){ # 2:4
  myrho <- sapply(X=fna.seqs, FUN=myfun_rho, k)
  colnames(myrho) <- seqinr::getName(fna.seqs)
  filename <- paste0("R.fna.seqinr_rho_wordsize",k,".tsv")
  write.table(data.frame(myrho), file=filename, sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
  #mydist <- as.dist(1-cor(myrho)); #print(mean(mydist))
  mydist <- dist(t(myrho), method="euclidean")
  hc <- hclust(d=mydist, method="average"); #plot(hc, hang=-1, main=filename); #rect.hclust(hc, k=2)
  cexRow <- min(1, 25 / ncol(myrho))
  cexCol <- min(1, 35 / nrow(myrho))
  heatmap(t(myrho), Rowv=as.dendrogram(hc), scale="none", margins=c(5,5), cexRow=cexRow, cexCol=cexCol, col=gray.colors(100, start=0.9, end=0.3), main=filename)
  #title(filename)
  tree.rho <- ape::ladderize(phy=ape::as.phylo(hc), right=TRUE)
  ape::write.tree(phy=tree.rho, file=paste0(filename,".tre") )
}
dev.off()

sessionInfo()
Sys.time()
