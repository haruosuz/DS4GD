#' ---
#' title: "DATA SCIENCE FOR GENOME DYNAMICS"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

# Clear R's environment
rm(list = ls())

# Load the packages into R
#+ warning = FALSE
#+ message = FALSE
library(seqinr)
library(zoo)
library(Biostrings)
library(pwalign)
library(ape)

#' # 1. DNA Sequence Statistics (1)
#' ## 1-1. 
#' ### 1-1-1.
source("my_assignment/my_assignment_1_dna1.R")
#' 
#' # 2. DNA Sequence Statistics (2)
source("my_assignment/my_assignment_2_dna2.R")
#' 
#' # 4. Pairwise Sequence Alignment
#' ## 4-1. Download FASTA
#' ## 4-2. dotplot
#' ## 4-3. self-similarity dot-plot
#' ## 4-4. AlignGlobal_BLOSUM62
#' ## 4-5. writePairwiseAlignments
#' ## 4-6. AlignGlobal BLOSUM80 BLOSUM45
#' ## 4-7. AlignGlobal_BLOSUM62_gap
#' ## 4-8. AlignLocal_BLOSUM62
source("my_assignment/my_assignment_4_align.R")
#' 
#' # 5. Multiple Alignment and Phylogenetic trees
#' ## 5-1. genetic distances
#' ## 5-2. unrooted tree
#' ## 5-3. unrooted tree from trimmed alignment
#' ## 5-4. rooted tree from trimmed alignment
source("my_assignment/my_assignment_5_msa_tree.R")
#' 
#' # [R Packages (2e)](https://r-pkgs.org/)
#' ## [10.2 Namespace](https://r-pkgs.org/namespace.html)
#?count
#?dplyr::count
#?seqinr::count

#?translate
#?microseq::translate
#?Biostrings::translate
#?seqinr::translate

#?as.alignment
#?seqinr::as.alignment
#?ape::as.alignment

#' # References
#' - https://github.com/haruosuz/DS4GD/tree/master
#' - https://github.com/haruosuz/DS4GD/blob/master/CaseStudy.md
#' - [R Packages (2e)](https://r-pkgs.org/)
#'   - [10.2 Namespace](https://r-pkgs.org/dependencies-mindset-background.html#sec-dependencies-namespace)
#' - [Chapter 11 Namespace | R Packages](https://bookdown.dongzhuoer.com/hadley/r-pkgs/namespace)
#' 
#' # Print R version, OS and loaded packages.
sessionInfo()
Sys.time()
