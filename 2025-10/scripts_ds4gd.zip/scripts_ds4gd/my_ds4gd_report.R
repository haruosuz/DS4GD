#' ---
#' title: "DATA SCIENCE FOR GENOME DYNAMICS"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

# Clear R's environment
rm(list = ls())

# Load the packages into R
#+ warning = FALSE
#+ message = FALSE
library(seqinr)
library(zoo)
library(Biostrings)
library(pwalign)
library(ape)

#' # 1. 
#' ## 1-2. 
#' ### 1-2-3.
#' # DNA Sequence Statistics (1)
#' # DNA Sequence Statistics (2)
#' # Pairwise Sequence Alignment
#' # Multiple Alignment and Phylogenetic trees
#' # [R Packages (2e)](https://r-pkgs.org/)
#' ## [10.2 Namespace](https://r-pkgs.org/namespace.html)
#?count
#?dplyr::count
#?seqinr::count

#?translate
#?microseq::translate
#?Biostrings::translate
#?seqinr::translate

#?as.alignment
#?seqinr::as.alignment
#?ape::as.alignment

#' # References
#' - https://github.com/haruosuz/DS4GD/tree/master
#' - https://github.com/haruosuz/DS4GD/blob/master/CaseStudy.md
#' - [R Packages (2e)](https://r-pkgs.org/)
#'   - [10.2 Namespace](https://r-pkgs.org/dependencies-mindset-background.html#sec-dependencies-namespace)
#' - [Chapter 11 Namespace | R Packages](https://bookdown.dongzhuoer.com/hadley/r-pkgs/namespace)
#' 
#' # Print R version, OS and loaded packages.
sessionInfo()
Sys.time()
