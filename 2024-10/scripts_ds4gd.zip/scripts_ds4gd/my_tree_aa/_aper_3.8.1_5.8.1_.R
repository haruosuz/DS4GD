#' ---
#' title: "Inferring Phylogenetic Trees of rRNA Genes"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      theme: united
#'      highlight: tango
#'      toc: true
#' ---
#' 
# Clear R's environment
rm(list = ls())

# Load the required packages
#+ warning = FALSE
#+ message = FALSE
library(seqinr)
library(ape)
library(Biostrings)
library(msa)
#' - https://emmanuelparadis.github.io/PGR.html 4.3 Conversions
#' - https://emmanuelparadis.github.io/APER.html
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/fb8nrm/alma99186639204031
#' SpringerLink Books (Series & Reference Works)
#' 
#' Pages 29-80
#' 
#' # 3 Phylogenetic Data in R
#' ## 3.8 Case Studies
#' ### 3.8.1 Sylvia Warblers
#' Page 67
#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4008546/
#' 2014-01-14 | Ragan | Table 1. All 16S ribosomal rRNA sequences used in this study | (A) three kingdoms | (B) proteobacteria | 
#' - https://www.ncbi.nlm.nih.gov/nuccore/NC_010109.1/ Lemna minor chloroplast | *, positions 106162–107648.
#' - https://www.ncbi.nlm.nih.gov/nuccore/NR_074311.1?report=genbank Synechocystis sp. PCC 6803 strain PCC 6803 16S ribosomal RNA, complete sequence
#' - https://academic.oup.com/jcb/article/29/3/400/2548067
#' 2009-07-01 | Chen | Table 1
#' - https://www.ncbi.nlm.nih.gov/nuccore/EU493137 Macrobrachium asperulum voucher MAS00008 16S ribosomal RNA gene, partial sequence; mitochondrial
# create a vector of mode character with the accession numbers
AN_Ragan_A <- c("X00686.1", "V01335.1", "AF207023.1", "NR_074117.1", "NR_074174.1", "NR_074253.1", "NR_074260.1", "JQ282815", "M62791", "NR_103937.1", "NR_074311.1") # "NC_010109.1", 
AN_Ragan_B <- c("NR_074311.1", "NR_029215.1", "NR_074249.1", "D14513.1", "AF155147.1", "NR_036778.1", "NR_102804.1", "NR_074199.1", "NR_074828.1")
AN_Chen <- c("EU493137", "DQ194906", "EU493150", "DQ194919", "EU493147", "DQ194951", "EU493134", "DQ478566")
x <- AN_Ragan_A # three kingdoms 
#x <- AN_Ragan_B # proteobacteria
#x <- AN_Chen # mitochondrial
x
# Read DNA Sequences from GenBank via Internet
my.seq <- ape::read.GenBank(x)
# printing the returned object
my.seq
class(my.seq) # "DNAbin"
ape::write.FASTA(x=my.seq, file="my_nt.fasta")
# Page 68
my.taxa <- attr(my.seq, "species") # the names taken from the “ORGANISM” field in the GenBank data
Species <- sapply(strsplit(my.taxa, "_"), function(x) paste(x[1:2], collapse = "_"))
Accession <- names(my.seq)
Length <- sapply(as.character(my.seq), length)
GCcontent <- sapply(as.character(my.seq), GC)
# Creates data frame (table)
mydata <- data.frame(Accession, Species, Length, GCcontent)
str(mydata)
knitr::kable(x = mydata, caption = "Table 1. Sequence data.")

# 
myDNAStringSet <- Biostrings::readDNAStringSet("my_nt.fasta")
myname <- names(myDNAStringSet)

#' alignment with Clustal:
method <- "Muscle" # "ClustalW", "ClustalOmega", "Muscle"
myMsaDNAMultipleAlignment <- msa::msa(inputSeqs=myDNAStringSet, method=method)
my.seq.ali <- as.DNAbin(myMsaDNAMultipleAlignment)
#ape::image.DNAbin(x=my.seq.ali, what=c("g", "n"), col=c("black", "grey")) # Page 65
par(mar=c(5, 6, 4, 2)) # c(bottom, left, top, right)
image(my.seq.ali) # visualize the alignment
as.character(my.seq.ali)[,1:8] # From DNAbin To character # Page 62 # Table 3.4.
as.character(my.seq.ali[myname, ])[,1:8] # reordering the rows # Page 68

#' Pages 123-202
#' 
#' # 5 Phylogeny Estimation
#' ### 5.2.1 Substitution Models: A Primer
#' 
#' Page 141
#' 
#' #### Jukes and Cantor 1969 (JC69)
#' 
#' Page 142
#' 
#' #### Kimura 1980 (K80)
#' 
#' Page 145
#' 
#' #### Galtier and Gouy 1995
#' 
#' ## 5.8 Case Studies
#' 
#' Page 190
#' 
#' ### 5.8.1 Sylvia Warblers
#' 
#' A distance matrix can be estimated from the aligned sequences using
#' `dist.dna`; if the sequences are substantially incomplete, we use 
#' the option `pairwise.deletion = TRUE`:
d.K80 <- dist.dna(my.seq.ali, pairwise.deletion = TRUE)
#' the default model for this function is Kimura’s two-parameter one.
#' We use the option `model` to try different models:
d.F84 <- dist.dna(my.seq.ali, model = "F84", pairwise.deletion = TRUE)
d.TN93 <- dist.dna(my.seq.ali, model = "TN93", pairwise.deletion = TRUE)
d.GG95 <- dist.dna(my.seq.ali, model = "GG95", pairwise.deletion = TRUE)
#' A way to compare these distance matrices is simply to look at their 
#' correlations. We do this by binding all distances in a single matrix, 
#' and compute the correlations among its columns 
#' (the results are rounded to three digits):
round(cor(cbind(d.K80, d.F84, d.TN93, d.GG95)), 3)

#' This shows that the GG95 distances differ substantially from the others. Note 
#' that a perfect correlation does not guarantee that the distances are the same: 
#' some graphical analyses are needed to check this. We do this to examine the 
#' saturation of substitutions in the sequences. We first compute the distances 
#' using the JC69 model and the raw distance (i.e., proportion of different sites):
d.JC69 <- dist.dna(my.seq.ali, model = "JC69", pairwise.deletion = TRUE)
d.raw <- dist.dna(my.seq.ali, model = "raw", pairwise.deletion = TRUE)
#' We then plot these two distances expecting the raw distances to be smaller 
#' because they do not consider multiple substitutions; we also plot the 
#' Jukes–Cantor distance versus the Kimura one to show the potential influence 
#' of the transition/transversion ratio (Fig. 5.15):
layout(matrix(1:2, 1))
plot(d.JC69, d.raw); abline(b = 1, a = 0) # draw x=y line
plot(d.K80, d.JC69); abline(b = 1, a = 0)
#' Fig. 5.15. Saturation plots for the sequences 
#' showing the effects of multiple substitutions (left) and 
#' of the transition/transversion ratio (right)
#' 
#' These plots show, as expected, that the most divergent sequences are slightly 
#' saturated, whereas the transition/transversion ratio does not seem to affect 
#' the estimated distances greatly.
#' 
#' - https://www.frontiersin.org/journals/marine-science/articles/10.3389/fmars.2021.573853/full
#' exhibited a larger number of transversions than transitions together with increasing evolutionary distance (Figure 1B).
layout(1)
ts <- dist.dna(my.seq.ali, model = "TS", pairwise.deletion = TRUE) / ncol(my.seq.ali)
tv <- dist.dna(my.seq.ali, model = "TV", pairwise.deletion = TRUE) / ncol(my.seq.ali)
plot(x=d.K80, y=ts, type="n", ylim = range(c(ts, tv)), 
     xlab = "K80 distance", ylab = "Number of Ts or Tv")
points(x=d.K80, y=ts, pch="s", col = "blue")
points(x=d.K80, y=tv, pch="v", col = "red")
#' Page 192
#' 
#' A point we explore briefly is the impact of the choice of the substitution 
#' model on the phylogeny estimation with the NJ method. We estimate a tree 
#' with the function nj for the K80 and GG95 distance matrices:
nj.K80 <- nj(d.K80)
nj.GG95 <- nj(d.GG95)
#' Page 193
#' 
#' To see if the estimated topologies are similar, we compute the topological 
#' distance between them:
dist.topo(nj.K80, nj.GG95)

#' #### Saturation
#' - https://github.com/haruosuz/evolve/blob/master/references/README.evolve.jargon.md#saturation
tr <- nj.K80
d_patristic <- cophenetic(tr) # x
d_uncorrected <- d.raw # y
nms <- rownames(as.matrix(d_uncorrected))
d_patristic <- as.dist(d_patristic[nms, nms])
summary(as.vector(d_patristic))
summary(as.vector(d_uncorrected))
mylim <- range(d_patristic, d_uncorrected)
mymax <- max(d_patristic, d_uncorrected)
plot(d_patristic, d_uncorrected, xlim=c(0,mymax), ylim=c(0,1), xlab="#substitutions (patristic distances)", ylab="#differences (uncorrected distances)")
abline(a = 0, b = 1, col = "blue") # x=y line
#abline(h = 1, col = "red") # y=1 line
#fit <- lm(d_uncorrected ~ d_patristic); fit; coef(fit)[2]
fit <- lm(d_uncorrected ~ d_patristic - 1) # linear regressions performed through the origin (i.e., the intercept is set to zero).
fit
#summary(fit)

#' #### bootstrap
#' We choose to treat rooted trees, and so first identify the outgroup species
TF <- grepl("Synechocystis_", mydata$Species); mydata[TF,]
#' We then build a function that includes the `root` function in order to estimate 
#' the NJ tree including the rooting operation:
#f <- function(xx) root(nj(dist.dna(xx, p=TRUE)), "NR_074311.1")
f <- function(xx) phangorn::midpoint(nj(dist.dna(xx, p=TRUE)))
tr <- f(my.seq.ali)
tr <- ladderize(tr, right=FALSE)

nboot <- 100 # number of bootstrap replicates.
set.seed(1111)
nj.boot <- boot.phylo(tr, my.seq.ali, FUN=f, B=nboot, rooted=TRUE)
nj.boot

#' Page 194
#' 
#' #### Plot Phylogenies
#' plot the estimated tree by NJ with the bootstrap values on the nodes.
#' first copy the estimated tree and substitute the accession numbers 
#' (which were used as tip labels) with the species names:
nj.est <- tr

ape::write.dna(my.seq.ali, file="my_nt_msa.fasta", format="fasta")
ape::write.tree(nj.est, "my_nt_msa_nj.tre")

nj.est$tip.label <- mydata$Species[match(nj.est$tip.label, mydata$Accession)]
#nj.est$tip.label <- sapply(nj.est$tip.label, function(x) paste(mydata[grepl(pattern=x, x=mydata$Accession),c("Accession","Species")],collapse=" ") )
layout(1)
ape::plot.phylo(nj.est, no.margin = TRUE)
nodelabels(round(nj.boot / nboot, 2), bg = "white")
add.scale.bar() # length = 0.01
axisPhylo()
#' Fig. 5.17. Phylogenetic tree
#' Page 195
sessionInfo()
