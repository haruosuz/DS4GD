# 2024-10-27 # Haruo Suzuki # This script performs Substitution Saturation Analysis using alignment and tree files.
rm(list = ls()) # Clear R's environment
# Extract Command Line Arguments
args <- commandArgs(trailingOnly = TRUE); print(args)
mytype <- args[1]; file_aln <- args[2]; file_tre <- args[3]
# <my_tree_aa.R>
#mytype="AA"; file_aln="myAlign.fasta"; file_tre="myTree.tre"
# <_aper_3.8.1_5.8.1_.R>
#mytype="DNA"; file_aln="my_nt_msa.fasta"; file_tre="my_nt_msa_nj.tre"
# <pbs.bactopia.pirate.sh> #mytype="DNA"; file_aln="core_alignment.fasta.gz"; file_tre="core-genome.treefile"
#Rscript --vanilla ./my_saturation.R "${mytype}" "${file_aln}" "${file_tre}"
# Running the <my_saturation.R> script generates an output file <Rplots.pdf>.

# Load the packages into R
library(ape)
library(phangorn)

mytree <- ape::read.tree(file=file_tre)
myphyDat <- phangorn::read.phyDat(file=file_aln, format="fasta", type=mytype)
mydist.hamming <- phangorn::dist.hamming(myphyDat, exclude="pairwise")

#' ## Substitution Saturation Analysis
#' - https://github.com/haruosuz/evolve/blob/master/references/README.evolve.jargon.md#saturation
#' 
#' APER page 138: 
#' We have to insure that the distances are ordered in the same way in
#' `d_uncorrected` and in `d_patristic`. The latter is a matrix—
#' not an object of class `"dist"`—which helps to reorder its rows and columns:
d_patristic <- cophenetic(mytree) # x
d_uncorrected <- mydist.hamming # y
nms <- rownames(as.matrix(d_uncorrected))
d_patristic <- as.dist(d_patristic[nms, nms])
summary(as.vector(d_patristic))
summary(as.vector(d_uncorrected))
mylim <- range(d_patristic, d_uncorrected)
mymax <- max(d_patristic, d_uncorrected)
plot(d_patristic, d_uncorrected, xlim=c(0,mymax), ylim=c(0,1), xlab="#substitutions (patristic distances)", ylab="#differences (uncorrected distances)")
abline(a = 0, b = 1, col = "blue") # x=y line
#abline(h = 1, col = "red") # y=1 line
#fit <- lm(d_uncorrected ~ d_patristic); fit; coef(fit)[2]
fit <- lm(d_uncorrected ~ d_patristic - 1) # linear regressions performed through the origin (i.e., the intercept is set to zero).
fit
#summary(fit)
sessionInfo()
