# Haruo Suzuki
# 2024-09-18
# This script visualizes a tree with multiple sequence alignments.
# First, run `my_tree_aa.R` to generate the "myAlign.fasta" and "myTree.tre" files needed for this script.

# Clear R's environment
rm(list = ls())

# Load the packages into R
library(ape)
library(ggtree)

myAlignAA <- ape::read.FASTA(file="myAlign.fasta", type="AA")
mytree <- read.tree(file="myTree.tre")
p <- ggtree(mytree) + geom_tiplab(size=3)
ggtree::msaplot(p=p, fasta=myAlignAA, offset=1.7, width=3)

#' # References
#' - https://cran.r-project.org/package=TDbook
#' - https://yulab-smu.top/treedata-book/chapter7.html
#' - https://yulab-smu.top/treedata-book/chapter7.html#msaplot
#' - https://guangchuangyu.github.io/treedata-workshop/r-ggtree-annotation.html

sessionInfo()
