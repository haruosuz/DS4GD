#+ echo = TRUE
rm(list = ls())
#+ message = FALSE
library(seqinr)

#' - https://github.com/haruosuz/introBI/blob/master/2020/CaseStudy.md#ncbi-genome-list
#' 
#' - https://github.com/haruosuz/DS4GD/tree/master/2023-04
#' - https://github.com/haruosuz/DS4GD/blob/master/2021/CaseStudy.md#ncbi-genome-list
#' - https://github.com/haruosuz/DS4GD/blob/master/2019giga/CaseStudy.md#ncbi-assembly_reports
#' 
#' - https://www.ncbi.nlm.nih.gov/genome/doc/ftpfaq/
#' Genomes Download FAQ
#' 
#' - https://www.ncbi.nlm.nih.gov/genome/doc/ftpfaq/#howtofind
#' How can I find the sequence and annotation of my genome of interest?
#' 
#' - ftp.ncbi.nlm.nih.gov/genomes/ASSEMBLY_REPORTS/
# Download File from the Internet
url <- "ftp://ftp.ncbi.nlm.nih.gov/genomes/ASSEMBLY_REPORTS/assembly_summary_refseq.txt" # 88M
url <- "ftp://ftp.ncbi.nlm.nih.gov/genomes/ASSEMBLY_REPORTS/assembly_summary_genbank.txt" # 510M
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)
d <- read.delim(file=filename, skip=1, check.names=FALSE, stringsAsFactors=FALSE)
dim(d)
colnames(d)
table(d$assembly_level)

#' - https://www.ncbi.nlm.nih.gov/assembly/GCA_009858895.3
#' Organism name: Severe acute respiratory syndrome coronavirus 2 (viruses)
#' FTP directory for GenBank assembly
#' 
#' - https://www.ncbi.nlm.nih.gov/genome/doc/ftpfaq/#allcomplete
#' How can I download RefSeq data for all complete bacterial genomes?
#' List the FTP path (column 20) for the assemblies of interest, in this case those that have "Complete Genome" assembly_level (column 12) and "latest" version_status (column 11). 
# grepl returns a logical vector (match or not for each element of x)
organism_name <- "Dengue virus"
organism_name <- "Severe acute respiratory syndrome coronavirus 2"
organism_name <- "Ideonella sakaiensis"
TF <- grepl(pattern = organism_name, x = d$organism_name, ignore.case = TRUE) & d$version_status == "latest" & grepl(pattern = "Complete Genome", x = d$assembly_level)
summary(TF)

#' - https://www.ncbi.nlm.nih.gov/genome/doc/ftpfaq/#files
#' What is the file content within each specific assembly directory?
# Download File from the Internet
filesuffix <- "_genomic.fna.gz"
#filesuffix <- "_cds_from_genomic.fna.gz"
url <- paste0(d$ftp_path[TF], "/", unlist(strsplit(d$ftp_path[TF], split="/"))[10], filesuffix )
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)
#if(!file.exists(filename)){ download.file(url = url, destfile = filename); untar(tarfile = filename, exdir = "APER2_Online_Material") }

seqs <- read.fasta(file=filename, seqtype="DNA", strip.desc=TRUE)
#write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=paste0(ACCESSION,".fasta") )

seq1 <- seqs[[1]]
getAnnot(seq1) # Get sequence annotations

#' # References
#' 

#getwd()
#list.files()
#sessionInfo()
#Sys.time()

