#' ---
#' title: "DS4GD_newick"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

rm(list = ls())
library(ape)
#?plot.phylo

#' # newick
#' - https://en.wikipedia.org/wiki/Newick_format
#?ape::read.tree
#layout(matrix(1:4, 2, 2))

nwk <- "((A,B,C),D);"
mytree <- read.tree(text=nwk); plot(mytree, main=nwk)

nwk <- "((A:0.05,B:0.2,C:0.1):0.3,D:0.4);"
mytree <- read.tree(text=nwk); plot(mytree, main=nwk)

nwk <- "((A:0.05,B:0.2,C:0.1)Ancestor:0.3,D:0.4)Root;"
mytree <- read.tree(text=nwk); plot(mytree, main=nwk)
nodelabels(mytree$node.label)
add.scale.bar()
axisPhylo()
names(mytree)

#' - https://jlsteenwyk.com/PhyKIT/usage/index.html#patristic-distances
#' Patristic distances are all tip-to-tip distances in a phylogeny.
cophenetic(mytree)

#' # rotate
#' - https://yulab-smu.top/treedata-book/faq.html#branch-setting
#?ape::ladderize
layout(matrix(1:4, 2, 2))
nwk <- "(E, ((C, (A, B)), D));"
nwk <- "(Fishes, ((Lizards, (Chimps, Humans)), Frogs));"
mytree <- read.tree(text=nwk); plot(mytree, main="initial")
mytree <- ladderize(mytree, right=TRUE); plot(mytree, main="right-ladderized")
mytree <- ladderize(mytree, right=FALSE); plot(mytree, main="left-ladderized")
mytree <- rotateConstr(mytree, constraint=read.tree(text=nwk)$tip.label); plot(mytree, main="rotateConstr")
write.tree(mytree)
#write.tree(mytree, file="myNewick.tre")
#read.tree(file="myNewick.tre")
#' - https://doua.prabi.fr/software/seaview
#'   - macOS X https://doua.prabi.fr/software/seaview_data/seaview5.zip
#'   - MS Windows https://doua.prabi.fr/software/seaview_data/seaview5.exe
#' - http://tree.bio.ed.ac.uk/software/figtree/
#' Compiled binaries (for Mac, Windows and Linux) are available from the FigTree GitHub repository.
#' 
#' # root
#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7149615/ 
#' Encyclopedia of Evolutionary Biology. 2016 : 489–493. Rooting Trees, Methods for
#' - https://phylobotanist.blogspot.com/2015/01/how-to-root-phylogenetic-tree-outgroup.html
#' - https://cabbagesofdoom.blogspot.com/2012/06/how-to-root-phylogenetic-tree.html
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/188bto4/alma99275963904031
#' Welcome to the Microbiome
#' - https://www.brh.co.jp/research/formerlab/miyata/2005/post_000008.php
#?ape::root
layout(matrix(1:4, 2, 2))
nwk <- "(Eukarotes, Archaea, Bacteria);"
mytree <- read.tree(text=nwk)
mytype <- "unrooted"; plot(mytree, type=mytype, main=mytype)

outgroups <- c("Eukarotes", "Archaea", "Bacteria")
for (myog in outgroups) {
  mytree <- ape::root(mytree, outgroup=myog, resolve.root=TRUE)
  plot(mytree, main=paste("outgroup:", myog))
}
#is.rooted(mytree)

#' # monophyletic
#' - https://en.wikipedia.org/wiki/Monophyly
#' - https://en.wikipedia.org/wiki/Paraphyly
#' ![https://www.numerade.com/ask/question/the-phylogenetic-tree-below-shows-the-relationship-between-bacteria-archaea-and-eukaryotes-select-the-wrong-statement-about-the-tree-from-the-following-bacteria-prokaryotes-archaea-eukaryote-78113/](https://cdn.numerade.com/ask_images/da888612ab4943e3acffead35b71f637.jpg)
#ape::is.monophyletic(phy = mytree, tips = c("Archaea", "Bacteria"))

#' # sister
#' - https://ja.wikipedia.org/wiki/姉妹群
#' - https://en.wikipedia.org/wiki/Sister_group
#' - CAMPBELL BIOLOGY; [Phylogeny and the Tree of Life](https://www.maruzen-publishing.co.jp/files/書籍営業部/講義用資料/2018/キャンベル11授業用パワポサンプル26_Lecture_Presentation.pdf)
#' Sister taxa are groups that share an immediate common ancestor that is not shared by any other group
#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6893154/
#'   - Perissodactyla (odd-toed ungulates) as a sister group to Cetartiodactyla (even-toed ungulates) (fig. 3a 
#'   - Perissodactyla as the sister group to the clade that contains Carnivora + Pholidota with 49% bootstrap support (fig. 3b 
#' ![](https://cdn.ncbi.nlm.nih.gov/pmc/blobs/da16/6893154/bc7ae9b772e6/evz193f3.jpg)
# Print R version, OS and loaded packages.
sessionInfo()
Sys.time()
