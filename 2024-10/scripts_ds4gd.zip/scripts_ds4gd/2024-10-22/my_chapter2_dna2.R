#' ---
#' title: "[Little Book of R for Bioinformatics](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan)"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---

# clear the decks
rm(list = ls())

#' ## [DNA配列の統計 (2)](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#dna-sequence-statistics-2)
#' ## [DNA Sequence Statistics (2)](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html)
#' ### [A little more introduction to R](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#a-little-more-introduction-to-r)
#' **続・R言語入門**

# log10() function to calculate the log to the base 10 of a scalar variable x
x <- 100
log10(x)

# mean() function to calculate the average of the values in a vector variable myvector:
myvector <- c(1,3,5,7,9)
mean(myvector)

# get the value of the 3rd element in the vector myvector
myvector[3]

#' - R for Data Science | 4 Workflow: basics | [4.3 Calling functions](https://r4ds.had.co.nz/workflow-basics.html#calling-functions)
#' 
#' `seq()` makes regular sequences of numbers
# create the sequence of numbers from 1-10 in steps of 1
seq(from=1, to=10, by=1)
1:10

# create a sequence of numbers from 1-10 in steps of 2
seq(from=1, to=10, by=2)

#' - biostatistics | R | 基礎編 | [繰返処理 | R で繰り返し処理を行う for 文と while 文について](https://stats.biopapyrus.jp/r/basic/loop-flow.html)  
#' - R for Data Science | 21 Iteration | [21.2 For loops](https://r4ds.had.co.nz/iteration.html?q=loop#for-loops)
#' 
#' for による繰り返し
# for loop to carry out the same command several times

# print out the square of each number between 1 and 10
for (i in 1:10) { print (i*i) }

# give a for loop a vector of numbers containing the values 2, 9, 100, and 133
myvector <- c(2, 9, 100, 133)
for (i in myvector) { print (i*i) }

# print out the square of every second number between 1 and 10
for (i in seq(from=1, to=10, by=2)) { print (i*i) }

#' - 2020-01-27 津田裕之 [6 図の作成 | Rによる統計入門](https://htsuda.net/stats/plot.html)  
#' - 2019/2/2 Sakai Masayuki [R plot()による可視化まとめ](http://rstudio-pubs-static.s3.amazonaws.com/463756_d4d86812878b476f9bdae2f55042f50e.html)  
#' - [Scatterplot | the R Graph Gallery](https://r-graph-gallery.com/scatterplot.html)
#' - [All Graphics in R (Gallery) | Plot, Graph, Chart, Diagram, Figure Examples](https://statisticsglobe.com/graphics-in-r#scatterplot)
#' 
# plot a scatterplot of the values in v1 against the values in v2
v1 <- 1:5
v2 <- 5:1
#plot(v1, v2)
plot(x=v1, y=v2, xlab="x", ylab="y")
# type: "p" for points, "l" for lines, "b" for both,
plot(x=v1, y=v2, xlab="x", ylab="y", type="b")

#' `＃`の後が[コメント](http://yusuke-memo.blogspot.jp/2009/10/r.html)行となる。
# writing the comment text after the “#” sign
x <- 100
log10(x) # Finds the log to the base 10 of variable x.

#' ### [Reading sequence data with SeqinR](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#reading-sequence-data-with-seqinr)
#' **Rパッケージ`seqinr`で配列データを読み込み**
#' 
# reading the genome sequence
library("seqinr") # Load the SeqinR package
ACCESSION <- "NC_001477" # Dengue virus 1
#ACCESSION <- "NC_045512" # SARS-CoV-2
filename <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text")
#filename <- paste0("http://togows.org/entry/nucleotide/",ACCESSION,".fasta")
#ape::write.FASTA(x=ape::read.GenBank(ACCESSION), file="myNT.fasta"); filename <- "myNT.fasta"
seq1 <- read.fasta(file=filename, seqtype="DNA", strip.desc=TRUE)[[1]]

# obtain nucleotides 452-535 of DNA sequence stored in the vector `seq1`
seq1[452:535]

# GC content of DNA sequence stored in the vector `seq1`
GC(seq1)

#' ### [Local variation in GC content](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#local-variation-in-gc-content)
#' **GC含量の局所変動**
#' は、[遺伝子の水平伝播](https://ja.wikipedia.org/wiki/遺伝子の水平伝播) [horizontal gene transfer](https://en.wikipedia.org/wiki/Inferring_horizontal_gene_transfer) や変異バイアス [mutation bias](https://en.wikipedia.org/wiki/Mutation_bias) を示唆
#' 
#' ### [A sliding window analysis of GC content](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#a-sliding-window-analysis-of-gc-content)
#' **GC含量のスライディングウィンドウ解析**

GC(seq1[1:2000])      # 塩基配列の 1-2000 番目のGC含量
GC(seq1[2001:4000])   # 塩基配列の 2001-4000 番目のGC含量
GC(seq1[4001:6000])   # 塩基配列の 4001-6000 番目のGC含量
GC(seq1[6001:8000])   # 塩基配列の 6001-8000 番目のGC含量
GC(seq1[8001:10000])  # 塩基配列の 8001-10000 番目のGC含量
GC(seq1[10001:10735]) # 塩基配列の 10001-10735 番目のGC含量

#' 配列を固定長（ここでは 2000 bp）の断片に分け、各配列断片のGC含量を計算する。このような方法はスライディングウィンドウ（sliding window）と呼ばれ、配列断片のサイズはウィンドウサイズ（window size）、配列断片を移動させるサイズはステップサイズ（step size）と呼ばれる。
#' 
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/fb8nrm/alma9926580096704034
#' よくわかるバイオインフォマティクス入門
#' p. 86: GC skew
#' - https://en.wikipedia.org/wiki/GC_skew
#' 
#' `zoo`パッケージを用いて、異なるウィンドウサイズ（2000, 3000, 300 bp）でスライディングウィンドウ解析を実行し、プロットする。
#' 
#install.packages("zoo")
library(zoo)
window_size <- 2000
#window_size <- 3000
#window_size <- 300
x <- seq(from = 1, to = length(seq1)-window_size, by = window_size)
y <- rollapply(data = seq1, width = window_size, by = window_size, FUN = GC)
par(family="mono")
plot(x, y, type="b", xlab="Position (bp)", ylab="GC content")

#' - 2010 [Mean of a sliding window in R - Cross Validated](http://stats.stackexchange.com/questions/3051/mean-of-a-sliding-window-in-r)
#' - 2010-08-31 [ベクトルの一定範囲に関数を適用しながら逐次計算していく（ローリング処理）](http://d.hatena.ne.jp/teramonagi/20100831/1283261344)
#' 
#' ### [Over-represented and under-represented DNA words](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#over-represented-and-under-represented-dna-words)
#' **k連続塩基(k-mer)の出現頻度の偏り**
#' 
#' - [Rで塩基配列解析2](https://www.iu.a.u-tokyo.ac.jp/~kadota/20170424_kadota.pdf)
#' k連続塩基(k-mer)解析 | 比較ゲノム解析 | アセンブル（ゲノムやトランスクリプトーム） | モチーフ解析 | 発現量推定
#' - [K-merとは?](https://nishi2.info/bioinfo/post/DNA_Analysis/Kmer.html)
#' - https://en.wikipedia.org/wiki/K-mer
#' - https://ja.wikipedia.org/wiki/オリゴヌクレオチド
#' - https://en.wikipedia.org/wiki/Oligonucleotide
#' - https://en.wikipedia.org/wiki/Genomic_signature
#' - [ゲノムサインとその生物学的な意味の解明](http://bioinfo.ie.niigata-u.ac.jp/?ゲノムサインとその生物学的な意味の解明)
#' 
#' <img alt="https://en.wikipedia.org/wiki/K-mer" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/K-mer_diagram.svg/440px-K-mer_diagram.svg.png" width=20%>
#' 
# Count oligomers (monomer/dimer/trimer/etc)
count(seq = seq1, wordsize = 2)

# odds ratio (rho statistic) is the ratio of the observed to expected frequency of oligonucleotides
rho(sequence = seq1, wordsize = 2)

#' k連続塩基(k-mer)のρ統計量 (オッズ比 = 観測値 / 期待値) を計算する。  
#' 2連続塩基(2-mer)の場合、次の通り計算される:  
#' 
#' ρ(xy) = f<sub>xy</sub> / (f<sub>x</sub> * f<sub>y</sub>),
#' 
#' ここで、f<sub>xy</sub>, f<sub>x</sub>, f<sub>y</sub>は、DNA配列中の文字列"xy", "x", "y"の頻度である。
#' 
#' 例えば、2連続塩基"CG"のρ値の計算式は:  
#' 
#' ρ(CG) = f<sub>CG</sub> / (f<sub>C</sub> * f<sub>G</sub>),
#' 
#' ここで、f<sub>CG</sub>, f<sub>C</sub>, f<sub>G</sub>は、DNA配列中の文字列"CG", "C", "G"の頻度である。
#' 
#' #### CpG
#' - https://en.wikipedia.org/wiki/CpG_site
#' - https://ja.wikipedia.org/wiki/CpGアイランド
#' - https://www.yodosha.co.jp/jikkenigaku/keyword/480.html
#' CpGアイランド
#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8844275/
#' Sci Rep. 2022 Feb 14;12(1):2420.
#' The low abundance of CpG in the SARS-CoV-2 genome is not an evolutionarily signature of ZAP
#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7454914/
#' Virus Evol. 2020 Aug 13;6(2):veaa057.
#' Intra-genome variability in the dinucleotide composition of SARS-CoV-2
#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7378049/
#' Sci Rep. 2020 Jul 23;10(1):12331.
#' Human SARS-CoV-2 has evolved to reduce CG dinucleotide in its open reading frames
#' - https://pubmed.ncbi.nlm.nih.gov/9461383/
#' Gene. 1997 Dec 31;205(1-2):103-7.
#' CpG distribution patterns in methylated and non-methylated species
#' T S Shimizu 1, K Takahashi, M Tomita
#' 
#' ### [Summary](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#summary)

#?seq() # creating a sequence of numbers
#?print() # printing out the value of a variable
#?plot() # making a plot (eg. a scatterplot)

#' ### [Links and Further Reading](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#links-and-further-reading)
#' 
#' ### [Exercises](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#exercises)
#' **演習**
#' [回答例](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#dna-sequence-statistics-2)
#' 
sessionInfo()
