#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#dna-sequence-statistics-1

# seqinr パッケージを R に読み込む
# Load the seqinr package into R
library("seqinr")

# DNA配列のテストデータを作成する（`seqinr`パッケージの`s2c`関数は文字列を文字ベクトルに変換する）
# Create test data for a DNA sequence (convert a single string into a vector of characters using the `s2c` function of the `seqinr` package)
myseq <- s2c("acgt")

# Rオブジェクト（文字ベクトル）の内容を表示する
# Print out the content of the R object (a vector of characters)
myseq

# DNA配列の長さ（ベクトル内の要素数）を計算する
# Calculate the length of the DNA sequence (number of elements in the vector)
length(myseq)

# DNA配列の塩基組成（ベクトル内のユニークな文字数）を計算する
# Calculate the base composition of the DNA sequence (number of unique characters in the vector)
table(myseq)

# DNA配列のGC含量 [(G+C)/(A+C+G+T)] を計算する
# Calculate the GC content of the DNA sequence [(G+C)/(A+C+G+T)]
GC(myseq)

# 2連続塩基（2-mer）頻度を数える
# Count dinucleotide (2-mer) frequencies in the sequence
count(myseq, wordsize = 2)

