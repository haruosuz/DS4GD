#' ---
#' title: "[Little Book of R for Bioinformatics](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan)"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

# Clear R's environment
rm(list = ls())

# Load the packages into R
library(seqinr)
library(Biostrings)
library(pwalign)

#' ## [ペアワイズ配列アラインメント](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#pairwise-sequence-alignment)
#' ## [Pairwise Sequence Alignment](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html)
#' 
#' **[2本の配列間でのアラインメント](https://ja.wikipedia.org/wiki/シーケンスアラインメント#ペアワイズアラインメント)**
#' 
#' ![https://ja.wikipedia.org/wiki/シーケンスアラインメント](https://upload.wikimedia.org/wikipedia/commons/8/86/Zinc-finger-seq-alignment2.png)
#' 
#' [変異](https://ja.wikipedia.org/wiki/突然変異)
#' [Mutation](https://en.wikipedia.org/wiki/Mutation)
#' 
#' ### [UniProt](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#uniprot)
#' 
#' - https://twitter.com/uniprot
#' - https://www.youtube.com/c/uniprotvideos
#' - https://ja.wikipedia.org/wiki/Swiss-Prot
#' - 2017.09.12 UniProtを使って、タンパク質のアミノ酸配列とその機能情報を横断的・網羅的に調べる | TogoTV 
#' https://doi.org/10.7875/togotv.2017.087
#' 
#' ### [Viewing the UniProt webpage for a protein sequence](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#viewing-the-uniprot-webpage-for-a-protein-sequence)
#' 
#' At the top of the UniProt website (http://www.uniprot.org), you will see a search box, and 
#' you can type the UniProt accession of the protein in this search box, 
#' and then click on the "Search" button to search for it.  
#' タンパク質配列を検索するには、UniProtウェブサイト (http://www.uniprot.org) にアクセスし、
#' ウェブページ上部の検索ボックスに UniProt accession を入力して、"Search"ボタンを押す。
#' 
#' ### [Retrieving a UniProt protein sequence via the UniProt website](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#retrieving-a-uniprot-protein-sequence-via-the-uniprot-website)
#' **UniProtのウェブサイトからタンパク質配列を取得**
#' 
#' Let's retrieve the protein sequences 
#' for the chorismate lyase protein from *Mycobacterium leprae* (UniProt accession "Q9CD83") and 
#' for the chorismate lyase protein from *Mycobacterium ulcerans* (UniProt accession "A0PQ23"), 
#' and save them as FASTA-format files (e.g., "Q9CD83.fasta" and "A0PQ23.fasta", respectively).
#' 
#' [ハンセン病（Leprosy）](https://ja.wikipedia.org/wiki/ハンセン病)の原因細菌[*Mycobacterium leprae*（らい菌）](https://ja.wikipedia.org/wiki/らい菌)と
#' [ブルーリ潰瘍（Buruli ulcer）](https://ja.wikipedia.org/wiki/ブルーリ潰瘍)の原因細菌[*Mycobacterium ulcerans*](http://www.nih.go.jp/niid/ja/diseases/ha/buruli-ulcer/1366-idsc/iasr-topic/1793-dj3863.html)
#' の[コリスミ酸リアーゼ](https://ja.wikipedia.org/wiki/コリスミ酸リアーゼ)タンパク質配列（UniProt accession は[Q9CD83](http://www.uniprot.org/uniprot/Q9CD83)と[A0PQ23](http://www.uniprot.org/uniprot/A0PQ23)）
#' をFASTA形式（ファイル名"Q9CD83.fasta"と"A0PQ23.fasta"）で保存する。
#' 
#' `read.fasta()`関数で、FASTAファイルをRに読み込む:
#' 
#library(seqinr)
#chars1 <- read.fasta(file = "Q9CD83.fasta")[[1]]
#chars2 <- read.fasta(file = "A0PQ23.fasta")[[1]]
#chars1 # Display the contents of the vector of chars

#' ### [Retrieving a UniProt protein sequence using SeqinR](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#retrieving-a-uniprot-protein-sequence-using-seqinr)
#' **SeqinRでUniProtのタンパク質配列を取得**
#' 
#' [Programmatic access | UniProt help | UniProt](https://www.uniprot.org/help/programmatic_access)

#library(seqinr)
chars1 <- read.fasta(file = "http://www.uniprot.org/uniprot/Q9CD83.fasta", seqtype = "AA")[[1]]
chars2 <- read.fasta(file = "http://www.uniprot.org/uniprot/A0PQ23.fasta", seqtype = "AA")[[1]]
chars1 # Display the contents of the vector of chars

#' ### [Comparing two sequences using a dotplot](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#comparing-two-sequences-using-a-dotplot)
#' **ドットプロットで2本の配列を比較**
#' 
#' タンパク質のアミノ酸配列や核酸の塩基配列の
#' [相同性](https://ja.wikipedia.org/wiki/相同)
#' [Sequence homology](https://en.wikipedia.org/wiki/Sequence_homology)
#' （共通の祖先に由来すること）を配列類似性に基づいて判断する。  
#' 
#' ヒトの[血小板由来成長因子](https://ja.wikipedia.org/wiki/血小板由来成長因子) (Platelet-Derived Growth Factor, PDGF) と 
#' [サル肉腫ウイルスの癌遺伝子 v-sis](https://www.wikigenes.org/e/mesh/e/21827.html) のアミノ酸配列は類似性が高い。
#' ([Science. 1983 "Simian sarcoma virus onc gene, v-sis, is derived from the gene (or genes) encoding a platelet-derived growth factor"](https://www.ncbi.nlm.nih.gov/pubmed/6304883))
#' 
#' [Dot plot |
#' For a simple visual representation of the similarity between two sequences, 
#' individual cells in the matrix can be shaded black if residues are identical, 
#' so that matching sequence segments appear as runs of diagonal lines across the matrix.
#' ](https://en.wikipedia.org/wiki/Dot_plot_%28bioinformatics%29)  
#' [ドットプロット](https://ja.wikipedia.org/wiki/ドットプロット_%28バイオインフォマティクス%29)
#' とは、2本の配列を比較するためのグラフである。
#' 両軸に全く同じ配列をとれば、右上がりの対角線が現れる。
#' 
#' Create a dotplot of the sequences for the chorismate lyase proteins from *M.leprae* and *M.ulcerans*:  
#' *M.leprae*と*M.ulcerans*のコリスミ酸リアーゼのタンパク質配列のドットプロットを作成する:  
par(mfrow=c(1,1))
dotPlot(chars1, chars2)

#' ### [Pairwise global alignment of DNA sequences using the Needleman-Wunsch algorithm](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#pairwise-global-alignment-of-dna-sequences-using-the-needleman-wunsch-algorithm)
#' **2本のDNA配列間の大域アラインメント**
#' 
#' [**大域アラインメントと局所アラインメント**](https://ja.wikipedia.org/wiki/シーケンスアラインメント#グローバルアラインメントとローカルアラインメント)
#' [*global* alignment and *local* alignment](https://towardsdatascience.com/pairwise-sequence-alignment-using-biopython-d1a9d0ba861f)
#' 
#' ![https://www.researchgate.net/figure/Global-and-local-alignments-of-a-pair-of-DNA-sequences_fig2_224580735](https://www.researchgate.net/profile/Nicola-Conci/publication/224580735/figure/fig2/AS:667774481346569@1536221251343/Global-and-local-alignments-of-a-pair-of-DNA-sequences.png)
#' 
#' 【例題】DNA配列 ("ATTGC"と"ATGC") 間の最適な大域アラインメントを見つける。
#' 
#' 例えば、塩基の一致 (match) に+2のスコア、不一致 (mismatch) に-1のペナルティ、ギャップ (gap) に-2のペナルティを与える。
#' 以下のアラインメントのスコアは？
#' 
#' ```
#' # give a score of +2 to a match and a penalty of -1 to a mismatch, and a penalty of -2 to a gap.
#' 
#' # The score for the following alignment is 2 + 2 + (-1) + (-1) + (-2) = 0:
#' ATTGC
#' ATGC-
#' 
#' # What is the score for the following alignment?
#' ATTGC
#' AT-GC
#' 
#' # What is the score for the following alignment?
#' ATTGC
#' A-TGC
#' ```
#' 
#' ![https://bi.biopapyrus.jp/seq/alignment/needleman%E2%80%93wunsch.html](https://bi.biopapyrus.jp/media/nw-001.png)
#' ![https://bi.biopapyrus.jp/seq/alignment/needleman%E2%80%93wunsch.html](https://bi.biopapyrus.jp/media/nw-005.png)
#' 
#' *scoring matrix (substitution matrix)*
#' [置換行列 | スコアマトリックスの作り方](https://bi.biopapyrus.jp/seq/score-matrix.html)
#' 
#' [`pwalign`](https://bioconductor.org/packages/pwalign/)
#' パッケージの`nucleotideSubstitutionMatrix()`関数でスコアマトリックス（置換行列）を作る:  
#' 
# make a scoring matrix which assigns a score of +2 to a match and -1 to a mismatch:
sigma <- pwalign::nucleotideSubstitutionMatrix(match = 2, mismatch = -1, baseOnly = TRUE)
sigma # Print out the matrix

#' <img alt="http://csbio.unc.edu/mcmillan/Comp555S16/Lecture14.html" src="http://csbio.unc.edu/mcmillan/Comp555S16/Media/AffineGapPenalties.png" width=50%>
#' http://csbio.unc.edu/mcmillan/Comp555S16/Lecture14.html
#' 
#' - [Gap penalty](https://en.wikipedia.org/wiki/Gap_penalty)
#' - [ClustalW ヘルプ | DDBJ](https://www.ddbj.nig.ac.jp/services/clustalw.html)
#' 
#' ギャップの最初の位置には、
#' ギャップ開始時のペナルティ *gap opening penalty* と
#' ギャップ継続時のペナルティ *gap extension penalty* を与える。
#' 隣接するギャップは一回の挿入・欠失で生じたと考える。
#' 
#' Instead of assigning the same penalty (eg. -8) to every gap position, 
#' it is common instead to assign a gap opening penalty to the first position in a gap (eg. -8), 
#' and a smaller gap extension penalty to every subsequent position in the same gap.
#' The reason for doing this is that it is likely that adjacent gap positions were created 
#' by the same insertion or deletion event, rather than 
#' by several independent insertion or deletion events. 
#' 
#' `pwalign::pairwiseAlignment()`関数で、DNA配列 ("ATTGC"と"ATGC") 間の最適な大域アラインメントを見つける:  

# print out the optimal global alignment for the two sequences and its score:
P1NT <- "ATTGC"
S1NT <- "ATGC"
#library(seqinr); dotPlot(s2c(P1NT), s2c(S1NT))
AlignGlobalNT <- pwalign::pairwiseAlignment(P1NT, S1NT, substitutionMatrix = sigma, 
                  gapOpening = 10, gapExtension = 4, scoreOnly = FALSE)
AlignGlobalNT # Print out the optimal alignment and its score

#' Note that we set “gapOpening” to be 10 and “gapExtension” to be 4, 
#' which means that the first position of a gap is assigned a score of (-10-4=)-14, 
#' and every subsequent position in a gap is given a score of -4.  
#' Here the alignment contains four matches, no mismatch, and one gap of length 1, 
#' so its score is (4\*2)+(0\*-1)+(1\*-14) = -6.
#' 
#' 【注意】gapOpening = 10, gapExtension = 4 は、
#' ギャップの最初の位置は (-10-4=)-14 のスコアが割り当てられ、
#' ギャップの後続の位置は -4 のスコアが与えられることを意味する。  
#' このアラインメントは、4個の一致 (match)、0個の不一致 (mismatch)、
#' 長さ1の1個のギャップ (gap) が含まれているので、
#' スコアは (4\*2)+(0\*-1)+(1\*-14) = -6 となる。
#' 
#' ### [Pairwise global alignment of protein sequences using the Needleman-Wunsch algorithm](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#pairwise-global-alignment-of-protein-sequences-using-the-needleman-wunsch-algorithm)
#' **2本のタンパク質配列間の大域アラインメント**
#' 
#' アミノ酸置換行列 [BLOSUM (BLOcks SUbstitution Matrix)](https://en.wikipedia.org/wiki/BLOSUM)
#' BLOSUM62 is the default matrix for protein BLAST.
#' BLOSUM80 is used for more closely related alignments, and 
#' BLOSUM45 is used for more distantly related alignments.
#' 
#'- [Codes Used in Sequence Description | Amino Acid](https://www.ddbj.nig.ac.jp/ddbj/code-e.html#amino)

# The physico-chemical classes for amino acids are given in 
#SEQINR.UTIL$AA.PROPERTY

# get a list of the available scoring matrices that come with the `pwalign` package:
#data(package="Biostrings")
#data(package="pwalign")
data("BLOSUM50") # load the BLOSUM50 matrix
BLOSUM50 # Print out the data

#' タンパク質配列 ("PAWHEAE"と"HEAGAWGHEE") 間の最適な大域アラインメントを見つける:  

# find the optimal global alignment between two protein sequences using the BLOSUM50 matrix:
P1AA <- "PAWHEAE"
S1AA <- "HEAGAWGHEE"
#library(seqinr); dotPlot(s2c(P1AA), s2c(S1AA))
AlignGlobalAA <- pwalign::pairwiseAlignment(P1AA, S1AA, substitutionMatrix = "BLOSUM50", 
                  gapOpening = 10, gapExtension = 4, scoreOnly = FALSE)
AlignGlobalAA # Print out the optimal global alignment and its score

#' The gap (`---`) will be given a score of (-10-4) -4 -4 = -22.
#' 
#' ギャップ (`---`) は (-10-4) -4 -4 = -22 のスコアが与えられる。

BLOSUM50["P","H"] +   (-10-4) -4 -4   + BLOSUM50["A","A"] + BLOSUM50["W","W"] + 
BLOSUM50["H","G"] + BLOSUM50["E","H"] + BLOSUM50["A","E"] + BLOSUM50["E","E"]

#' ### [Aligning UniProt sequences](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#aligning-uniprot-sequences)
#' **UniProt配列のアラインメント**

#library(seqinr)
chars1 <- read.fasta(file = "http://www.uniprot.org/uniprot/Q9CD83.fasta")[[1]]
chars2 <- read.fasta(file = "http://www.uniprot.org/uniprot/A0PQ23.fasta")[[1]]

# 文字ベクトルを文字列に変換
# conversion of a vector of chars into a string
string1 <- c2s(chars1)
string2 <- c2s(chars2)

# 大文字に変換
# convert strings to uppercase
STRING1 <- toupper(string1)
STRING2 <- toupper(string2)
STRING1 # Print out the content of the string

# align the two protein sequences
# library(pwalign); data(BLOSUM50)
AlignGlobal <- pwalign::pairwiseAlignment(STRING1, STRING2, substitutionMatrix = BLOSUM50, 
                gapOpening = 10, gapExtension = 4, scoreOnly = FALSE)
AlignGlobal # Print out the optimal global alignment and its score

#' ### [Viewing a long pairwise alignment](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#viewing-a-long-pairwise-alignment)
#' **2本の配列間のアラインメントの表示と出力**
#' 
# print out the alignment
writePairwiseAlignments(AlignGlobal)

# Write a PairwiseAlignments object to a file
writePairwiseAlignments(AlignGlobal, file="AlignGlobal.txt")

#getwd()
#list.files()

#' ### [Pairwise local alignment of protein sequences using the Smith-Waterman algorithm](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#pairwise-local-alignment-of-protein-sequences-using-the-smith-waterman-algorithm)
#' **2本のタンパク質配列間の局所アラインメント**

# find the best local alignment between the two protein sequences
AlignLocal <- pwalign::pairwiseAlignment(STRING1, STRING2, substitutionMatrix = BLOSUM50, 
               gapOpening = 10, gapExtension = 4, scoreOnly = FALSE, type="local")
AlignLocal # Print out the optimal local alignment and its score
writePairwiseAlignments(AlignLocal)

#' We see that the optimal local alignment is quite similar to the optimal global alignment 
#' in this case, except that it excludes a short region of poorly aligned sequence 
#' at the start and at the ends of the two proteins.
#' 
#' ### [Calculating the statistical significance of a pairwise global alignment](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#calculating-the-statistical-significance-of-a-pairwise-global-alignment)
#' **ペアワイズ大域アラインメントの統計的有意性の計算**
#' 
#' ### [Summary](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#summary)

#data()
#?double
#?toupper

#library(Biostrings)
#nucleotideSubstitutionMatrix()
#?pairwiseAlignment

#library(seqinr)
#?c2s

#' ### [Links and Further Reading](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#links-and-further-reading)
#' - 2018-09-04 [PAM vs BLOSUM score matrices](https://www.cs.rice.edu/~ogilvie/comp571/pam-vs-blosum/)
#' - 2008-08-07 Guangchuang Yu [sequence alignment program written in R](https://guangchuangyu.github.io/2008/08/sequence-alignment-program-written-in-r/)
#' Sequence alignment by dynamic programming.
#' - 2021 榊原康文 [バイオインフォマティクス (第3回) | 配列解析（ペアワイズアライメント）](https://www.dna.bio.keio.ac.jp/lecture/bioinfo/bioinformatics-3.pdf)
#' 相同性検索（アライメント）の威力
#' - 2021/12/25 日本バイオインフォマティクス学会 編 [バイオインフォマティクス入門 第2版](https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/188bto4/alma9926623411304034)  
#'   - p.100: 3-2 配列アラインメント
#'   - p.102: 3-3 スコア行列 | 図 1.　BLOSUM62 行列の一部
#' - 2021.03.30 [配列解析 | 塩基配列解析とアミノ酸配列解析](https://bi.biopapyrus.jp/seq/)
#'   - [アラインメント | 核酸あるいはアミノ酸配列を複数並べ類縁度を可視化](https://bi.biopapyrus.jp/seq/alignment/)
#'     - [グローバルアライメント | グローバルアライメントを求める Needleman–Wunsch アルゴリズム](https://bi.biopapyrus.jp/seq/alignment/needleman–wunsch.html)
#'     - [ローカルアラインメント | ローカルアラインメントを求める Smith-Waterman アルゴリズム](https://bi.biopapyrus.jp/seq/alignment/smith-waterman.html)
#' - 2018/11/19 藤博幸・編 [よくわかるバイオインフォマティクス入門](https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/fb8nrm/alma9926580096704034)  
#'   - pp. 4-7:  1.1.2 変異と置換および分子進化 | 図 1.5 点変異・挿入変異・欠失変異 | 図 1.6 変異 (mutation) と 置換 (substitution)  
#'   - pp. 11-13: 1.3 配列アラインメント | 1.3.1 ペアワイズアラインメント
#' - 2009.9.12 川端 猛 [バイオインフォマティクス基礎講座 | 配列解析](https://www.jst.go.jp/nbdc/bird/jinzai/literacy/streaming/h21_3_1.pdf)
#'   - https://www.jst.go.jp/nbdc/bird/jinzai/literacy/streaming/
#'
#' ### [Exercises](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#exercises)
#' **演習**
#' [回答例](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#sequence-alignment)
#' 
sessionInfo()
