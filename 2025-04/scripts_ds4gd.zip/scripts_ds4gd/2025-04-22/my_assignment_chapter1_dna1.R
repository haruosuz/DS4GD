#' # assignment
#' - [Exercises](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter1.html#exercises)
#' - [Answers to the exercises on DNA Sequence Statistics (1)](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#dna-sequence-statistics-1)

# Clear R's environment
rm(list = ls())

# Load the packages into R
library(ape)
library(seqinr)

#' Record answers to the following questions.
#' Modify the example sentence and values as needed.
#' 
#' Download the DNA sequence of your genome of interest.
# Retrieving a DNA sequence from NCBI
ACCESSION <- "NC_045512" # Modify the accession number
filename <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text")
#filename <- paste0("http://togows.org/entry/nucleotide/",ACCESSION,".fasta")
#ape::write.FASTA(x=ape::read.GenBank(ACCESSION), file="myNT.fasta"); filename <- "myNT.fasta"
seqs <- read.fasta(file=filename, seqtype="DNA", strip.desc=TRUE)
#write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=paste0(ACCESSION,".fasta") )
seq1 <- seqs[[1]] # extract the 1st element from list
getAnnot(seq1) # get sequence annotations

#' ### Q1. 
#' What is the length in nucleotides of the genome sequence?

length(seq1)

#' ### Q2. 
#' What are the last 30 nucleotides of the genome sequence?

tail(seq1, 30)

#' ["SARS-CoV-2 RNAs carry poly(A) tails"](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7179501/)
#' 
#' ### Q3. 
#' How many of each of the four nucleotides A, C, T and G, 
#' and any other symbols, are there in the genome sequence?

table(seq1)

#' [Borreliella burgdorferi B31 chromosome](https://www.ncbi.nlm.nih.gov/nuccore/NC_001318.1/) does contain non-A/C/G/T nucleotides.
#' 
#' DDBJ 
#' [Codes Used in Sequence Description](https://www.ddbj.nig.ac.jp/ddbj/code-e.html)
#' [配列の記載に用いる略号](https://www.ddbj.nig.ac.jp/ddbj/code.html)
#' 
#' ### Q4. 
#' What is the GC content of the genome sequence, when 
#' (i) all non-A/C/T/G nucleotides are included, 
#' (ii) non-A/C/T/G nucleotides are discarded?
#help("GC")
GC(seq1)
GC(seq1, exact=FALSE)
GC(seq1, exact=TRUE)

#' ### Q5. 
#' How many of each of the four nucleotides A, C, T and G 
#' are there in the complement of the genome sequence?

#help.search("complement")
#help("comp")
table(comp(seq1))

#' - Mar 14, 2018 [Practice writing the complementary strand of DNA and mRNA during transcription - YouTube](https://www.youtube.com/watch?v=9qyi6xgOjEk)
#' <img alt="" src="https://i.ytimg.com/vi/9qyi6xgOjEk/maxresdefault.jpg" width=35%>
#' 
#' ### Q6. 
#' How many occurrences of the DNA words CC, CG and GC occur in the genome sequence?

count(seq=seq1, wordsize=2)

#' ### Q7. 
#' How many occurrences of the DNA words CC, CG and GC occur in the 
#' (i) first 6 and (ii) last 33 nucleotides of the genome sequence?

count(seq=head(seq1, 6), wordsize=2)
count(seq=tail(seq1, 33), wordsize=2)

# Print R version and packages
sessionInfo()
Sys.time()

#' - https://www.ncbi.nlm.nih.gov/datasets/genome/
#' - https://www.ncbi.nlm.nih.gov/datasets/genome/GCF_009858895.2/
#' Severe acute respiratory syndrome coronavirus 2 isolate Wuhan-Hu-1, complete genome
#'  - https://www.ncbi.nlm.nih.gov/nuccore/MN908947.3/
#'  - https://www.ncbi.nlm.nih.gov/nuccore/NC_045512.2/
#' Severe acute respiratory syndrome coronavirus 2 isolate Wuhan-Hu-1, complete genome
#' - https://www.ncbi.nlm.nih.gov/nuccore/NC_001318.1/
#' Borreliella burgdorferi B31, complete sequence
