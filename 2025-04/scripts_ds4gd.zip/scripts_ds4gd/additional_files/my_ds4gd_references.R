#' ---
#' title: "DS4GD_references"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---
#' 
#' # References
#' 
#' ## Epidemiology
#' - https://twitter.com/metacovid19
#' - https://moderna-epi-report.jp/
#' 新型コロナ・季節性インフルエンザ リアルタイム流行・疫学情報
#' - https://news.yahoo.co.jp/expert/articles/9a709d9886fcb1147208719a3ec653feed67187e
#' 新型コロナ 流行状況をどのように把握すれば良い？
#' - 
#' 
#' ## Nextstrain
#' Real-time tracking of pathogen evolution
#' 
#' - https://nextstrain.org/
#' - https://nextstrain.org/narratives/trees-background/ja
#' 系統発生樹の解読について
#' 
#' ## SARS-CoV-2
#' - https://www.ddbj.nig.ac.jp/sars-cov-2.html
#' SARS-CoV-2ゲノム配列登録情報 by Japan Covid-19 Open Data Consortium
#'   - https://getentry.ddbj.nig.ac.jp/getentry/na/BS000685-BS000694/
#'   - https://getentry.ddbj.nig.ac.jp/getentry/na/BS000695-BS001136/
#'   - https://getentry.ddbj.nig.ac.jp/getentry/na/BS001145-BS001191
#' - 
#' - https://www.tmiph.metro.tokyo.lg.jp/lb_virus/sars2ngstree/
#' 東京都健康安全研究センター » 2024年 1月の東京都における新型コロナウイルスのゲノム解析結果
#' 
#' - ![](https://www.tmiph.metro.tokyo.lg.jp/files/lb_virus/sars2ngstree/222S3.png)
#' 
#' ## 2022-02-11
#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8832810/
#' Pango lineage designation and assignment using SARS-CoV-2 spike gene nucleotide sequences
#' 
#' Using the Genbank features annotations (accession ID: NC_045512; gene ID: 43740568), we extracted the spike gene nucleotide sequences from the full alignment (genome positions 21,562 to 25,384),
#' 
#' - https://www.ncbi.nlm.nih.gov/nuccore/NC_045512
#' Severe acute respiratory syndrome coronavirus 2 isolate Wuhan-Hu-1, complete genome
#' 
#' ## Vaughn Cooper
#' - https://twitter.com/vscooper
#' - 2020/04/02 https://www.youtube.com/watch?v=7gCY9tP981I 11:20 The ongoing evolution of SARS-CoV-2
#'   - Slides https://figshare.com/articles/Ongoing_evolution_of_SARS-CoV-2_/12061692
#' - 2020/03/25 https://www.youtube.com/watch?v=MHRGPzoFyEM Evolution of SARS-CoV-2
#'   - Slides https://figshare.com/articles/Evolution_of_SARS-CoV-2/12026913
#' 
#' ![](https://figshare.com/ndownloader/files/22098021/preview/22098021/page_4_width_2000.png)
#' 
#' ![](https://figshare.com/ndownloader/files/22098021/preview/22098021/page_3_width_2000.png)
#' 
#' ## 長谷川政美
#' - https://twitter.com/masasloth
#' - https://kagakubar.com/luca/41.html
#' 
#' 第41話　ノコギリエイ目の系統樹マンダラ
#' 
#' ![](https://kagakubar.com/luca/41%E5%9B%9E/Fig.41-2s.jpg)
#' 
#' 軟骨魚類の進化についての2つの対立仮説。(a)形態に基づいた仮説、(b)分子系統樹。
#' 
#' - https://kagakubar.com/evolution/07.html
#' 進化の歴史
#' ー時間と空間が織りなす生き物のタペストリー
#' 第7話　なぜ多様な種が進化したか？
#' ◎収斂進化
#' 
#' ![](https://kagakubar.com/evolution/7%E5%9B%9E/Fig.7-4as.jpg)
#' ![](https://kagakubar.com/evolution/7%E5%9B%9E/Fig.7-4bs.jpg)
#' 
#' 図7-4　真獣類のなかの収斂。(a)インドハリネズミ Paraechinus microps、(b)ハリテンレック Setifer setosus。
#' 
#' ## unclassified
#' 
#' ![](https://cdn.numerade.com/ask_images/48dfe3f861924087a22ccf8723f6d21f.jpg)
#' 
#' - 2011-06-10 Avril Coghlan - "A Little Book of R For Bioinformatics" https://github.com/haruosuz/r4bioinfo/tree/master/R_Avril_Coghlan
#' - CAMPBELL BIOLOGY, 11th edition ; キャンベル生物学 原書11版, 丸善出版, (2018/3/20), 1704p. https://www.maruzen-publishing.co.jp/info/index.php?action=detail&news_no=19283
#'   - 26章 系統と生命の樹 [Phylogeny and the Tree of Life](https://www.maruzen-publishing.co.jp/files/書籍営業部/講義用資料/2018/キャンベル11授業用パワポサンプル26_Lecture_Presentation.pdf)
#' - 2018-07-30 Andrew Rambaut - "How to read a phylogenetic tree" https://artic.network/how-to-read-a-tree.html
#' - 2012-06-07 Richard Edwards - "How to root a phylogenetic tree" http://cabbagesofdoom.blogspot.com/2012/06/how-to-root-phylogenetic-tree.html
#' 
#' ## 三中信宏
#' Minaka Nobuhiro
#' 
#' - https://twitter.com/leeswijzer
#' - https://leeswijzer.hatenablog.com/
#' 2023-01-27 建築様式の系統樹 | 
#' 2015-06-15 世界言語のインフォグラフィクス | 
#' - https://leeswijzer.hatenablog.com/?page=1434328364
#' 2015-02-04 キュジャスの系図表（Stemma Agnationis）備忘メモ | 
#' 2014-11-03 Feast Your Eyes on This Beautiful Linguistic Family Tree | これはみごとな言語系統樹 | 
#' 2014-07-18 ビールの系統樹 | 
#' 2014-02-28 「食べるラー油」の系統樹 | 
#' 2014-01-08 欧州言語の距離ネットワーク | 
#' - https://leeswijzer.hatenablog.com/?page=1377905502
#' 2013-07-24 金管楽器コルネットの系統発生（続）
#' - https://leeswijzer.hatenablog.com/?page=1363912214
#' 2013-03-17 麺の系統樹（続） | 
#' 2013-02-13 国立民族学博物館国際シンポジウム〈「樹」について考える〉
#' 〈言語の系統関係を探る：その方法論と歴史学研究における意味〉
#' 
#' - http://leeswijzer.org/files/TheBookOfTrees.html
#' 翻訳本：マニュエル・リマ［三中信宏訳］『THE BOOK OF TREES — 系統樹大全：知の世界を可視化するインフォグラフィックス』 
#' 
#' X-Men Family Tree
#' ![https://www.pinterest.jp/pin/438608451188950235/](https://i.pinimg.com/564x/d1/b6/5a/d1b65af566e400b87cbb1df766fcf942.jpg)
#' 
#' ## 棒の手紙
#' - http://kokorohaitsumo15sai.la.coocan.jp/bonotegami.htm
#' これが「棒の手紙」だ！
#' 
#' ![](http://kokorohaitsumo15sai.la.coocan.jp/bonotegami01.JPG)
#' 
#' ## sushi
#' 進化の順番で寿司を食べる
#' 
#' - https://dailyportalz.jp/kiji/150714194069
#' 
#' ![](https://goto33.c.blog.ss-blog.jp/_images/blog/_e3a/goto33/024.jpg)
#' 
#' 
#' 
#' ## 
#' 
#' - [Which came first: the chicken or the egg? - Curious](https://www.science.org.au/curious/earth-environment/which-came-first-chicken-or-egg)
#' - https://pubmed.ncbi.nlm.nih.gov/21238242
#' Trends Ecol Evol. 1998 Apr 1;13(4):158. doi: 10.1016/s0169-5347(98)01362-7.
#' - 
#' - https://epirhandbook.com/en/phylogenetic-trees.html
#' 15 Phylogenetic trees | The Epidemiologist R Handbook
#' - https://epirhandbook.com/jp/phylogenetic-trees.html
#' 38 系統樹 | 疫学のための R ハンドブック
#' 
#' - 11/7/2017 [Module 24: An Intro to Phylogenetic Tree Construction in R](https://fuzzyatelin.github.io/bioanth-stats/module-24/module-24.html)
#'   - [Distance-based methods](https://fuzzyatelin.github.io/bioanth-stats/module-24/module-24.html#distance-based_methods)
#'   The following figure can help visually distinguish UPGMA methods from neighbor-joining methods (you can ignore single linkage and complete linkage)
#' 
#' ## 2021-12-25 バイオインフォマティクス入門 第2版
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/188bto4/alma9926623411304034
#' Maruzen eBook Library
#' - https://www.keio-up.co.jp/np/isbn/9784766427912/
#' - https://www.keio-up.co.jp/np/detail_contents.do?goods_id=6182
#' |
#' 第3章　配列解析
#' 3ー2　配列アラインメント：動的計画法による配列アラインメントの計算
#' 3ー3　スコア行列：アミノ酸の類似性スコアとその統計的評価
#' 3ー4　高速な類似配列検索：高速に配列を比較するための計算技術
#' 3ー5　ホモロジー検索：高速にホモロジー検索するためのプログラム
#' 3ー6　マルチプルアラインメント：マルチプルアラインメントによる配列の多重比較
#' |
#' 第5章　遺伝・進化解析
#' 5ー6　分子進化：分子進化の中立説と分子時計
#' 5ー7　進化系統樹：進化系統樹の表現方法
#' 5ー8　パラログ・オーソログ：進化系統樹によるホモログ・パラログ・オーソログの解析
#' 5ー9　系統推定アルゴリズム：系統樹をつくるための系統推定アルゴリズム
#' 
#' ## 2018-11-19 よくわかるバイオインフォマティクス入門
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/fb8nrm/alma9926580096704034
#' Maruzen eBook Library
#' - https://www.kspub.co.jp/book/detail/5138212.html
#' 1章　配列解析
#' 2章　分子進化
#' 6章　ゲノム解析
#' 
#' ## 2021-05 Mastering Python for Bioinformatics by Ken Youens-Clark
#' - https://www.oreilly.com/library/view/mastering-python-for/9781098100872/
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/188bto4/alma9926722992204034
#' Ebook Central Perpetual, DDA and Subscription Titles
#' 
#' ## 2018.5 再現可能性のすゝめ ―RStudioによるデータ解析とレポート作成―（Wonderful R 3）
#' - https://www.kyoritsu-pub.co.jp/book/b10003938.html
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/188bto4/alma9926579997904034
#' Maruzen eBook Library
#' 
#' ## Emmanuel Paradis (2012) "Analysis of Phylogenetics and Evolution with R" 2nd ed.
#' - https://github.com/haruosuz/books/tree/master/aper
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/fb8nrm/alma99186639204031
#' SpringerLink Books (Series & Reference Works)
#' 
#' 2 1 Introduction
#' In phylogenetic analyses, the usual computer program strategy follows a “black box” model where some data, stored in files, are read by a specific program, some computations are made, and the results are written into a file on the disk. What happens in the program cannot be accessed by the user. 
#' 
#' 188 5 Phylogeny Estimation
#' 
#' There has been an increasing trend in the literature over the past few years to perform estimation of phylogenies as a black-box computation where data are input and a tree is output. 
#' 
#' 
#' 
#' ## Ziheng Yang (2006) "Computational Molecular Evolution"
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/188bto4/alma99159251504031
#' Ebook Central Academic Complete
#' - http://abacus.gene.ucl.ac.uk/CME/
#'   - http://abacus.gene.ucl.ac.uk/CME/TableOfContents.pdf
#' 
#' 
#' 
#' ## 
#' - https://github.com/haruosuz/evolve/blob/master/references/evolve.video.md
#' 
#' 
#' 
#' 