#+ echo = TRUE
rm(list = ls())
#+ message = FALSE
# Load the required packages, installing if necessary
if (!require("BiocManager", quietly = TRUE)) install.packages("BiocManager")  # Install BiocManager if not already installed
if (!require("Biostrings", quietly = TRUE)) BiocManager::install("Biostrings")  # Install Biostrings using BiocManager if not already installed
library(Biostrings)  # Load the Biostrings package

# Download the genome file if it does not exist already
ACCESSION <- "HG738867.1" #  Escherichia coli str. K-12 substr. MC4100 complete genome
url <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text")
filename <- paste0(ACCESSION,".fna")
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Load the genome as a DNAStringSet object
myDNAStringSet <- readDNAStringSet(filename)

# Search for the pattern on the + strand
pattern <- "CCGGATGCGGCGTAAACGCCTTATCCGGCC"
#vmatchPattern(pattern, myDNAStringSet)
vcountPattern(pattern, myDNAStringSet)

# Search for the pattern on the - strand (complementary sequence)
pattern <- reverseComplement(DNAString(pattern))
#vmatchPattern(pattern, myDNAStringSet)
vcountPattern(pattern, myDNAStringSet)

#
sessionInfo()
