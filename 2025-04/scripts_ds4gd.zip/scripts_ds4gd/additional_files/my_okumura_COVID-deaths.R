# Haruo Suzuki
# 2025-04-27
# This script is for the analysis of 
# the number of deaths due to COVID-19 "COVID-deaths.csv".

# Clear R's environment
rm(list = ls())

# Load R packages
library(tidyverse)

# Read the COVID-19 deaths data
URL <- "https://okumuralab.org/~okumura/python/data/COVID-deaths.csv"
df <- read_csv(URL, col_types = cols(month = col_character()))

# Plot the data with smaller English font size
df %>%
  ggplot(aes(x = month, y = deaths)) +
  geom_col(width = 0.8) +  # Width between 0 and 1 looks better
  labs(x = "Month", y = "Number of deaths") +
  theme(
    axis.text.x = element_text(size = 9, angle = 90, hjust = 1),  # Set font size for x-axis tick labels
    axis.text.y = element_text(size = 9)                          # Set font size for y-axis tick labels
  )

#' # References
#' - https://x.com/h_okumura/status/1916409620656259324
#' - https://okumuralab.org/~okumura/python/COVID-deaths.html
#' 
