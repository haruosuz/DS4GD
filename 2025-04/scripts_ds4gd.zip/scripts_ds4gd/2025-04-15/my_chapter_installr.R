#' ---
#' title: "Little Book of R for Bioinformatics"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.time()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

#' ## [R言語入門](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#how-to-install-r-and-a-brief-introduction-to-r)
#' ## [How to install R and a Brief Introduction to R](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html)
#' ### Introduction to R
#' 
#' - 2022-06-26 中澤 港 | 統計処理ソフトウェアRについてのTips https://minato.sip21c.org/swtips/R.html
#' - 2019.08.16 biostatistics R を利用した統計解析およびデータの視覚化 https://stats.biopapyrus.jp/r/
#' - 2023-05-08 奥村 晴彦 | Rの初歩 https://okumuralab.org/~okumura/stat/first.html
#' 
#' ### [Installing R](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#installing-r)
#' 
#' - 2019-05-10 Sampo Suzuki | Rのインストール https://k-metrics.github.io/cabinet/env_install_r.html  
#' - 2017年 1月 30日 統計処理ソフトウェアRについてのTips／インストール https://minato.sip21c.org/swtips/Rinstall.html  
#' 
#' ### [Installing R packages](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#installing-r-packages)
#' 
#' - 2017.12.23 生物統計学 R 基礎編 パッケージ https://stats.biopapyrus.jp/r/basic/package.html   
#' - [Bioconductor: Genomicデータ解析ツール群 - Heavy Watal](https://heavywatal.github.io/rstats/bioconductor.html)  
#' 
#' #### [How to install an R package](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#how-to-install-an-r-package)
#' パッケージ[`seqinr`](https://cran.r-project.org/package=seqinr)のインストール:  
# install the "seqinr" package
#install.packages("seqinr")

#' `seqinr`パッケージの呼び出し:  
# load the "seqinr" package into R
#library(seqinr)

#' #### [How to install a Bioconductor R package](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#how-to-install-a-bioconductor-r-package)
#' Bioconductorパッケージ[`Biostrings`](http://bioconductor.org/packages/Biostrings/)のインストール:  
# install the Bioconductor package called "Biostrings"
#install.packages("BiocManager")
#BiocManager::install("Biostrings")

#' `Biostrings`パッケージの呼び出し:  
# load the "Biostrings" package into R
#suppressMessages(library(Biostrings))

#' ### [Running R](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#running-r)
#' 
#' - R のインストールと起動・終了
#' 2019 [Mac 版](https://www.ic.nanzan-u.ac.jp/~urakami/pdf/19Rpdf/19m_1.pdf) |
#' [Win 版](https://www.ic.nanzan-u.ac.jp/~urakami/pdf/RpdfW/v95_1w.pdf)
#' 
#' Rを終了:  
# To quit R, type:
#quit()
#q()

#' - [R for Data Science | 6 Workflow: scripts | 6.1 Running code](https://r4ds.had.co.nz/workflow-scripts.html#running-code)
#' 
#' Cmd/Ctrl + Enter
#' 
#' ### [A brief introduction to R](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#a-brief-introduction-to-r)
#' 
#' - 2017.12.23 生物統計学 R 基礎編 演算子 https://stats.biopapyrus.jp/r/basic/arithmetic-operator.html
#' 
#' 算術演算子  
# typing in commands
2*3
10-3

#' 代入演算子  
#' All variables (vectors, etc.) created by R are called objects. 
#' In R, we assign values to variables using an arrow (`<-`).
# assign the value 2*3 to the variable x
x <- 2*3

# To view the contents of any R object, just type its name
x

#' - 2017.03.12 生物統計学 R 基礎編 データ型 https://stats.biopapyrus.jp/r/basic/data-type.html  
#' - 2017.06.13 生物統計学 R 基礎編 ベクトル https://stats.biopapyrus.jp/r/basic/vector.html    
#' 
#' ベクトルの作成は、関数`c()`を用いる。  
#' use the `c()` (combine) function to create a vector
# create a vector called myvector that has elements with values 8, 6, 9, 10, and 5:
myvector <- c(8, 6, 9, 10, 5)

# see the contents of the variable myvector:
myvector

#' ベクトル要素の取得は、角括弧に要素の添字を書く。  
#' extract elements with single square brackets `[index]`.
# get the value of the 4th element in the vector myvector
myvector[4]

#' - 2019.07.06 生物統計学 R 基礎編 リスト https://stats.biopapyrus.jp/r/basic/list.html  
#' 
#' リストは異なる型（数値や文字列）のデータをまとめられる。
#' リストの作成は関数`list()`を用いる。  
#' A list can contain elements of different types (e.g. numeric and character).
# create a list mylist:
mylist <- list(disease="COVID-19", virus="SARS-CoV-2", myvector)
mylist

#' `[[ ]]`はリスト内の要素（ベクトル）を取り出す。  
#' extract elements with double square brackets `[[index]]`.
# extract the second and third elements from mylist:
mylist[[2]]
mylist[[3]]

#' リストの要素に名前が付けられている場合、`$`記号でアクセスする。  
# mylist$virus is the same as mylist[[2]]:
mylist$virus

# find the names of the named elements in a list
attributes(mylist)

#' - 2012/05/08 table 関数を使ったクロス集計 http://nshi.jp/contents/r/crosstab/

# produce a table variable that contains the number of bases:
mybases <- c("a", "c", "g", "t", "a")
table(mybases)
# store the table variable produced by the function table(), and call the stored table “mytable”:
mytable <- table(mybases)
mytable
# access the 1st element in the table mytable (the number of base "a"):
mytable[[1]]
mytable[["a"]]

#' - Rの基本演算、関数、定数 https://whitewell.sakura.ne.jp/R/Rintro-01.html
#' 
# calculate the log to the base 10 of a number:
log10(100)

#' - 2016/04/27 ヘルプ https://r-beginners.com/026help.html
#' - 統計ソフトRの「困った」を解決する12（+α）の方法 https://id.fnshr.info/2011/07/07/rhelp/  
#' 
# get help about a particular function
help(log10)

#' 標準偏差 standard deviation を計算する関数を探す

# search for all functions containing the word “deviation” in their description:
#help.search("deviation")
#RSiteSearch("deviation")

#' ベクトルの値の平均

# calculate the average of the values in the vector myvector
mean(myvector)

#' ### [Links and Further Reading](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#links-and-further-reading)
#' 
sessionInfo()
