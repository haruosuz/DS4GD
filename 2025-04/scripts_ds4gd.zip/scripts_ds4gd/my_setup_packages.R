#' [Omit `#` to execute.](https://r4ds.hadley.nz/workflow-basics.html#comments)
#R.version

#' - https://cran.r-project.org/mirrors.html
# URLs of the repositories for use by install.packages
options(repos="https://ftp.yz.yamagata-u.ac.jp/pub/cran/")
options(repos="https://cran.asia/")

#' Rパッケージのインストール:  
#' Installing the R packages:  
#install.packages("tidyverse")
#install.packages("seqinr")
#install.packages("zoo")
#install.packages("ape")
#install.packages("phangorn")
#install.packages("phytools")
#install.packages("geiger")
#install.packages("ggseqlogo")
#install.packages("microseq")
#install.packages("rentrez")
#install.packages("Peptides", dependencies=TRUE)

#' Bioconductorパッケージのインストール:  
#' Installing the Bioconductor packages:  
#if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
#BiocManager::install("ggtree")
#BiocManager::install("biomartr")
#BiocManager::install("Biostrings")
#BiocManager::install("pwalign")
#BiocManager::install("msa")
#BiocManager::install("DECIPHER")

#' ```
#' Update all/some/none? [a/s/n]:
#' n
#' ```
#' 
#' Rパッケージのバージョンを表示する:  
#' Print the versions of these packages:  
packageVersion("tidyverse")
packageVersion("seqinr")
packageVersion("zoo")
packageVersion("ape")
packageVersion("phangorn")
packageVersion("phytools")
packageVersion("geiger")
packageVersion("ggseqlogo")
packageVersion("microseq")
packageVersion("rentrez")
packageVersion("Peptides")

#packageVersion("ggtree")
packageVersion("biomartr")
packageVersion("Biostrings")
packageVersion("pwalign")
packageVersion("msa")
packageVersion("DECIPHER")

#' Rパッケージの呼び出し:  
#' Load the packages into R:  
library(tidyverse)
library(seqinr)
library(zoo)
library(ape)
library(phangorn)
library(phytools)
library(geiger)
library(ggseqlogo)
library(microseq)
library(rentrez)
library(Peptides)

#library(ggtree)
library(biomartr)
library(Biostrings)
library(pwalign)
library(msa)
library(DECIPHER)

#' R、OS、ロードされたパッケージのバージョン情報を表示する:  
#' Print version information about R, the OS and attached or loaded packages:  
sessionInfo()
