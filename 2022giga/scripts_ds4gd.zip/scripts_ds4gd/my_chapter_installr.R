#' ---
#' title: "Little Book of R for Bioinformatics"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.time()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

#' ## [R言語入門](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#how-to-install-r-and-a-brief-introduction-to-r)
#' ## [How to install R and a Brief Introduction to R](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html)
#' ### Introduction to R
#' 
#' - 2022-06-26 中澤 港 | 統計処理ソフトウェアRについてのTips https://minato.sip21c.org/swtips/R.html
#' - 2019.08.16 biostatistics R を利用した統計解析およびデータの視覚化 https://stats.biopapyrus.jp/r/
#' - 2019-04-22 奥村 晴彦 | Rの初歩 https://oku.edu.mie-u.ac.jp/~okumura/stat/first.html
#' - 2004/05/26 統計解析ソフト R の備忘録 [R-Tips](http://stat.sys.i.kyoto-u.ac.jp/titech/class/doc/r-tips.pdf
#' 
#' ### [Installing R](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#installing-r)
#' 
#' - [R のインストール - RjpWiki](http://www.okadajp.org/RWiki/?R%20のインストール)  
#' - [統計処理ソフトウェアRについてのTips／インストール](https://minato.sip21c.org/swtips/Rinstall.html)  
#' 
#' ### [Installing R packages](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#installing-r-packages)
#' 
#' - biostatistics | R | 基礎編 | [パッケージ](https://stats.biopapyrus.jp/r/basic/package.html)  
#' - [Bioconductor: Genomicデータ解析ツール群 - Heavy Watal](https://heavywatal.github.io/rstats/bioconductor.html)  
#' 
#' #### [How to install an R package](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#how-to-install-an-r-package)
#' パッケージ[`seqinr`](https://cran.r-project.org/package=seqinr)のインストール:  
# install the "seqinr" package
#install.packages("seqinr")

#' `seqinr`パッケージの呼び出し:  
# load the "seqinr" package into R
#library(seqinr)

#' #### [How to install a Bioconductor R package](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#how-to-install-a-bioconductor-r-package)
#' Bioconductorパッケージ[`Biostrings`](http://bioconductor.org/packages/Biostrings/)のインストール:  
# install the Bioconductor package called "Biostrings"
#install.packages("BiocManager")
#BiocManager::install("Biostrings")

#' `Biostrings`パッケージの呼び出し:  
# load the "Biostrings" package into R
#suppressMessages(library(Biostrings))

#' ### [Running R](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#running-r)
#' 
#' - R のインストールと起動・終了
#' 2019 [Mac 版](https://www.ic.nanzan-u.ac.jp/~urakami/pdf/19Rpdf/19m_1.pdf) |
#' [Win 版](https://www.ic.nanzan-u.ac.jp/~urakami/pdf/RpdfW/v95_1w.pdf)
#' 
#' Rを終了:  
# To quit R, type:
#quit()
#q()

#' - https://github.com/haruosuz/books/tree/master/r4all
#' - https://github.com/haruosuz/books/tree/master/r4ds
#' 
#' When you double-click on a script file, it will automatically open in RStudio.
#' 
#' [Pressing Cmd/Ctrl + Enter executes the current R expression in the console.](https://r4ds.had.co.nz/workflow-scripts.html)
#' 
#' ### [A brief introduction to R](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#a-brief-introduction-to-r)
#' 
#' biostatistics | R | 基礎編 | [演算子](https://stats.biopapyrus.jp/r/basic/arithmetic-operator.html)
#' 
#' 算術演算子  
# typing in commands
2*3
10-3

#' 代入演算子  
#' All variables (vectors, etc.) created by R are called objects. 
#' In R, we assign values to variables using an arrow (`<-`).
# assign the value 2*3 to the variable x
x <- 2*3

# To view the contents of any R object, just type its name
x

#' - biostatistics | R | 基礎編 | [データ型](https://stats.biopapyrus.jp/r/basic/data-type.html)  
#' - biostatistics | R | 基礎編 | [ベクトル](https://stats.biopapyrus.jp/r/basic/vector.html)  
#' 
#' ベクトルの作成は、関数`c()`を用いる。  
#' use the `c()` (combine) function to create a vector
# create a vector called myvector that has elements with values 8, 6, 9, 10, and 5:
myvector <- c(8, 6, 9, 10, 5)

# see the contents of the variable myvector:
myvector

#' ベクトル要素の取得は、角括弧に要素の添字を書く。  
#' extract elements with single square brackets `[index]`.
# get the value of the 4th element in the vector myvector
myvector[4]

#' - [リスト](https://stats.biopapyrus.jp/r/basic/list.html)  
#' 
#' リストは異なる型（数値や文字列）のデータをまとめられる。
#' リストの作成は関数`list()`を用いる。  
#' A list can contain elements of different types (e.g. numeric and character).
# create a list mylist:
mylist <- list(name="Fred", wife="Mary", myvector)
mylist

#' `[[ ]]`はリスト内の要素（ベクトル）を取り出す。  
#' extract elements with double square brackets `[[index]]`.
# extract the second and third elements from mylist:
mylist[[2]]
mylist[[3]]

#' リストの要素に名前が付けられている場合、`$`記号でアクセスする。  
# mylist$wife is the same as mylist[[2]]:
mylist$wife

# find the names of the named elements in a list
attributes(mylist)

#' - [table 関数を使ったクロス集計](http://nshi.jp/contents/r/crosstab/)

# produce a table variable that contains the number of bases:
mybases <- c("A", "C", "G", "T", "A")
table(mybases)
# store the table variable produced by the function table(), and call the stored table “mytable”:
mytable <- table(mybases)
mytable
# access the 1st element in the table mytable (the number of base “A”):
mytable[[1]]
mytable[["A"]]

#' - [R の演算の基礎](http://ss.sguc.ac.jp/~rider/R/basiccalc.html) 四則演算 | 数学関数

# calculate the log to the base 10 of a number:
log10(100)

#' - [ヘルプ](https://r-beginners.com/026help.html)
#' - [Rのヘルプ機能 - RjpWiki](http://www.okadajp.org/RWiki/?Rのヘルプ機能)
#' - [必要な関数を探す - RjpWiki](http://www.okadajp.org/RWiki/?必要な関数を探す)
#' - [統計ソフトRの「困った」を解決する12（+α）の方法｜Colorless Green Ideas](https://id.fnshr.info/2011/07/07/rhelp/)
#' 
# get help about a particular function
help(log10)

#' 標準偏差 standard deviation を計算する関数を探す

# search for all functions containing the word “deviation” in their description:
#help.search("deviation")
#RSiteSearch("deviation")

#' ベクトルの値の平均

# calculate the average of the values in the vector myvector
mean(myvector)

#' - [関数の作り方 | R の関数を一から作る方法](https://stats.biopapyrus.jp/r/basic/function.html)
#' - [Rの関数定義の基本 - RjpWiki](http://www.okadajp.org/RWiki/?Rの関数定義の基本)
#'  
# create a function to calculate the value of 20 plus square of some input number:
myfunction <- function(x) { return(20 + (x*x)) }
# use the function for different input numbers (eg. 10, 25):
myfunction(10)
myfunction(25)

#' ### [Links and Further Reading](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#links-and-further-reading)
#' 
sessionInfo()
