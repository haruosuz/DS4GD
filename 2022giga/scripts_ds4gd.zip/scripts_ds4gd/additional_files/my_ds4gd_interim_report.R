#' ---
#' title: "My interim report"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

#' # [Little Book of R for Bioinformatics](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan)
#' ## DNA Sequence Statistics (1)
source("my_assignment_chapter1_dna1.R")
#' ## DNA Sequence Statistics (2)
source("my_assignment_chapter2_dna2.R")
#' ## Dotplot
source("my_assignment_chapter4_align_dotplot.R")
#' ## Pairwise Sequence Alignment
source("my_assignment_chapter4_align_pairwise.R")

#' # Print R version and packages
sessionInfo()
Sys.time()
