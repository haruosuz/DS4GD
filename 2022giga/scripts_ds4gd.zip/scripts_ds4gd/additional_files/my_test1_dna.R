#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#dna-sequence-statistics-1

# load the "SeqinR" R package
library("seqinr")
# Create tests
testseq <- s2c("acgt")
testseq
# Length of a DNA sequence
length(testseq)
# Base composition of a DNA sequence
table(testseq)
# GC Content of DNA
GC(testseq)
# DNA words
count(testseq, wordsize = 2)