#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#over-represented-and-under-represented-dna-words

# Loading Package "seqinr"
library(seqinr)
# Create tests
testseq <- s2c("aatgc")
# Get the number of occurrences of 1-nucleotide DNA words
count(testseq, 1)
# Get the number of occurrences of 2-nucleotide DNA words
count(testseq, 2)
# The rho statistic can be computed on each of the 16 dinucleotides
rho(sequence = testseq, wordsize = 2)
