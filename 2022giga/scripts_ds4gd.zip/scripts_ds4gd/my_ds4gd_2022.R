#' ---
#' title: "DS4GD_2022"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

rm(list = ls())

# Loading packages
#+ warning = FALSE
#+ message = FALSE
#library(seqinr)
#library(phangorn)
library(ape)

#' # References
#' - [Which came first: the chicken or the egg? - Curious](https://www.science.org.au/curious/earth-environment/which-came-first-chicken-or-egg)
#' - https://pubmed.ncbi.nlm.nih.gov/21238242
#' Trends Ecol Evol. 1998 Apr 1;13(4):158. doi: 10.1016/s0169-5347(98)01362-7.
#' - 
#' - https://artic.network/how-to-read-a-tree.html
#' - 
#' - 11/7/2017 [Module 24: An Intro to Phylogenetic Tree Construction in R](https://fuzzyatelin.github.io/bioanth-stats/module-24/module-24.html)
#'   - [Distance-based methods](https://fuzzyatelin.github.io/bioanth-stats/module-24/module-24.html#distance-based_methods)
#'   The following figure can help visually distinguish UPGMA methods from neighbor-joining methods (you can ignore single linkage and complete linkage)
#'
#' # [Emmanuel Paradis (2012) "Analysis of Phylogenetics and Evolution with R"](https://github.com/haruosuz/books/tree/master/aper)
#' - https://link.springer.com/book/10.1007%2F978-1-4614-1743-9
#'   - https://link.springer.com/content/pdf/10.1007/978-1-4614-1743-9.pdf
#' 
#' - **[5 Phylogeny Estimation](https://link.springer.com/content/pdf/10.1007%2F978-1-4614-1743-9_5)**
#'   - **5.1 Distance Methods**
#'   - **5.1.1 Calculating Distances**
#'   - **5.1.3 Simple Clustering, UPGMA, and WPGMA**
#'   - **5.1.4 Neighbor-Joining**
#'
#' # [Ziheng Yang (2006) "Computational Molecular Evolution"](http://abacus.gene.ucl.ac.uk/CME/)
#' [Table of Contents](http://abacus.gene.ucl.ac.uk/CME/TableOfContents.pdf)
#' 
#' - **Part I: Modeling Molecular Evolution**
#'   - **CHAPTER 1 Models of Nucleotide Substitution**
#' - **Part II: Phylogeny Reconstruction**
#'   - **CHAPTER 3 PHYLOGENY RECONSTRUCTION: Overview**
#'     - **3.1 Tree Concepts**
#'
#' # [The Newick tree format](http://evolution.genetics.washington.edu/phylip/newicktree.html)

layout(matrix(1:4, 2, 2))

txt <- "((A,B,C),D);"
tr <- read.tree(text = txt); tr; plot(tr, main = txt)

txt <- "((,,),);"
tr <- read.tree(text = txt); tr; plot(tr, main = txt)

txt <- "((A:0.05,B:0.2,C:0.1):0.3,D:0.4);"
tr <- read.tree(text = txt); tr; plot(tr, main = txt)

txt <- "((A:0.05,B:0.2,C:0.1)Ancestor:0.3,D:0.4)R;"
tr <- read.tree(text = txt); tr
plot.phylo(tr, main = txt)
nodelabels(tr$node.label)
add.scale.bar()

names(tr)
write.tree(tr)
write.tree(tr, file = "myNewick.tre")

#' - http://tree.bio.ed.ac.uk/software/figtree/
#' FigTree is designed as a graphical viewer of phylogenetic trees and as a program for producing publication-ready figures. 
#library(ape)
#?ape::ladderize
layout(matrix(1:4, 2, 2))
txt <- "(E, ((C, (A, B)), D));"
txt <- "(Fishes, ((Lizards, (Chimps, Humans)), Frogs));"
tr <- read.tree(text = txt); write.tree(tr); plot(tr, main = "normal")
tr <- ladderize(tr, right=T); write.tree(tr); plot(tr, main="right-ladderized")
tr <- ladderize(tr, right=F); write.tree(tr); plot(tr, main="left-ladderized")
#layout(matrix(1, 1))
txt <- "(Humans, ((Lizards, Snakes), (Crocodiles, Birds)));"
tr <- read.tree(text = txt); plot(tr, type="cladogram", main="Reptiles are monophyletic?")
#ape::is.monophyletic(phy = tr, tips = c("Lizards", "Snakes", "Crocodiles"))
#' 
#' - https://en.wikipedia.org/wiki/Monophyly
#' 
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/fb8nrm/alma9926580096704034
#' よくわかるバイオインフォマティクス入門 | 2章 分子系統解析 21 | 2.3.2 I配列聞の相違度の計算 | 
#' 2.3.3 I進化距離の推定 | 同じ座位 で2回以上の置換が生じることを多重置換 (multiple substitutions)という. | 
#' 21 | 図 2.3 多 重 置 換
#' 
#' # model
#' 
#' ![https://en.wikipedia.org/wiki/Transversion](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/All_transitions_and_transversions.svg/320px-All_transitions_and_transversions.svg.png)
#' 
#' - [Codes Used in Sequence Description](https://www.ddbj.nig.ac.jp/ddbj/code-e.html)
#' Nucleotide Base Codes
#' ```
#' r	a or g	purine
#' y	c or t	pyrimidine
#' ```
#' 
# vector of chars
chars1 <- c("a","c","g","t", "a","c","g","t", "a","a","c","c","g","g","t","t")
chars2 <- c("a","c","g","t", "g","t","a","c", "c","t","a","g","c","t","a","g")
############################ #-transitions-#  #--------transversions--------#
chars1 <- c("a","c","g","t", "a","c",         "a","a","g","g")
chars2 <- c("a","c","g","t", "g","t",         "c","t","c","t")
mat <- rbind(chars1, chars2)
myDNAbin <- ape::as.DNAbin(mat)
as.character(myDNAbin)
ape::dist.dna(x = myDNAbin, model = "TS") # transitions
ape::dist.dna(x = myDNAbin, model = "TV") # transversions
ape::dist.dna(x = myDNAbin, model = "N")
#' - https://en.wikipedia.org/wiki/Models_of_DNA_evolution#JC69_model_(Jukes_and_Cantor_1969)
#' ![](https://wikimedia.org/api/rest_v1/media/math/render/svg/0e78cfbdcb0ae0efaaf136d9a1f7856a617de5f3)
( p <- ape::dist.dna(x = myDNAbin, model = "raw") )
( d <- -3/4 * log(1 - 4/3 * p) )
ape::dist.dna(x = myDNAbin, model = "JC69") # Jukes and Cantor (1969)

# Print R version and packages
sessionInfo()
Sys.time()
