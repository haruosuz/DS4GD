#' # assignment
#' - [Exercises](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#exercises)
#' - [Answers to the exercises on Multiple Alignment and Phylogenetic Trees](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#multiple-alignment-and-phylogenetic-trees)

# Clear R's environment
rm(list = ls())

# Load the packages into R
#+ warning = FALSE
#+ message = FALSE
library(rentrez)
library(seqinr)
library(Biostrings)
library(msa)
library(microseq)
library(ape)
library(phangorn)

#' - https://en.wikipedia.org/wiki/Split_(phylogenetics)
# Function to display a split (bipartition of a set of taxa)
# Branch lengths are ignored; only topology is considered
# Cutting an internal branch in an unrooted tree separates multiple sequences into two groups
display_splits <- function(myphy) {
  myphy$edge.length <- NULL
  splits <- prop.part(myphy)
  internal_splits <- splits[sapply(splits, function(x) length(x) > 1 & length(x) < length(myphy$tip.label))]
  for(i in seq_along(internal_splits)) {
    group1 <- myphy$tip.label[internal_splits[[i]]]
    group2 <- setdiff(myphy$tip.label, group1)
    cat(sprintf("Split %d:\n  Group 1: (%s);\n  Group 2: (%s);\n\n",
                i, paste(group1, collapse=","), paste(group2, collapse=",")))
  }
}

#' Record answers to the following questions.
#' Modify the example sentence and values as needed.
#' 
#' ## Q1. 
#' Calculate pairwise distances between aligned homologous sequences.
#' Identify the pairs with the smallest and greatest distances.
# Retrieve several protein sequences from NCBI
# Modify the accession number **
myIngroup <- c("WZU51027.1", "QNO39293.1", "XXW08590.1") # replication protein [Canine circovirus]
myOutgroup <- c("WRK61487.1") # replicase [Bamboo rat circovirus]
ACCESSIONs <- c(myIngroup, myOutgroup)
ACCESSIONs
file.fasta <- "my_aa.fasta"
#seqs <- lapply(ACCESSIONs, function(x) rentrez::entrez_fetch(db="protein", id=x, rettype="fasta"))
#write(unlist(seqs), file=file.fasta)

read.fasta.protein <- function(ACCESSION) seqinr::read.fasta(file=paste0("http://togows.dbcls.jp/entry/protein/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
#read.fasta.protein <- function(ACCESSION) seqinr::read.fasta(file=paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=protein&id=", ACCESSION, "&rettype=fasta&retmode=text"), seqtype="AA", strip.desc=TRUE)[[1]]
seqs <- lapply(ACCESSIONs, read.fasta.protein)
write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=file.fasta, nbchar=max(getLength(seqs)))

#' Read amino-acid sequences from a file in FASTA format.
seqs <- read.fasta(file=file.fasta, seqtype="AA", strip.desc=TRUE)

# Get the number of elements
length(seqs)
# Get the length of sequences
seqinr::getLength(seqs)
# Get sequence annotations
unlist(seqinr::getAnnot(seqs))

# write out the sequences to a FASTA file
seqinr::write.fasta(sequences=seqs, names=ACCESSIONs, file.out="my_aa.fasta")

# Read an XStringSet object from a file
myAAStringSet <- Biostrings::readAAStringSet(file = "my_aa.fasta")

# Multiple Sequence Alignment using ClustalW
library(msa)
myMsaAAMultipleAlignment <- msa::msa(inputSeqs=myAAStringSet, method="ClustalW")
myMsaAAMultipleAlignment
#print(myMsaAAMultipleAlignment, show="complete")

# write an XStringSet object to a file
Biostrings::writeXStringSet(x = unmasked(myMsaAAMultipleAlignment), filepath = "my_aa_msa.fasta")

# Read the FASTA-format alignment into R
#myAln <- seqinr::read.alignment(file = "my_aa_msa.fasta", format = "fasta")
# Calculate the pairwise distances between the protein sequences
#mydist <- seqinr::dist.alignment(x = myAln, matrix = "similarity")

# Convert the MSA object directly into a phyDat object for phangorn
myphyDat <- phangorn::as.phyDat(myMsaAAMultipleAlignment, type = "AA")
# Calculate the evolutionary distances using the LG model and pairwise gap deletion
mydist <- phangorn::dist.hamming(myphyDat, ratio = TRUE, exclude = "none")
#mydist <- phangorn::dist.ml(myphyDat, model = "LG", exclude = "pairwise")
mydist
#as.matrix(mydist)
#as.dist(as.matrix(mydist))
#as.matrix(summary(as.numeric(mydist)))
#' ** Pairwise distance — Smallest: "QNO39293.1" & "XXW08590.1" (0.1056106), Greatest: "WZU51027.1" & "WRK61487.1" (0.2772277).
#' 
#' ## Q2. 
#' Infer an unrooted phylogenetic tree of the proteins, using the neighbour-joining algorithm. 
#' Which are grouped together in the tree?

# Reconstruct a phylogenetic tree with the neighbor joining algorithm
mytree <- ape::nj(mydist)
ape::plot.phylo(mytree, type = "unrooted", underscore=TRUE)
display_splits(mytree) # Cutting an internal branch in an unrooted tree divides the sequences into two groups.

#' ## Q3. 
#' Infer an unrooted phylogenetic tree based on a trimmed alignment.
#' Does this differ from the tree based on the untrimmed alignment (in Q2)?
#' Trimming discards columns with too many gaps. If the topologies are identical, 
#' gappy columns had no strong effect. If different, they added noise to the analysis.
#library(microseq)
msa.untrimmed <- microseq::readFasta(in.file = "my_aa_msa.fasta")
print(nchar(msa.untrimmed$Sequence))
msa.trimmed <- microseq::msaTrim(msa = msa.untrimmed, gap.end = 0, gap.mid = 0)
print(nchar(msa.trimmed$Sequence))
microseq::writeFasta(fdta = msa.trimmed, out.file = "my_aa_msa_trim.fasta", width = 80)
# Import sequence alignments
myphyDat <- phangorn::read.phyDat(file="my_aa_msa_trim.fasta", format="fasta", type="AA")
# Calculate the evolutionary distances using the LG model and pairwise gap deletion
mydist <- phangorn::dist.hamming(myphyDat, ratio = TRUE, exclude = "none")
#mydist <- phangorn::dist.ml(myphyDat, model = "LG", exclude = "pairwise")
mydist
# Reconstruct a phylogenetic tree
mytree.trim <- ape::nj(mydist)
ape::plot.phylo(mytree.trim, type = "unrooted", main="unrooted tree", underscore=TRUE)
#display_splits(mytree.trim)
ape::all.equal.phylo(mytree, mytree.trim, use.edge.length = FALSE)
#' ** Tree topologies are: 1. Identical (if `TRUE` above) / 2. Different (if `FALSE` above)
#' 
#' ## Q4.
#' Infer a rooted phylogenetic tree based on the trimmed alignment using an outgroup.
#' Describe the evolutionary relationships among the sequences; 
#' which lineages are sister groups or form a monophyletic clade?
#' 
#' Unlike the unrooted tree, 
#' the rooted tree tells us the direction of evolutionary divergence, allowing us 
#' to determine which lineages share more recent common ancestors and
#' to infer the relative order of branching events.
mytree <- mytree.trim
mytree <- ape::root(phy=mytree, outgroup=myOutgroup, resolve.root=TRUE)
mytree <- ape::ladderize(mytree, right = FALSE)
ape::plot.phylo(mytree, type="phylogram", main="rooted tree", underscore=TRUE)
#' ** Taxon XXW08590.1 and taxon WZU51027.1 are sister groups to each other, 
#' meaning they share a more recent common ancestor with each other than with any other sequences. 
#' Together with any descendants of their most recent common ancestor (MRCA), 
#' they form a monophyletic group, the clade (XXW08590.1,WZU51027.1). 
#' The clade and taxon QNO39293.1 are sister groups. 
#' The unrooted tree is rooted with the outgroup (WRK61487.1), the most distantly related sequences compared to any in the ingroup. 
#' Note that the outgroup (WRK61487.1) and QNO39293.1 were grouped together in one split of the unrooted tree.
#mytree$edge.length <- NULL # remove branch lengths
# Print the tree as a Newick-format (parenthetic format) text
ape::write.tree(phy = mytree)
# Save the tree as a Newick-format (parenthetic format) text file
ape::write.tree(phy = mytree, file = "my_aa_msa_trim_nj.tre")
#' - https://en.wikipedia.org/wiki/Sister_group
#' - https://en.wikipedia.org/wiki/Clade
#' - https://en.wikipedia.org/wiki/Newick_format
# Print R version and packages
sessionInfo()
Sys.time() # 2026-04