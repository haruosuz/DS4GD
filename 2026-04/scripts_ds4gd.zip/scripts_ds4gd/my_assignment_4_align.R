#' # assignment
#' - [Exercises](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#exercises)
#' - [Answers to the exercises on Sequence Alignment](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#sequence-alignment)

rm(list = ls()) # Clear R's environment

# Load the packages into R
library(seqinr)
library(pwalign)
library(Biostrings)

#' Record answers to the following questions.
#' Modify the example sentence and values as needed.
#' 
#' ## Q1. 
#' Download FASTA files of two homologous protein sequences from public databases.

# Generate URLs to retrieve protein sequences from NCBI
acc1 <- "EDD8358772.1" # Modify the accession number **
acc2 <- "HHE9944003.1" # Modify the accession number **
url1 <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=protein&id=", acc1, "&rettype=fasta&retmode=text")
url2 <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=protein&id=", acc2, "&rettype=fasta&retmode=text")

# Print URLs
url1
url2
# You can access these sequences by pasting the URLs into a web browser.

# Define local file names to save the sequences
filename1 <- paste0(acc1, ".fasta")
filename2 <- paste0(acc2, ".fasta")

# Download the FASTA files from the URLs to the local machine
download.file(url1, destfile = filename1)
download.file(url2, destfile = filename2)

# Read FASTA-formatted sequences from the downloaded local files
chars1 <- read.fasta(file = filename1, seqtype = "AA", strip.desc = TRUE)[[1]]
chars2 <- read.fasta(file = filename2, seqtype = "AA", strip.desc = TRUE)[[1]]

# get sequence length and annotation
length(chars1); getAnnot(chars1)
length(chars2); getAnnot(chars2)

# conversion of a vector of chars into a string
string1 <- c2s(chars1)
string2 <- c2s(chars2)

# convert strings to uppercase 
STRING1 <- toupper(string1)
STRING2 <- toupper(string2)

#' ## Q2. 
#' Check if the two sequences are homologous.  
#' 
#' Create a dotplot for two sequences.
#' In the dotplot, the 1st sequence is plotted along the x-axis (horizontal axis), 
#' and the 2nd sequence is plotted along the y-axis (vertical axis). 
#' The dotplot displays a dot at points where there is an identical amino acid in the two sequences.  
#' 
#' ** Homology:  
#' 1. Suggested (Many dots are observed along a diagonal line)  
#' 2. Not suggested (No distinct diagonal line of dots is observed)  

par(mfrow=c(1,2))
dotPlot(seq1 = chars1, seq2 = chars2)

#' ## Q3. 
#' Create a self-similarity dot-plot. i.e. Compare the sequence against itself.
#' Sequences may contain regions of self-similarity (internal repeats).

par(mfrow=c(1,2))
dotPlot(chars1, chars1)
dotPlot(chars2, chars2)

#' ## Q4. 
#' What are the alignment statistics for the optimal global alignment between the two proteins 
#' when using the BLOSUM62 scoring matrix (substitution matrix), 
#' a gap opening penalty of -11, and a gap extension penalty of -1 (`blastp` default values)?
#' 
#' ** Alignment statistics — Length: ?, Identity: ? (?%), Gaps: ? (?%)

AlignGlobal_BLOSUM62 <- pwalign::pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM62", 
                                                   gapOpening = -11, gapExtension = -1) 

writePairwiseAlignments(AlignGlobal_BLOSUM62)

#' ## Q5. 
#' Check if the alignment made using the BLOSUM80 or BLOSUM45 scoring matrix 
#' (substitution matrix) is different from that when BLOSUM62 is used.
#' BLOSUM62 is the default matrix for protein BLAST (`blastp`).
#' BLOSUM80 is used for more closely related alignments, and 
#' BLOSUM45 is used for more distantly related alignments.  
#' 
#' ** The alignments using BLOSUM62, BLOSUM80, and BLOSUM45 are:  
#' 1. Different  
#' 2. Identical  

#data(package="pwalign")
AlignGlobal_BLOSUM62

AlignGlobal_BLOSUM80 <- pwalign::pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM80", 
                                                   gapOpening = -11, gapExtension = -1) 
AlignGlobal_BLOSUM80

AlignGlobal_BLOSUM45 <- pwalign::pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM45", 
                                                   gapOpening = -11, gapExtension = -1) 
AlignGlobal_BLOSUM45
#writePairwiseAlignments(AlignGlobal_BLOSUM80)
#writePairwiseAlignments(AlignGlobal_BLOSUM45)

#' ## Q6. 
#' Check whether the alignment result changes when the gap penalties are modified,
#' e.g., by setting gapOpening = -0.5, gapExtension = -11.5.  
#' 
#' ** When the gap penalties are modified, the alignment result is:  
#' 1. Changed (A lower gap opening penalty resulted in multiple shorter gaps)  
#' 2. Not changed  

AlignGlobal_BLOSUM62_gap <- pwalign::pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM62", 
                                                       gapOpening = -0.5, gapExtension = -11.5) 
AlignGlobal_BLOSUM62_gap
#writePairwiseAlignments(AlignGlobal_BLOSUM62_gap)

#' ## Q7. 
#' Check if the optimal local alignment is different from the optimal global alignment.  
#' 
#' ** The optimal local alignment and global alignment are:  
#' 1. Different  
#' 2. Identical  
AlignGlobal_BLOSUM62

AlignLocal_BLOSUM62 <- pwalign::pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM62", 
                                                  gapOpening = -11, gapExtension = -1, type="local")
AlignLocal_BLOSUM62
#writePairwiseAlignments(AlignLocal_BLOSUM62)

# Print R version and packages
sessionInfo()
Sys.time() # 2026-04
