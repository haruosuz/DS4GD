#' # assignment
#' - [Exercises](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#exercises)
#' - [Answers to the exercises on Sequence Alignment](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#sequence-alignment)

rm(list = ls()) # Clear R's environment

# Load the packages into R
library(seqinr)
library(pwalign)
library(Biostrings)

#' Record answers to the following questions.
#' Modify the example sentence and values as needed.
#' 
#' ## Q1. 
#' Download FASTA files of two homologous protein sequences from public databases.

# Generate URLs to retrieve protein sequences from NCBI
acc1 <- "EDD8358772.1" # Modify the accession number **
acc2 <- "HHE9944003.1" # Modify the accession number **
url1 <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=protein&id=", acc1, "&rettype=fasta&retmode=text")
url2 <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=protein&id=", acc2, "&rettype=fasta&retmode=text")

# Print URLs
url1
url2
# You can access these sequences by pasting the URLs into a web browser.

# Define local file names to save the sequences
filename1 <- paste0(acc1, ".fasta")
filename2 <- paste0(acc2, ".fasta")

# Download the FASTA files from the URLs to the local machine
download.file(url1, destfile = filename1)
download.file(url2, destfile = filename2)

# Read FASTA-formatted sequences from the downloaded local files
chars1 <- read.fasta(file = filename1, seqtype = "AA", strip.desc = TRUE)[[1]]
chars2 <- read.fasta(file = filename2, seqtype = "AA", strip.desc = TRUE)[[1]]

# get sequence length and annotation
length(chars1); getAnnot(chars1)
length(chars2); getAnnot(chars2)

# conversion of a vector of chars into a string
string1 <- c2s(chars1)
string2 <- c2s(chars2)

# convert strings to uppercase 
STRING1 <- toupper(string1)
STRING2 <- toupper(string2)

#' ## Q2. 
#' Create a dotplot for two sequences.
#' In the dotplot, the 1st sequence is plotted along the x-axis (horizontal axis), 
#' and the 2nd sequence is plotted along the y-axis (vertical axis). 
#' The dotplot displays a dot at points where there is an identical amino acid in the two sequences.  
#' 
#' Check if the two sequences are homologous.  
#' ** Homology suggested (diagonal line observed)? [Yes / No]
par(mfrow=c(1,2))
dotPlot(seq1 = chars1, seq2 = chars2)

#' ## Q3. 
#' What are the alignment statistics for the optimal global alignment between the two proteins 
#' when using the BLOSUM62 scoring matrix (substitution matrix), 
#' a gap opening penalty of -11, and a gap extension penalty of -1 (`blastp` default values)?
#' 
#' ** Alignment statistics — Length: 000, Identity: 000/000 (00.0%), Gaps: 00/000 (0.0%)

AlignGlobal_BLOSUM62 <- pwalign::pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM62", 
                                                   gapOpening = -11, gapExtension = -1) 
#AlignGlobal_BLOSUM62
writePairwiseAlignments(AlignGlobal_BLOSUM62)

#' ## Q4. 
#' Check if the alignment made using the BLOSUM80 or BLOSUM45 scoring matrix 
#' (substitution matrix) is different from that when BLOSUM62 is used.
#' BLOSUM62 is the default matrix for protein BLAST (`blastp`).
#' BLOSUM80 is used for more closely related alignments, and 
#' BLOSUM45 is used for more distantly related alignments.  
#data(package="pwalign")
#' ** BLOSUM62 and BLOSUM80 alignments are identical? [Yes / No]  
#' ** BLOSUM62 and BLOSUM45 alignments are identical? [Yes / No]  
AlignGlobal_BLOSUM80 <- pwalign::pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM80", 
                                                   gapOpening = -11, gapExtension = -1) 
#AlignGlobal_BLOSUM80
# Compare BLOSUM62 vs BLOSUM80 (Returns TRUE if identical, FALSE if different)
identical(
  c(as.character(pattern(AlignGlobal_BLOSUM62)), as.character(subject(AlignGlobal_BLOSUM62))), 
  c(as.character(pattern(AlignGlobal_BLOSUM80)), as.character(subject(AlignGlobal_BLOSUM80))))

AlignGlobal_BLOSUM45 <- pwalign::pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM45", 
                                                   gapOpening = -11, gapExtension = -1) 
#AlignGlobal_BLOSUM45
# Compare BLOSUM62 vs BLOSUM45 (Returns TRUE if identical, FALSE if different)
identical(
  c(as.character(pattern(AlignGlobal_BLOSUM62)), as.character(subject(AlignGlobal_BLOSUM62))), 
  c(as.character(pattern(AlignGlobal_BLOSUM45)), as.character(subject(AlignGlobal_BLOSUM45))))

#' ## Q5. 
#' Check whether the alignment result changes when the gap penalties are modified
#' from the default values (opening = -11, extension = -1) 
#' to new values (gapOpening = -0.5, gapExtension = -11.5).  
#' A lower gap opening penalty makes it easier to introduce new gaps.
#' 
#' ** Default and modified gap penalty alignments are identical? [Yes / No]
AlignGlobal_BLOSUM62_gap <- pwalign::pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM62", 
                                                       gapOpening = -0.5, gapExtension = -11.5) 
#AlignGlobal_BLOSUM62_gap
# Compare Default vs Modified Gap Penalties (Returns TRUE if identical, FALSE if different)
identical(
  c(as.character(pattern(AlignGlobal_BLOSUM62)), as.character(subject(AlignGlobal_BLOSUM62))), 
  c(as.character(pattern(AlignGlobal_BLOSUM62_gap)), as.character(subject(AlignGlobal_BLOSUM62_gap))))

#' ## Q6. 
#' Check if the optimal local alignment is different from the optimal global alignment.  
#' Global alignment covers the entire length of both sequences, whereas 
#' local alignment focuses only on the most similar regions, excluding poorly aligned regions at the ends of the proteins.
#' 
#' ** Local and global alignments are identical? [Yes / No]
AlignLocal_BLOSUM62 <- pwalign::pairwiseAlignment(STRING1, STRING2, substitutionMatrix = "BLOSUM62", 
                                                  gapOpening = -11, gapExtension = -1, type="local")
#AlignLocal_BLOSUM62
# Compare Global vs Local Alignment (Returns TRUE if identical, FALSE if different)
identical(
  c(as.character(pattern(AlignGlobal_BLOSUM62)), as.character(subject(AlignGlobal_BLOSUM62))), 
  c(as.character(pattern(AlignLocal_BLOSUM62)), as.character(subject(AlignLocal_BLOSUM62))))

# Print R version and packages
sessionInfo()
Sys.time() # 2026-04
