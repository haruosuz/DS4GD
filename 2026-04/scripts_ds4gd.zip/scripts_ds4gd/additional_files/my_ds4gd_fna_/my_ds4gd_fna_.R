#+ echo = TRUE
rm(list = ls())
#+ message = FALSE
library(tidyverse)
library(seqinr)
library(ape)
library(Biostrings)
library(DECIPHER)
#install.packages("RSQLite")
#library(RSQLite)
#' - https://github.com/haruosuz/DS4GD/blob/master/2019giga/CaseStudy.md#fna
# Make a vector containing NCBI accessions
ACCESSIONs <- c("BN000925", "U67194", "AB231906", "AM157767", "GQ983559", "AM261282", "AY950444", "KC170283", "CP006601") # IncP-1 plasmids
ACCESSIONs <- c("AP018710", "CP014764", "CP015073", "CP020602") # pSN1216-29 and related plasmids
#ACCESSIONs <- c("JX869059", "KY352407", "MN908947") # MERS-CoV, SARS-CoV, SARS-CoV-2

# Create a function to retrieve several nucleotide sequences from NCBI
retrieve_ncbi_fna <- function(ACCESSION) seqinr::read.fasta(file = paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text"), seqtype="DNA", strip.desc=TRUE)[[1]]

# Retrieve the sequences and store them in list variable
fna.seqs <- lapply(ACCESSIONs, retrieve_ncbi_fna)

# Write and Read FASTA files
file.fasta <- "mySequences.fna"
# Write sequence(s) into a file in fasta format
seqinr::write.fasta(sequences=fna.seqs, names=seqinr::getAnnot(fna.seqs), file.out=file.fasta, nbchar=max(seqinr::getLength(fna.seqs)))
# Read FASTA formatted files
fna.seqs <- seqinr::read.fasta(file=file.fasta, seqtype="DNA", strip.desc=TRUE)
length(fna.seqs)

# Apply a Function over a List
#lapply(fna.seqs, summary)
#sapply(fna.seqs, summary)
Length <- seqinr::getLength(fna.seqs) # get the length of sequences
GCcontent <- round( sapply(fna.seqs, seqinr::GC) , digits=3) # Global G+C content
Annotation <- unlist(seqinr::getAnnot(fna.seqs)) # sequence annotations
d.f <- data.frame(Length, GCcontent, Annotation)
knitr::kable(d.f, caption = "Table. DNA Sequence Statistics.")
#write.csv(d.f, file = "R.ds4gd_fna.csv", quote=TRUE, row.names=FALSE)

#' - https://github.com/haruosuz/DS4GD/blob/master/2017/hclust.md
#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#over-represented-and-under-represented-dna-words
myfun_rho <- function(x,k) seqinr::rho(c(x, ' ', rev(seqinr::comp(x))), wordsize=k)

par(cex=0.9) # Set Graphical Parameters
for(k in 2:3){
  myrho <- sapply(X=fna.seqs, FUN=myfun_rho, k)
  colnames(myrho) <- seqinr::getName(fna.seqs)
  filename <- paste0("R.fna.seqinr_rho_wordsize",k,".tsv")
  write.table(data.frame(myrho), file=filename, sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
  mydist <- as.dist(1-cor(myrho)); #print(mean(mydist))
  hc <- hclust(d=mydist, method="average"); #plot(hc, hang=-1, main=filename)
  heatmap(t(myrho), Rowv=as.dendrogram(hc), scale="none", margins=c(5,5), cexRow=1.0, cexCol=1/k, col=gray.colors(100, start=0.9, end=0.3), main=filename)
  tree.rho <- ape::ladderize(phy=ape::as.phylo(hc), right=TRUE)
  ape::write.tree(phy=tree.rho, file=paste0(filename,".tre") )
}

#' - https://github.com/haruosuz/r4bioinfo/tree/master/R_DECIPHER
#' - https://bioconductor.org/packages/release/bioc/vignettes/DECIPHER/inst/doc/ArtOfAlignmentInR.pdf
# Read an XStringSet object from a file
myDNAStringSet <- Biostrings::readDNAStringSet(file=file.fasta)
# Create a connection to a DBMS
dbConn <- DBI::dbConnect(RSQLite::SQLite(), ":memory:")
# Add Sequences from Text File to Database
DECIPHER::Seqs2DB(seqs=myDNAStringSet, type="XStringSet", dbFile=dbConn, identifier=names(myDNAStringSet))
# Finds Synteny in a Sequence Database
SyntenyObject <- DECIPHER::FindSynteny(dbFile=dbConn)
# Scatterplot Matrices
pairs(SyntenyObject, boxBlocks=TRUE)

#getwd()
#list.files()
sessionInfo()
Sys.time()
