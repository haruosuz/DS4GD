#' ---
#' title: "Little Book of R for Bioinformatics"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---

# clear the decks
rm(list = ls())

# load the packages
#+ warning = FALSE
#+ message = FALSE
library(seqinr)
library(Biostrings)
library(msa)
library(microseq)
library(ape)

#' ## [多重整列と系統樹](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#multiple-alignment-and-phylogenetic-trees)
#' ## [Multiple Alignment and Phylogenetic trees](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html)
#' **多重整列と系統樹**
#' 
#' ![https://bioinf.comav.upv.es/courses/biotech3/theory/phylogeny.html](https://bioinf.comav.upv.es/courses/biotech3/static/phylogeny/phylo_msa.png)
#' 
#' ### [Retrieving a list of sequences from UniProt](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#retrieving-a-list-of-sequences-from-uniprot)
#' **UniProtから複数の配列を取得**
#' 
#' [狂犬病ウイルス](https://ja.wikipedia.org/wiki/狂犬病ウイルス) Rabies virus, Mokola virus, Lagos bat virus, West Caucasian bat virus の 
#' Phosphoprotein のタンパク質配列（UniProt accession: 
#' [P06747](http://www.uniprot.org/uniprot/P06747), 
#' [P0C569](http://www.uniprot.org/uniprot/P0C569), 
#' [O56773](http://www.uniprot.org/uniprot/O56773), 
#' [Q5VKP1](http://www.uniprot.org/uniprot/Q5VKP1)）を取得し、FASTA形式で保存する:  

# create a function to retrieve several sequences from UniProt
read.fasta.uniprot <- function(ACCESSION) seqinr::read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]

ACCESSIONs <- c("P06747", "P0C569", "O56773", "Q5VKP1") # Make a vector containing the names of the sequences
seqs <- lapply(ACCESSIONs, read.fasta.uniprot) # Retrieve the sequences and store them in list variable "seqs"
length(seqs)      # Print out the number of sequences retrieved
seq1 <- seqs[[1]] # Get the 1st sequence
seq1[1:6]         # Print out the first 6 letters of the 1st sequence
seq2 <- seqs[[2]] # Get the 2nd sequence
seq2[1:6]         # Print out the first 6 letters of the 2nd sequence

# write out the sequences to a FASTA file
write.fasta(sequences=seqs, names=ACCESSIONs, file.out="my_aa.fasta")

#' ### [Creating a multiple alignment of protein, DNA or mRNA sequences using CLUSTAL](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#creating-a-multiple-alignment-of-protein-dna-or-mrna-sequences-using-clustal)
#' **CLUSTALを用いたタンパク質/DNA/mRNA配列の多重アラインメントの作成**

#library(Biostrings)
# Read an XStringSet object from a file
myAAStringSet <- readAAStringSet(file = "my_aa.fasta")

#library(msa)
# Multiple Sequence Alignment using ClustalW
myMsaAAMultipleAlignment <- msa(inputSeqs=myAAStringSet, method="ClustalW")

# write an XStringSet object to a file
writeXStringSet(x = unmasked(myMsaAAMultipleAlignment), filepath = "my_aa_msa.fasta")

#' ### [Viewing a long multiple alignment](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#viewing-a-long-multiple-alignment)
#' **多重アラインメントの表示**

print(myMsaAAMultipleAlignment, show="complete")

#' ### [Reading a multiple alignment file into R](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#reading-a-multiple-alignment-file-into-r)
#' **多重アラインメントのファイルをRに読み込む**

myAln <- seqinr::read.alignment(file = "my_aa_msa.fasta", format = "fasta")
names(myAln)
myAln$seq

#' ### [Discarding very poorly conserved regions from an alignment](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#discarding-very-poorly-conserved-regions-from-an-alignment)
#' **アラインメントから保存度の低い領域を破棄する**
#' 
#' Trimming a multiple sequence alignment by discarding columns with too many gaps.
#' 
#' 多重配列アラインメントからギャップの多い列を破棄する

#library(microseq)
msa.untrimmed <- readFasta(in.file = "my_aa_msa.fasta")
print(nchar(msa.untrimmed$Sequence))
msa.trimmed <- msaTrim(msa = msa.untrimmed, gap.end = 0.5, gap.mid = 0.9)
print(nchar(msa.trimmed$Sequence))
writeFasta(fdta = msa.trimmed, out.file = "my_aa_msa_trim.fasta", width = 80)
#myAln <- seqinr::read.alignment(file = "my_aa_msa_trim.fasta", format = "fasta")

#' ### [Calculating genetic distances between protein sequences](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#calculating-genetic-distances-between-protein-sequences)
#' **タンパク質配列間の遺伝的距離を計算する**

mydist <- dist.alignment(x = myAln, matrix = "similarity") # Calculate the pairwise distances
mydist # Print out the distance matrix
#as.matrix(mydist)
#as.dist(as.matrix(mydist))
#as.matrix(summary(as.numeric(mydist)))

#' The pairwise distance between O56773 and P0C569 is the smallest (0.4142670).  
#' The pairwise distance between Q5VKP1 and O56773 is the greatest (0.5067117).  
#' 遺伝的距離は、
#' "O56773"と"P0C569"との間で最小（0.4142670）、
#' "Q5VKP1"と"O56773"との間で最大（0.5067117）。
#' 
#' ### [Building an unrooted phylogenetic tree for protein sequences](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#building-an-unrooted-phylogenetic-tree-for-protein-sequences)
#' **タンパク質配列の無根系統樹の構築**
#' 
#' Based on the distance matrix, an unrooted phylogenetic tree is inferred
#' using the [Neighbor-Joining (NJ) algorithm](https://en.wikipedia.org/wiki/Neighbor_joining).  
#' 距離行列に基づいて、[近隣結合法 NJ (Neighbor-Joining)](https://ja.wikipedia.org/wiki/近隣結合法) により無根系統樹を構築する。  
#library(ape)
# construct a phylogenetic tree with the neighbor joining algorithm
mytree <- nj(mydist)
# plot the tree:
plot.phylo(mytree, type="unrooted")

#' Cutting a branch in an unrooted tree separates multiple sequences into two groups.
#' Q5VKP1 and P06747 in one group, O56773 and P0C569 in the other.  
#' 系統樹の枝を切断すると、二群に分かれる。
#' "Q5VKP1"と"P06747"が一方の群、"O56773"と"P0C569"がもう一方の群。
#' 
#' ### [Building a rooted phylogenetic tree for protein sequences](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#building-a-rooted-phylogenetic-tree-for-protein-sequences)
#' **タンパク質配列の有根系統樹の構築**
#' 
#' To root an unrooted tree, we add an outgroup sequence that is 
#' known to be more distantly related to the ingroup sequences.
#' Using the Fox-1 protein homologous sequences from three Caenorhabditis 
#' species (C. elegans and its close relatives) as the ingroup and the 
#' distantly related fruitfly (Drosophila melanogaster) as the outgroup, 
#' we infer a rooted phylogenetic tree based on multiple sequence alignment.
#' 
#' 無根系統樹を有根化するために、内群よりも遠縁であることがわかっている外群を追加する。
#' 内群として3種の Caenorhabditis 属（C. elegans とその近縁種）、
#' 外群として遠縁なショウジョウバエ (Drosophila melanogaster) の
#' Fox-1 タンパク質相同配列を用いて、多重配列アラインメントに基づく有根系統樹を構築する。
#' 
# retrieve several sequences from UniProt
# Make a vector containing the names of the sequences
myIngroup <- c("Q10572","E3M2K8","A8WS01")
myOutgroup <- c("Q9VT99")
ACCESSIONs <- c(myIngroup, myOutgroup)
ACCESSIONs
# Retrieve the sequences and store them in list variable "seqs"
seqs <- lapply(ACCESSIONs, read.fasta.uniprot)

getLength(seqs) # get the length of sequences
getAnnot(seqs) # get sequence annotations

# write out the sequences to a FASTA file
write.fasta(sequences=seqs, names=ACCESSIONs, file.out="my_aa.fasta")

# Read an XStringSet object from a file
myAAStringSet <- readAAStringSet(file = "my_aa.fasta")

# Multiple Sequence Alignment using ClustalW
myMsaAAMultipleAlignment <- msa(inputSeqs=myAAStringSet, method="ClustalW")
myMsaAAMultipleAlignment

# write an XStringSet object to a file
writeXStringSet(x = unmasked(myMsaAAMultipleAlignment), filepath = "my_aa_msa.fasta")

# Trimming a multiple sequence alignment by discarding columns with too many gaps.
msa <- readFasta(in.file = "my_aa_msa.fasta")
print(nchar(msa$Sequence))
msa.trimmed <- msaTrim(msa, gap.end = 0.3, gap.mid = 0.9)
print(nchar(msa.trimmed$Sequence))
writeFasta(fdta = msa.trimmed, out.file = "my_aa_msa_trim.fasta", width = 80)

# read the FASTA-format alignment into R
myAln <- read.alignment(file = "my_aa_msa_trim.fasta", format = "fasta")
myAln$seq

# Calculating pairwise distances from aligned sequences
mydist <- dist.alignment(x = myAln, matrix = "similarity") # Calculate the pairwise distances
mydist # Print out the distance matrix

# construct a phylogenetic tree with the neighbor joining algorithm
mytree <- nj(mydist) # infer a tree
mytree
mytree <- root(phy=mytree, outgroup=myOutgroup, resolve.root=TRUE) # roots the tree
mytree
plot.phylo(mytree, type="phylogram") # plot the tree

#' Q10572 and A8WS01 are sister groups, 
#' meaning they share a more recent common ancestor 
#' with each other than with any other sequences. 
#' Together with all descendants of their most recent common ancestor (MRCA), 
#' they form a monophyletic group or clade. 
#' This clade and E3M2K8 are sister groups. 
#' Including all descendants of their MRCA, they form another clade. 
#' The unrooted tree is rooted with Q9VT99 as the outgroup, 
#' the most distantly related sequence compared to any in the ingroup.
# Is Group Monophyletic
ACCESSIONs
ape::is.monophyletic(phy=mytree, tips=ACCESSIONs[c(1,2)])
ape::is.monophyletic(phy=mytree, tips=ACCESSIONs[c(1,3)])

#' ### [Saving a phylogenetic tree as a Newick-format tree file](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#saving-a-phylogenetic-tree-as-a-newick-format-tree-file)
#' **系統樹をNewick形式ファイルとして保存する**

write.tree(phy = mytree, file = "my_aa_msa_trim_nj.tre")

#' ### [Calculating genetic distances between DNA/mRNA sequences](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#calculating-genetic-distances-between-dna-mrna-sequences)
#' **DNA/mRNA配列間の遺伝的距離を計算する**
#' 
#' Duvenhage virus, Mokola virus, Lagos bat virus v006株, Lagos bat virus V267株 の Phosphoprotein の mRNA配列（NCBI accession: 
#' [AF049115](https://www.ncbi.nlm.nih.gov/nuccore/AF049115), 
#' [AF049118](https://www.ncbi.nlm.nih.gov/nuccore/AF049118), 
#' [AF049114](https://www.ncbi.nlm.nih.gov/nuccore/AF049114), 
#' [AF049119](https://www.ncbi.nlm.nih.gov/nuccore/AF049119)）を取得し、FASTA形式で保存する:  
#' 
# create a function to retrieve several nucleotide sequences from NCBI
read.fasta.ncbi_nuccore <- function(ACCESSION) seqinr::read.fasta(file = paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text"), seqtype="DNA", strip.desc=TRUE)[[1]]

# retrieve several nucleotide sequences from NCBI
ACCESSIONs <- c("AF049115", "AF049118", "AF049114", "AF049119") # Make a vector containing the names of the sequences
seqs <- lapply(ACCESSIONs, read.fasta.ncbi_nuccore) # Retrieve the sequences and store them in list variable "seqs"

# write out the sequences to a FASTA-format file
write.fasta(seqs, ACCESSIONs, file="my_nt.fasta")

# Read an XStringSet object from a file
myDNAStringSet <- readDNAStringSet(file = "my_nt.fasta")

# Multiple Sequence Alignment using ClustalW
myMsaDNAMultipleAlignment <- msa(myDNAStringSet)
myMsaDNAMultipleAlignment

# convert msa for the seqinr package
seqinr_alignment <- msaConvert(myMsaDNAMultipleAlignment, type="seqinr::alignment")

# calculate a genetic distance for DNA/mRNA sequences
myDNAbin <- as.DNAbin(seqinr_alignment)   # Convert the alignment to "DNAbin" format
mydist <- dist.dna(myDNAbin, model="K80") # Calculate the distance matrix
mydist # Print out the distance matrix

#' ### [Building a phylogenetic tree for DNA or mRNA sequences](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#building-a-phylogenetic-tree-for-dna-or-mrna-sequences)
#' **DNA/mRNA配列の系統樹の構築**

# construct a phylogenetic tree with the neighbor joining algorithm
mytree <- nj(mydist) # infer a tree
plot.phylo(mytree, type="unrooted") # plot the tree
unlist(getAnnot(seqs)) # get sequence annotations

#' ### [Summary](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#summary)
#' 
#' ### [Links and Further Reading](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#links-and-further-reading)
#' 
#' - This entry is no longer annotated in UniProtKB and can be found in UniParc.
#'   - https://www.uniprot.org/uniprotkb/E1FUV2/history
#'   - https://www.uniprot.org/uniprotkb/A8NSK3/history
#' -
#' - https://en.wikipedia.org/wiki/Split_(phylogenetics)
#' -
#' - https://en.wikipedia.org/wiki/Sister_group
#' - https://ja.wikipedia.org/wiki/姉妹群
#' -
#' - https://en.wikipedia.org/wiki/Most_recent_common_ancestor
#' - https://ja.wikipedia.org/wiki/最も近い共通祖先
#' -
#' - https://en.wikipedia.org/wiki/Clade
#' - https://en.wikipedia.org/wiki/Monophyly
#' - https://ja.wikipedia.org/wiki/系統群
#' - https://ja.wikipedia.org/wiki/単系統群
#' - https://ja.wikipedia.org/wiki/分岐学
#' -
#' - McLennan, D.A. How to Read a Phylogenetic Tree. Evo Edu Outreach 3, 506–519 (2010). https://doi.org/10.1007/s12052-010-0273-6
#' a simplified phylogenetic tree of the dinosaurs (Fig. 7)
#' 
#' ### [Exercises](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#exercises)
#' **演習**
#' [回答例](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#multiple-alignment-and-phylogenetic-trees)
#'  
sessionInfo()
