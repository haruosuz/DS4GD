#' # function
#' - [A brief introduction to R](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#a-brief-introduction-to-r)
#' - [A little more introduction to R](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#a-little-more-introduction-to-r)
#' - 2017.12.23 関数の作り方 | R の関数を一から作る方法 https://stats.biopapyrus.jp/r/basic/function.html  
#' - [19 Functions | R for Data Science](https://r4ds.had.co.nz/functions.html)
#' - [25 Functions – R for Data Science (2e)](https://r4ds.hadley.nz/functions.html)
# create our own functions
# create a function to calculate the value of 20 plus square of some input number:
myfunction <- function(x) { return(20 + (x*x)) }
# view the code that makes up a function by typing its name
myfunction
# use the function for different input numbers (eg. 10, 25):
myfunction(10)
myfunction(25)

#' # assignment
#' - [Exercises](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#exercises)
#' - [Answers to the exercises on DNA Sequence Statistics (2)](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#dna-sequence-statistics-2)
#' 
# Clear R's environment
rm(list = ls())

# Load the packages into R
library(ape)
library(seqinr)
library(zoo)

#' Record answers to the following questions.
#' Modify the example sentence and values as needed.
#' 
#' Download the DNA sequence of your genome of interest.
# Retrieving a DNA sequence from NCBI
ACCESSION <- "M28829" # Modify the accession number **
filename <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text")
#filename <- paste0("http://togows.org/entry/nucleotide/",ACCESSION,".fasta")
#ape::write.FASTA(x=ape::read.GenBank(ACCESSION), file="myNT.fasta"); filename <- "myNT.fasta"
seqs <- read.fasta(file=filename, seqtype="DNA", strip.desc=TRUE)
#write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=paste0(ACCESSION,".fasta") )
seq1 <- seqs[[1]] # extract the 1st element from list
getAnnot(seq1) # get sequence annotations
getLength(seq1) # get the length of sequences

#' ## Q1. 
#' Write a function to calculate the AT content of a DNA sequence 
#' (ie. the fraction of the nucleotides in the sequence that are As or Ts). 
#' What is the AT content of the genome?

# Here is a function to calculate the AT content of a genome sequence:
AT <- function(x){ library("seqinr"); 1 - GC(x) }

# use the function to calculate the AT content of the genome:
AT(seq1)

# AT = 1 - GC, ie. (AT + GC = 1):
GC(seq1)
AT(seq1) + GC(seq1)

#' ## Q2
#' Draw a sliding window plot of GC content in the genome sequence,
#' using an appropriate window size (e.g., 500, 1000, 10000, 100000 nucleotides).
#' Are there any regions of unusual DNA content in the genome (e.g., a high peak or a low trough)?

# write a function to make a sliding window plot:
slidingwindowplotGC <- function(windowsize, inputseq)
{
  # this function requires the 'zoo' R package #install.packages("zoo")
  require("zoo")
  x <- seq(from = 1, to = length(inputseq)-windowsize, by = windowsize)
  y <- rollapply(data = inputseq, width = windowsize, by = windowsize, FUN = GC)
  plot(x, y, type="l", xlab="Position (bp)", ylab="GC content")
  }

# make a sliding window plot of GC content:
window_size <- 500 # Adjust as needed **
slidingwindowplotGC(windowsize = window_size, inputseq = seq1)

#' The GC content is relatively low near 7500 bases and high near 6000 bases. **
#' 
#' ## Q3. 
#' Write a function to draw a sliding window plot of AT content.

# write a function to make a sliding window plot:
slidingwindowplotAT <- function(windowsize, inputseq)
{
  require("zoo")
  x <- seq(from = 1, to = length(inputseq)-windowsize, by = windowsize)
  AT <- function(x){ library("seqinr"); 1 - GC(x) }
  y <- rollapply(data = inputseq, width = windowsize, by = windowsize, FUN = AT)
  plot(x, y, type="l", xlab="Position (bp)", ylab="AT content")
  }

#' Use it to make a sliding window plot of AT content along the genome. 
par(mfrow=c(2,1), mgp=c(1.7, 0.5, 0), mar=c(3, 3, 1, 1), cex=0.9) # c(bottom, left, top, right)
# make a sliding window plot of AT content:
slidingwindowplotAT(windowsize = window_size, inputseq = seq1)
# This is the mirror image of the plot of GC content (because AT equals 1 minus GC):
slidingwindowplotGC(windowsize = window_size, inputseq = seq1)

#' ## Q4. 
#' The odds ratio (Rho statistic) is defined as the ratio of 
#' the observed to expected relative frequency of oligonucleotides.
#' A rho value greater than 1 (rho > 1) indicates over-representation, whereas 
#' a rho value less than 1 (rho < 1) indicates under-representation.
#' Which 2-nucleotide word is most over-represented or under-represented in the genome sequence?
 
# calculate the Rho statistic for words of length 2 in the genome
rho(sequence = seq1, wordsize = 2)
# sort the results to find the lowest and highest values
sort(rho(sequence = seq1, wordsize = 2))

#' The Rho value is lowest for "ta" (0.6356692). **
#' This DNA word is most under-represented in the genome sequence.  
#' The Rho value is highest for "at" (1.2652844). **
#' This DNA word is most over-represented in the genome sequence.
#' 
#' The DNA word "ta" is most under-represented (rho = 0.6356692), and "at" is most over-represented (rho = 1.2652844) in the genome sequence. **
#' 
# Print R version and packages
sessionInfo()
Sys.time() # 2026-04