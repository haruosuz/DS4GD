#' # assignment
#' - [Exercises](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#exercises)
#' - [Answers to the exercises on Multiple Alignment and Phylogenetic Trees](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#multiple-alignment-and-phylogenetic-trees)

rm(list = ls()) # Clear R's environment

# Load the packages into R
#+ warning = FALSE
#+ message = FALSE
library(seqinr)
library(Biostrings)
library(msa)
library(microseq)
library(ape)

#' - https://en.wikipedia.org/wiki/Split_(phylogenetics)
# Function to display a split (bipartition of a set of taxa)
# Branch lengths are ignored; only topology is considered
# Cutting an internal branch in an unrooted tree separates multiple sequences into two groups
display_splits <- function(myphy) {
  myphy$edge.length <- NULL
  splits <- prop.part(myphy)
  internal_splits <- splits[sapply(splits, function(x) length(x) > 1 & length(x) < length(myphy$tip.label))]
  for(i in seq_along(internal_splits)) {
    group1 <- myphy$tip.label[internal_splits[[i]]]
    group2 <- setdiff(myphy$tip.label, group1)
    cat(sprintf("Split %d:\n  Group 1: (%s);\n  Group 2: (%s);\n\n",
                i, paste(group1, collapse=","), paste(group2, collapse=",")))
  }
}

#' Record answers to the following questions.
#' Modify the example sentence and values as needed.
#' 
#' ## Q1. 
#' Calculate pairwise distances between aligned homologous sequences.
#' Identify the pairs with the smallest and greatest distances.
# Retrieve several sequences from UniProt
# Make a vector containing the names of the sequences
myIngroup <- c("Q9YRR4", "Q9YP96", "B0LSS3", "Q6TFL5") # "Dengue virus"
myOutgroup <- c("Q32ZE1", "P0DOK8") # "Zika virus" "Japanese encephalitis virus"
ACCESSIONs <- c(myIngroup, myOutgroup)
ACCESSIONs

# Create a function to retrieve several sequences from UniProt
read.fasta.uniprot <- function(ACCESSION) seqinr::read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]

# Retrieve the sequences and store them in list variable "seqs"
seqs <- lapply(ACCESSIONs, read.fasta.uniprot)

# Get the number of elements
length(seqs)

# Get the length of sequences
seqinr::getLength(seqs)

# Get sequence annotations
unlist(seqinr::getAnnot(seqs))

# write out the sequences to a FASTA file
seqinr::write.fasta(sequences=seqs, names=ACCESSIONs, file.out="my_aa.fasta")

# Read an XStringSet object from a file
myAAStringSet <- Biostrings::readAAStringSet(file = "my_aa.fasta")

# Multiple Sequence Alignment using ClustalW
library(msa)
myMsaAAMultipleAlignment <- msa::msa(inputSeqs=myAAStringSet, method="ClustalW")
myMsaAAMultipleAlignment
print(myMsaAAMultipleAlignment, show="complete")

#' The alignment contains a lot of columns with gaps in them. 
#' This could possibly be adding noise to the phylogenetic analysis.

# write an XStringSet object to a file
Biostrings::writeXStringSet(x = unmasked(myMsaAAMultipleAlignment), filepath = "my_aa_msa.fasta")

# read the FASTA-format alignment into R
myAln <- seqinr::read.alignment(file = "my_aa_msa.fasta", format = "fasta")

# calculate the pairwise distances between the protein sequences
mydist <- seqinr::dist.alignment(x = myAln, matrix = "similarity")
mydist
#as.matrix(mydist)
#as.dist(as.matrix(mydist))
#as.matrix(summary(as.numeric(mydist)))

#' Based on the distance matrix, 
#' B0LSS3 and Q9YP96 have the smallest pairwise distance (0.2268713), and 
#' Q32ZE1 and P0DOK8 have the greatest pairwise distance (0.4379016).
#' 
#' ## Q2. 
#' Build an unrooted phylogenetic tree of the proteins, using the neighbour-joining algorithm. 
#' Which are grouped together in the tree?

# construct a phylogenetic tree with the neighbor joining algorithm
mytree <- ape::nj(mydist)
ape::plot.phylo(mytree, type = "unrooted")
#display_splits(mytree)
#' Cutting a branch in an unrooted tree separates multiple sequences into two groups.
#' For example, B0LSS3 and Q9YP96 are grouped together.
#' 
#' ## Q3. 
#' Build an unrooted phylogenetic tree of the proteins, based on a trimmed alignment of the proteins. 
#' Does this differ from the tree based on the untrimmed alignment (in Q2)?
# Trimming a multiple sequence alignment by discarding columns with too many gaps.
#library(microseq)
msa.untrimmed <- microseq::readFasta(in.file = "my_aa_msa.fasta")
print(nchar(msa.untrimmed$Sequence))
msa.trimmed <- microseq::msaTrim(msa = msa.untrimmed, gap.end = 0.3, gap.mid = 0.9)
print(nchar(msa.trimmed$Sequence))
microseq::writeFasta(fdta = msa.trimmed, out.file = "my_aa_msa_trim.fasta", width = 80)

# read the FASTA-format alignment into R
myAln <- seqinr::read.alignment(file = "my_aa_msa_trim.fasta", format = "fasta")
unlist(myAln$seq)

# calculate the pairwise distances between the protein sequences
mydist <- seqinr::dist.alignment(x = myAln, matrix = "similarity")

# construct a phylogenetic tree
mytree <- ape::nj(mydist)
ape::plot.phylo(mytree, type = "unrooted", main="unrooted tree")
#display_splits(mytree)
#' Example interpretation sentences:  
#' 
#' - Tree topologies changed.  
#' The trimmed and untrimmed alignments produce different tree topologies,
#' suggesting that gappy columns in the original alignment added noise to the analysis.  
#' 
#' - Tree topologies unchanged.  
#' The trimmed and untrimmed alignments produce the same tree topology,
#' suggesting that gappy columns in this case did not strongly affect the analysis.  
#' 
#' ## Q4. 
#' Build a rooted phylogenetic tree of the proteins, based on a trimmed alignment, using an outgroup. 
#' Which are the most closely related proteins, based on the tree? 
#' What extra information does this tree tell you, compared to the unrooted tree in Q3?
mytree <- ape::root(phy=mytree, outgroup=myOutgroup, resolve.root=TRUE)
#mytree <- ape::ladderize(mytree, right = FALSE)
ape::plot.phylo(mytree, type="phylogram", main="rooted tree")

#' **Figure. Rooted phylogenetic tree of homologous proteins.**
#' Pairwise distances were calculated using the `dist.alignment` function (`seqinr` v4.2.36).
#' The unrooted tree was inferred using the Neighbor-Joining algorithm (`nj` function),
#' then rooted using the `root` function with an outgroup,
#' and plotted with `plot.phylo` (`ape` v5.8.1).
#' The analysis was carried out in R version 4.4.1 (2024-06-14).
#' 
#' -----
#' 
#' B0LSS3 and Q9YRR4 are sister groups, 
#' meaning they share a more recent common ancestor 
#' with each other than with any other sequences. 
#' Together with all descendants of their most recent common ancestor (MRCA), 
#' they form a monophyletic group or clade. 
#' This clade and Q9YP96 are sister groups. 
#' Including all descendants of their MRCA, 
#' they form another clade, which is a sister group to Q6TFL5. 
#' The unrooted tree is rooted with Q32ZE1 and P0DOK8 as the outgroup, 
#' the most distantly related sequence compared to any in the ingroup.
#' 
#' Note that outgroup (Q32ZE1 and P0DOK8) and Q6TFL5 were grouped together in one split of the unrooted tree.
#' 
#' Unlike the unrooted tree, 
#' the rooted tree tells us the direction of evolutionary divergence, 
#' allowing us to determine which lineages share more recent common ancestors 
#' and to infer the relative order of branching events.

# Saving a phylogenetic tree as a Newick-format tree file
ape::write.tree(phy = mytree, file = "my_aa_msa_trim_nj.tre")

# Print a tree in parenthetic format using the Newick format.
#mytree$edge.length <- NULL # remove branch lengths
ape::write.tree(phy = mytree)

# Print R version and packages
sessionInfo()
Sys.time() # 2026-04