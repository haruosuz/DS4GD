#' ---
#' title: "Inferring Phylogenetic Trees"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      theme: united
#'      highlight: tango
#'      toc: true
#' ---
#' 
# Clear R's environment
rm(list = ls())

# Load the required packages
#+ warning = FALSE
#+ message = FALSE
library(Peptides)
library(rentrez)
library(seqinr)
library(ape)
library(phangorn)
library(phytools)
library(microseq)
library(Biostrings)
library(DECIPHER)
library(ggseqlogo)
library(tidyverse)

# parameters
mycex <- 0.90 # Graphical Parameters
#par(mfrow=c(1,1), mgp=c(1.7, 0.5, 0), mar=c(1.5, 0.5, 1, 0.5), cex=mycex) # c(bottom, left, top, right)
database <- "ncbi_protein"
#database <- "uniprot"
#' - https://cran.r-project.org/web/packages/phangorn/vignettes/Trees.html
UPGMA_NJ <- "UPGMA"
#UPGMA_NJ <- "NJ"
# ?phangorn::dist.ml 
mymodel <- "LG" # "WAG", "JTT", "LG", "Dayhoff", , "Blosum62", ,
myexclude <- "pairwise" # "none", "all", "pairwise"
#myexclude <- "all" # "none", "all", "pairwise"
#' - https://academic.oup.com/sysbio/article/69/2/265/5541794
#' Distance matrices used in the MSA-with-complete-gap-deletion and the MSA-with-pairwise-gap-deletion approaches of the NJ method were computed using the phangorn 2.4.0 package (Schliep 2011) on R environment with the WAG
#' substitution model and dist.ml function with parameter exclude=“all” and “pairwise,” respectively.
#' Phylogenetic reconstruction was conducted using the same package. Bootstrap values were computed using the bootstrap.phyDat function of the same package (bs = 100).
#' 
#' # Acquiring the Sequences
file.fasta <- "myAA.fasta" # FASTA file of protein (amino acid) sequences
download <- ifelse(!file.exists(file.fasta), TRUE, FALSE)
# Retrieve the sequences and store them in list variable "seqs"
if(download){
  if (database == "ncbi_protein") {
    ACCESSIONs <- c("NP_001393", "WP_010885563", "WP_165740382", "NP_001952", "WP_048053510", "WP_244340847") # elongation factor # ISBN-10:4339027359 p.195
    
    #seqs <- lapply(ACCESSIONs, function(x) rentrez::entrez_fetch(db="protein", id=x, rettype="fasta"))
    #write(unlist(seqs), file=file.fasta)
    
    # Create a function to retrieve several protein sequences from NCBI
    read.fasta.protein <- function(ACCESSION) seqinr::read.fasta(file = paste0("http://togows.dbcls.jp/entry/protein/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
    seqs <- lapply(ACCESSIONs, read.fasta.protein)
    write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=file.fasta, nbchar=max(getLength(seqs)))

  } else if (database == "uniprot") {
    ACCESSIONs <- c("P68104", "Q8U152", "P33166", "P13639", "P61877", "P80868") # Elongation factor
    #ACCESSIONs <- c("P01958", "P69905", "P69907", "P02062", "P68871", "P68873") # Hemoglobin subunit
    #ACCESSIONs <- c("P60174", "P00939", "P00942", "P0A858") # Triosephosphate isomerase
    
    # Create a function to retrieve several sequences from UniProt
    read.fasta.uniprot <- function(ACCESSION) seqinr::read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
    seqs <- lapply(ACCESSIONs, read.fasta.uniprot)
    # Write sequence(s) in FASTA formatted files
    write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=file.fasta, nbchar=max(getLength(seqs)))
  }
}

#' Read amino-acid sequences from a file in FASTA format.
seqs <- read.fasta(file=file.fasta, seqtype="AA", strip.desc=TRUE)

# Get sequence features: hydrophobicity, length, and annotations
Hydrophobicity <- Peptides::hydrophobicity(seqs, scale="KyteDoolittle")
Length <- getLength(seqs) # get the length of sequences
Annotation <- unlist(getAnnot(seqs)) # get sequence annotations

# Pattern Matching and Replacement
Accession <- gsub(pattern="^(UniRef[0-9]+_)*(sp\\|)?([^ .|]+).*", replacement="\\3", x=Annotation)
Accession <- gsub(pattern="^(UniRef[0-9]+_)*((sp|tr)\\|)?([^ .|]+).*", replacement="\\4", x=Annotation)

ProteinName <- Annotation
# "sp|P21074.3|A57_VACCC RecName: Full=Guanylate kinase homolog"
#ProteinName <- gsub(pattern="^([^ ]+) (RecName: .+)", replacement="\\2", x=ProteinName)
# "sp|P21074|A57_VACCC Guanylate kinase homolog OS=Vaccinia virus (strain Copenhagen) OX=10249 GN=A57R PE=3 SV=3"               
# "UniRef50_A0A4Y5MWZ9 Guanylate kinase-like domain-containing protein n=5 Tax=Orthopoxvirus TaxID=10242 RepID=A0A4Y5MWZ9_9POXV"
#ProteinName <- gsub(pattern="^([^ ]+) (.+) (OS|n)=.+", replacement="\\2", x=ProteinName)
# "AAM13634.1 CPXV195 protein [Cowpox virus]"
#ProteinName <- gsub(pattern="^([^ ]+) (.+) \\[(.+)\\]", replacement="\\2", x=ProteinName)
# one line
ProteinName <- gsub(pattern="^([^ ]+) (.+?) (\\[.+\\])$|^([^ ]+) (.+?) (OS|n)=.+|^([^ ]+) (RecName: .+)", replacement="\\2\\5\\8", x=ProteinName)
#ProteinName

OrganismName <- Annotation
# "AAM13634.1 CPXV195 protein [Cowpox virus]"
#OrganismName <- gsub(pattern=".+\\[(.+)\\]", replacement="\\1", x=OrganismName)
# "sp|P21074|A57_VACCC Guanylate kinase homolog OS=Vaccinia virus (strain Copenhagen) OX=10249 GN=A57R PE=3 SV=3"               
# "UniRef50_A0A4Y5MWZ9 Guanylate kinase-like domain-containing protein n=5 Tax=Orthopoxvirus TaxID=10242 RepID=A0A4Y5MWZ9_9POXV"
#OrganismName <- gsub(pattern=".+ (OS|Tax)=(.+) (OX|TaxID)=.+", replacement="\\2", x=OrganismName)
# "sp|P21074.3|A57_VACCC RecName: Full=Guanylate kinase homolog"
#OrganismName <- gsub(pattern="sp\\|[^|]+\\|([^ ]+) RecName: .*", replacement="\\1", x=OrganismName)
# one line
OrganismName <- gsub(pattern=".+\\[(.+)\\]|.+(OS|Tax)=(.+) (OX|TaxID)=.+|sp\\|[^|]+\\|([^ ]+) RecName: .*", replacement="\\1\\3\\5", x=OrganismName)
#OrganismName

# Creates data frame (table)
#Annotation <- substr(x=Annotation, start=1, stop=70)
mydata <- data.frame(Hydrophobicity, Length, Accession, ProteinName, OrganismName, Annotation) %>% arrange(desc(`Length`))
knitr::kable(x = mydata, caption = "Table 1. Sequence data.")

# Filter sequences based on length criteria
#hist(mydata$Length) # Histograms
summary(mydata$Length) # Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
length_min <- min(Length); length_min # Replace this value with your own criteria.
length_max <- max(Length); length_max # Replace this value with your own criteria.
TF <- length_min <= Length & Length <= length_max; summary(TF); seqs <- seqs[TF]
#TF <- grepl(pattern="MAG:|partial|Fragment|Isoform", x=getAnnot(seqs), ignore.case=TRUE); summary(TF); seqs <- seqs[!TF]
# Write sequence(s) in FASTA formatted files
file.fasta <- "myAA_filtered.fasta"
mynames <- getAnnot(seqs)
mynames <- getName(seqs)
#mynames <- gsub(pattern="\\..+", replacement="", x=getName(seqs)) # alignment and tree need to have the same names in PhyKIT
write.fasta(sequences=seqs, names=mynames, file.out=file.fasta, nbchar=max(getLength(seqs)))

#' # Aligning the Sequences
#' - Vignettes: [The Art of Multiple Sequence Alignment in R](https://bioconductor.org/packages/release/bioc/vignettes/DECIPHER/inst/doc/ArtOfAlignmentInR.pdf)
#library(DECIPHER)
myAAStringSet <- Biostrings::readAAStringSet(filepath=file.fasta)
myAlignAA <- DECIPHER::AlignSeqs(myAAStringSet)
#myAlignAA <- subseq(myAlignAA, start=73, end=162)
myAlignAA
#DECIPHER::BrowseSeqs(myAlignAA, threshold = 0.5) # ?ConsensusSequence

# write an XStringSet object to a file
file.align.untrimmed <- "myAlign.fasta"
Biostrings::writeXStringSet(x=myAlignAA, filepath=file.align.untrimmed)

#' ## Trimming multiple sequence alignments
#' - https://cran.r-project.org/package=microseq
#library(microseq)
msa.untrimmed <- microseq::readFasta(in.file = file.align.untrimmed)
print(nchar(msa.untrimmed$Sequence))
msa.trimmed <- microseq::msaTrim(msa = msa.untrimmed, gap.end = 0, gap.mid = 0)
print(nchar(msa.trimmed$Sequence))
file.align.trimmed <- "myAlignTrim.fasta"
microseq::writeFasta(fdta = msa.trimmed, out.file = file.align.trimmed, width = 80)

# read the FASTA-format alignment into R
file_align <- file.align.untrimmed
myAln <- seqinr::read.alignment(file=file_align, format="fasta", forceToLower=FALSE)
unlist(myAln$seq)

#' ## Sequence Logos
#' - https://cran.r-project.org/package=ggseqlogo
#' - https://omarwagih.github.io/ggseqlogo/
#require(ggplot2) #require(ggseqlogo) #?geom_logo
ggseqlogo(data=substr(x=toupper(myAln$seq), start=1, stop=20), seq_type='aa', method='bits') # method='prob'

#' ## Check Average Identity to Estimate Reliability of the Alignment
# squared root of pairwise distances from aligned sequences
mydist <- seqinr::dist.alignment(x=myAln, matrix="identity", gap=FALSE)
mean(mydist ^ 2); #summary(as.vector(mydist ^ 2))
#' - [Phylogenetic Trees Made Easy: A How-To Manual (5th edition)](https://github.com/haruosuz/DS4GD/blob/master/CaseStudy.md#ptme5)
#' (p.60) *Codons: Pairwise amino acid identity* | 
#' The p-distance is 1–amino acid identity; thus 
#' if the average p-distance is <0.7 the alignment is acceptable; 
#' if ≥0.7 it is unreliable.
#' 
#' # Estimating Phylogenetic Trees
#' ## Distance based methods
#' - Vignettes: [Estimating phylogenetic trees with phangorn](https://cran.r-project.org/web/packages/phangorn/vignettes/Trees.html)
#' After constructing a distance matrix, we reconstruct a rooted tree with UPGMA and alternatively an unrooted tree using Neighbor Joining
#library(phangorn)
myphyDat <- read.phyDat(file=file_align, format="fasta", type="AA")
#names(myphyDat) <- gsub(pattern="^(UniRef[0-9]+_)*((sp|tr)\\|)?([^ .|]+).*", replacement="\\4", x=names(myphyDat))
if(UPGMA_NJ == "UPGMA") myfun <- function(x) upgma(dist.ml(x, model=mymodel, exclude=myexclude))
if(UPGMA_NJ == "NJ") myfun <- function(x) NJ(dist.ml(x, model=mymodel, exclude=myexclude))
mytree <- myfun(myphyDat); #summary(mytree$edge.length)

set.seed(123)
mytrees_bs <- bootstrap.phyDat(myphyDat, FUN=myfun, bs=100, multicore=TRUE)
#mytree <- plotBS(tree=mytree, BStrees=mytrees_bs) # version 2.11.1 # further parameters used by `plot.phylo` #plot=TRUE
mytree <- plotBS(tree=mytree, trees=mytrees_bs) # version 2.12.1
if (all(mytree$node.label <= 1, na.rm = TRUE)) { mytree$node.label <- mytree$node.label * 100 }

#' ## Substitution Saturation Analysis
#' - https://en.wikipedia.org/wiki/Genetic_saturation
d_patristic <- cophenetic(mytree)
d_uncorrected <- mydist ^ 2
nms <- rownames(as.matrix(d_uncorrected))
d_patristic <- as.dist(d_patristic[nms, nms])
summary(as.vector(d_patristic))
summary(as.vector(d_uncorrected))
mylim <- range(d_patristic, d_uncorrected)
mymax <- max(d_patristic, d_uncorrected)
plot(d_patristic, d_uncorrected, xlim=c(0,mymax), ylim=c(0,1), xlab="#substitutions (patristic distances)", ylab="#differences (uncorrected distances)")
abline(a = 0, b = 1, col = "blue") # x=y line
#abline(h = 1, col = "red") # y=1 line
#fit <- lm(d_uncorrected ~ d_patristic); fit; coef(fit)[2]
fit <- lm(d_uncorrected ~ d_patristic - 1) # linear regressions performed through the origin (i.e., the intercept is set to zero).
fit
#summary(fit)
#' 
#' ## Unrooted and Rooted Trees
# Outgroup or Midpoint rooting
outgroups <- c()
#outgroups <- mytree$tip.label[c(1,length(mytree$tip.label))]
#my.subtrees <- subtrees(mytree) #length(my.subtrees) #sapply(my.subtrees, function(x) length(x$tip.label)) #outgroups <- my.subtrees[[1]]$tip.label
#TF <- grepl(pattern="KGUA_|virus", x=mydata$Annotation, ignore.case=FALSE); summary(TF); mydata$Annotation[TF]; outgroups <- mydata$Accession[TF]
TF <- ifelse(length(outgroups) > 0, ape::is.monophyletic(phy=mytree, tips=outgroups), FALSE )
tree.main <- ifelse(TF, "Outgroup rooted ", "Midpoint rooted ")
tree.main <- ifelse(UPGMA_NJ == "NJ", paste0(tree.main,UPGMA_NJ), UPGMA_NJ)
tree.main
#length(mytree$node.label); summary(mytree$node.label); mytree$node.label
if(TF) {
  mytree <- ape::root(phy=mytree, outgroup=outgroups, resolve.root=TRUE)
} else {
  if(UPGMA_NJ == "NJ"){ 
    mytree <- phangorn::midpoint(mytree)
    #mytree <- phytools::midpoint.root(mytree)
  }
}
#length(mytree$node.label); summary(mytree$node.label); mytree$node.label
mytree <- ladderize(mytree, right=TRUE)

#' ## write tree and data table
# write.tree / read.tree
#mytree$tip.label <- gsub(pattern="^(UniRef[0-9]+_)*((sp|tr)\\|)?([^ .|]+).*", replacement="\\4", x=mytree$tip.label)
#plot.phylo(mytree, type="phylogram", show.node.label=TRUE); tiplabels(); #nodelabels(); #edgelabels();
write.tree(phy = mytree, file = "myTree.tre")
mytree <- read.tree(file = "myTree.tre")
mytree$node.label <- as.numeric(mytree$node.label)
#plot.phylo(mytree, type="phylogram", show.node.label=TRUE); tiplabels(); #nodelabels(); #edgelabels();
#length(mytree$node.label); summary(mytree$node.label); mytree$node.label

# data table sorted by tree $tip.label
mydata <- mydata[match(rev(mytree$tip.label), rownames(mydata)),]
write_tsv(x=mydata, file="myTable.tsv")
#' - https://www.zoology.ubc.ca/~schluter/R/Phylogenetic.html#Row_order

x <- mytree$tip.label[1]; mydata[rownames(mydata) %in% x,c("Annotation")]
mytree$tip.label <- sapply(mytree$tip.label, function(x) mydata[rownames(mydata) %in% x,c("Annotation")] )
#mytree$tip.label <- sapply(mytree$tip.label, function(x) mydata[grepl(pattern=x, x=rownames(mydata)),c("Annotation")] )

pdf("myTree.pdf", pointsize=10, width=15, height=9)
par(mfrow=c(1,1), mgp=c(1.7, 0.5, 0), mar=c(1.5, 0.5, 1, 0.5), cex=mycex) # c(bottom, left, top, right)
plot.phylo(x=mytree, show.node.label=TRUE, main=paste0(tree.main," tree"), root.edge=TRUE, underscore=TRUE); ape::add.scale.bar(); axisPhylo()
#plot.phylo(x=mytree, show.node.label=TRUE, root.edge=TRUE, underscore=TRUE); ape::add.scale.bar(); #axisPhylo()
dev.off()

#' **Figure. Evolutionary relationships of some organisms' proteins.**  
#' Phylogenetic tree involving `print(nchar(msa.trimmed$Sequence))` sites in the alignment of amino acid sequences of `length(seqs)` proteins.  
#' 
#' Multiple sequence alignments of amino acid sequences were performed using the `?DECIPHER` package (version `packageVersion("DECIPHER")`) (http://www2.decipher.codes/Citation.html).  
#' 
#' Positions containing gaps were eliminated using the `?microseq` package (version `packageVersion("microseq")`) (https://cran.r-project.org/package=microseq).  
#' 
#' Sequence logos were drawn using the `?ggseqlogo` package (version `packageVersion("ggseqlogo")`) (https://cran.r-project.org/package=ggseqlogo).  
#' 
#' Phylogenetic tree inference was performed using the `phangorn` package (version `packageVersion("phangorn")`) (https://cran.r-project.org/package=phangorn).  
#' Distance matrices (pairwise distances between all pairs of sequences) were computed using the `phangorn::dist.ml` function 
#' from the aligned sequences with the `myexclude` gap deletion approach and the amino acid substitution model `mymodel`.  
#' The distance-based method `UPGMA_NJ` [UPGMA (unweighted pair group method with arithmetic mean) or Neighbor Joining (NJ)] 
#' was performed using the `phangorn::upgma` or `phangorn::NJ` function.  
#' Bootstrap percentages at nodes were calculated with 100 replicates using the `phangorn::bootstrap.phyDat` function.  
#' The tree is drawn to scale, with branch lengths measured in the number of substitutions per site (indicated by horizontal scale bars).  
#' 
#' The analyses were implemented in `R.version.string`.  
#' Use `sessionInfo()` to print version information about R and packages.
sessionInfo()
Sys.time() # 2026-04

#' # References
#' 
#' - https://cran.r-project.org/package=Peptides
#'   - https://github.com/dosorio/Peptides/
#' - http://togows.dbcls.jp/site/en/rest.html
#' TogoWS REST service
#' - 
#' - https://ja.wikipedia.org/wiki/EF-Tu
#' - https://ja.wikipedia.org/wiki/EF-G
#' - https://en.wikipedia.org/wiki/Elongation_factor
#'   - https://en.wikipedia.org/wiki/EEF-1
#'     - https://en.wikipedia.org/wiki/Eukaryotic_translation_elongation_factor_1_alpha_1
#'   - https://en.wikipedia.org/wiki/EEF2
#' - https://www.brh.co.jp/research/formerlab/miyata/2005/post_000008.php
#' 【生物最古の枝分かれ：問題点と重複遺伝子による解決】 | JT生命誌研究館
#'  | 遺伝子重複 | ポリペプチド伸長因子（EF-1a/Tu）（EF-2/G）
#'  | 図3．重複遺伝子EF-Tu/1aとEF-G/2に基づく超生物界の複合系統樹
#' - 
#' - 2010.4. 動物の系統分類と進化（藤田敏彦 著）
#'   - https://www.shokabo.co.jp/mybooks/ISBN978-4-7853-5842-6.htm
#'   - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/188bto4/alma9926405490104034
#' Maruzen eBook Library
#'  | p.65-66 | 遺伝子重複(gene duplication)
#'  | ヘモグロビン α 鎖と β 鎖は，ヒト，ウマ，チンパンジーが共有
#'  | パラローガス(paralogous) | オーソローガス(orthologous)
