#' ---
#' title: "Title"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---

#' ---
#' 
#' https://github.com/haruosuz/DS4GD/blob/master/2021/CaseStudy.md#assignment-13
#' 
#' # Introduction
#' 
#' # Methods
#' 
#' - [NCBI Genome List](https://github.com/haruosuz/DS4GD/blob/master/2021/CaseStudy.md#ncbi-genome-list)
#' - [BLAST (Basic Local Alignment Search Tool)](https://github.com/haruosuz/DS4GD/blob/master/2021/CaseStudy.md#blast)
#' 
#' # Results and Discussion
#' 
#' - [Answers to the End-of-chapter Exercises](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html)
#' 

# clear the decks
rm(list = ls())

# Loading packages
#+ warning = FALSE
#+ message = FALSE
library(seqinr)
library(ape)
library(phangorn)
library(microseq)

library(Biostrings)
library(DECIPHER)

library(tidyverse)
require(ggseqlogo)

#' ## NCBI Protein
#' 
#' - http://togows.dbcls.jp/site/ja/rest.html
togows_protein_fasta <- function(ACCESSION) seqinr::read.fasta(file = paste0("http://togows.dbcls.jp/entry/protein/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
#ACCESSIONs <- c() # Make a vector containing ACCESSION (protein_id) of the sequences
ACCESSIONs <- c("CAJ85684", "BAF33454", "CAJ43307", "ADD63272") # TrfA (RK2, pBP136, QKH54, pAKD4)
ACCESSIONs <- c("CAJ85684", "BAF33454", "CAJ43307", "ADD63272", "CAA41700") # TrfA (RK2, pBP136, QKH54, pAKD4), RepA (pPS10)
#seqs <- lapply(ACCESSIONs, togows_protein_fasta) # Retrieve the sequences and store them in list variable "seqs"
file.fasta <- "data/myNCBIprotein.fasta"

#' ## UniProt
#' 
#' - https://www.uniprot.org/help/fasta-headers
retrieve_seqs_uniprot <- function(ACCESSION) seqinr::read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
ACCESSIONs <- c("Q8U152","P61877","Q9SI75","P25039","P80868","P0A6M8","P0CE47","P0CE48","P17745","P33166","P02992"); outgroups <- c("P61877","Q9SI75","P25039","P80868","P0A6M8") # EF
#seqs <- lapply(ACCESSIONs,  retrieve_seqs_uniprot)
file.fasta <- "data/myUniProt.fasta"

#' Write sequence(s) into a file in fasta format
#write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=file.fasta, nbchar=max(getLength(seqs)))

#' Read amino-acid sequences from a file in FASTA format.
file.fasta <- "data/myNCBIprotein.fasta" # NCBI Protein
#file.fasta <- "data/myUniProt.fasta" # UniProt
seqs <- read.fasta(file=file.fasta, seqtype="AA", strip.desc=TRUE)

#' Get sequence length and annotations
Length <- getLength(seqs) # get the length of sequences
Annotation <- unlist(getAnnot(seqs)) # get sequence annotations
# NCBI Protein
Accession <- gsub(pattern="^([^ ]+) .+", replacement="\\1", x=Annotation)
ProteinName <- gsub(pattern="^([^ ]+)\\.[0-9]+ (.+) \\[(.+)\\]", replacement="\\2", x=Annotation)
OrganismName <- gsub(pattern=".+\\[(.+)\\]", replacement="\\1", x=Annotation)
# UniProt
#Accession <- gsub(pattern="^sp\\|([^ ]+)\\|.+", replacement="\\1", x=Annotation)
#ProteinName <- gsub(pattern="^([^ ]+) (.+) OS=.+", replacement="\\2", x=Annotation)
#OrganismName <- gsub(pattern=".+ OS=(.+) OX=.+", replacement="\\1", x=Annotation)
#' Creates data frame (table)
d.f <- data.frame(Length, Annotation, Accession, ProteinName, OrganismName) %>% arrange(desc(`Length`))
write_csv(x=d.f, file="analysis/table.csv")
knitr::kable(x = d.f, caption = "Table 1. Sequence data.")

#' Histograms
hist(d.f$Length)
#' - https://r4ds.had.co.nz/exploratory-data-analysis.html
ggplot(d.f, aes(x = `Length`)) + geom_histogram(bins = 5)

#' ## Multiple Sequence Alignment
#' 
#' - https://github.com/haruosuz/r4bioinfo/tree/master/R_DECIPHER
#' - Vignettes https://bioconductor.org/packages/release/bioc/vignettes/DECIPHER/inst/doc/ArtOfAlignmentInR.pdf
#library(DECIPHER)
myAAStringSet <- Biostrings::readAAStringSet(filepath=file.fasta)
myAlignAA <- AlignSeqs(myAAStringSet)
#DECIPHER::BrowseSeqs(myAlignAA, threshold = 0.5) # ?ConsensusSequence

myAlignAA
#as.character(myAlignAA)

#' ## Sequence Logos
#' 
#' - https://cran.r-project.org/package=ggseqlogo
#' - Vignettes https://omarwagih.github.io/ggseqlogo/
#install.packages("ggseqlogo")
#require(ggplot2)
#require(ggseqlogo)
#?geom_logo
ggseqlogo(as.character(myAlignAA), seq_type='aa', method='prob')
ggseqlogo(substr(as.character(myAlignAA),210,220), seq_type='aa', method='bits')

# write an XStringSet object to a file
file.align <- "analysis/myAlignAA.fasta"
writeXStringSet(myAlignAA, filepath=file.align)

#' ## Check Average Identity to Estimate Reliability of the Alignment
#' 
#' Trimming multiple sequence alignments
#library(microseq)
msa.untrimmed <- microseq::readFasta(in.file = file.align)
print(nchar(msa.untrimmed$Sequence))
msa.trimmed <- microseq::msaTrim(msa = msa.untrimmed, gap.end = 0, gap.mid = 0)
print(nchar(msa.trimmed$Sequence))
file.align.trimmed <- "analysis/myAlignAAtrimmed.fasta"
microseq::writeFasta(fdta = msa.trimmed, out.file = file.align.trimmed, width = 80)

# Read aligned sequence file
myaln <- seqinr::read.alignment(file=file.align.trimmed, format="fasta")
# Pairwise Distances from Aligned Protein Sequences
# The resulting matrix contains the squared root of the pairwise distances.
mydist <- seqinr::dist.alignment(x=myaln, matrix="identity")
mydist

#' - [Phylogenetic Trees Made Easy: A How-To Manual (5th edition)](https://github.com/haruosuz/DS4GD/blob/master/2021/CaseStudy.md#ptme5)
#' 
#' The p-distance is 1–amino acid identity; thus 
#' if the average p-distance is <0.7 the alignment is acceptable; 
#' if ≥0.7 it is unreliable.
mean(mydist ^ 2)

#' ## Neighbor-Joining Tree
mytree <- ape::nj(mydist)
#mytree <- ape::root(phy=mytree, outgroup=outgroups, resolve.root=TRUE)
mytree <- phangorn::midpoint(mytree)
mytree <- ape::ladderize(mytree, right = FALSE)
ape::plot.phylo(mytree, type="phylogram", main="rooted tree")
file.tree <- "analysis/my_ape_nj.tre"
write.tree(mytree, file=file.tree)
mytree <- read.tree(file=file.tree)
#x <- mytree$tip.label[1]; TF <- grepl(pattern=x, x=d.f[,"Accession"]); summary(TF); d.f[TF,]; paste(d.f[TF,c("Accession","OrganismName")],collapse="~")
#mytree$tip.label <- sapply(mytree$tip.label, function(x) paste(d.f[grepl(pattern=x, x=d.f[,"Accession"]),c("Accession","OrganismName")],collapse="~") )
mytree$tip.label <- sapply(mytree$tip.label, function(x) paste(d.f[grepl(pattern=x, x=d.f[,"Accession"]),c("Accession","ProteinName","OrganismName")],collapse="~") )
par(mfrow=c(1,1), mgp=c(1.7, 0.5, 0), mar=c(1, 0.5, 0.5, 0.5), cex=0.7) # c(bottom, left, top, right)
ape::plot.phylo(mytree, type="phylogram", show.node.label=TRUE, font=3)
add.scale.bar(x=0.01, y=0.9)#, col=2)
title(basename(file.tree))

#' ## UPGMA Tree with Bootstrap values
#' 
#' - https://github.com/haruosuz/r4bioinfo/tree/master/R_phangorn
#' - Vignettes: https://cran.r-project.org/web/packages/phangorn/vignettes/Trees.html
#library(phangorn)
myphyDat <- read.phyDat(file=file.align, format="fasta", type="AA")
myfun <- function(x) upgma(dist.ml(x, model="JTT"))
mytree <- myfun(myphyDat)
set.seed(123)
BStrees <- bootstrap.phyDat(myphyDat, FUN=myfun, bs=100)
treeBS <- plotBS(mytree, BStrees, "phylogram")

#getwd()
#list.files()
sessionInfo()
Sys.time()

#' # References
#' ## elongation factors EF-Tu and EF-G
#' - [HASEGAWA et al. 1990 "Close evolutionary relatedness of archaebacteria, Methanococcus and Halobacterium, to eukaryotes demonstrated by composite phylogenetic trees of elongation factors EF-Tu and EF-G: Eocyte tree is unlikely"](https://www.jstage.jst.go.jp/article/jjg/65/3/65_3_109/_article/-char/ja/)
#' - [Iwabe et al. 1989 "Evolutionary relationship of archaebacteria, eubacteria, and eukaryotes inferred from phylogenetic trees of duplicated genes."](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC298494/)
#' - [宮田　隆の進化の話【生物最古の枝分かれ：問題点と重複遺伝子による解決】 | JT生命誌研究館](https://www.brh.co.jp/research/formerlab/miyata/2005/post_000008.php)
#' 図3．重複遺伝子EF-Tu/1aとEF-G/2に基づく超生物界の複合系統樹
#' 真核生物のミトコンドリア（mt）とクロロプラスト（chl）はいずれも真正細菌の系統に含まれていることに注意。これは両者とも真正細菌起源であることの分子からの証拠である。
#' ![](https://www.brh.co.jp/_old/imgs/katari/shinka/14_zu03.gif)
#' 
#' ## replication initiation proteins Rep, TrfA
#' - [Wegrzyn et al. 2021 "Defining a novel domain that provides an essential contribution to site-specific interaction of Rep protein with DNA"](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8034659/)
#' ![https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8034659/figure/F1/](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8034659/bin/gkab113fig1.jpg)
#' - [Yano et al. 2012 "Roles of Long and Short Replication Initiation Proteins in the Fate of IncP-1 Plasmids"](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3294859/)
#' ![https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3294859/figure/F1/](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3294859/bin/zjb9990912760001.jpg)
#' 

