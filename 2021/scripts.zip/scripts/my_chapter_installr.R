#' ---
#' title: "Little Book of R for Bioinformatics"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.time()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

#' ## [R言語入門](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#how-to-install-r-and-a-brief-introduction-to-r)
#' ## [How to install R and a Brief Introduction to R](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html)
#' ### Introduction to R
#' 
#' - 2019.08.16 biostatistics [R を利用した統計解析およびデータの視覚化](https://stats.biopapyrus.jp/r/)
#' - 2019-04-22 奥村 晴彦 [Rの初歩](https://oku.edu.mie-u.ac.jp/~okumura/stat/first.html)
#' - [R-Tips](http://cse.naro.affrc.go.jp/takezawa/r-tips/r.html)
#' 
#' ### [Installing R](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#installing-r)
#' 
#' - [R のインストール - RjpWiki](http://www.okadajp.org/RWiki/?R%20のインストール)
#' - [01.セットアップ・参考文献](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/01.html)
#' 
#' ### [Installing R packages](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#installing-r-packages)
#' 
#' - [パッケージ | R のパッケージのインストール方法と呼び出し方](https://stats.biopapyrus.jp/r/basic/package.html)
#' - [Bioconductor: Genomicデータ解析ツール群 - Heavy Watal](https://heavywatal.github.io/rstats/bioconductor.html)
#' 
#' #### [How to install an R package](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#how-to-install-an-r-package)
#' パッケージ[`seqinr`](https://cran.r-project.org/package=seqinr)のインストール:  
# install the "seqinr" package
#install.packages("seqinr")

#' `seqinr`パッケージの呼び出し:  
# load the "seqinr" package into R
#library(seqinr)

#' #### [How to install a Bioconductor R package](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#how-to-install-a-bioconductor-r-package)
#' Bioconductorパッケージ[`Biostrings`](http://bioconductor.org/packages/Biostrings/)のインストール:  
# install the Bioconductor package called "Biostrings"
#install.packages("BiocManager")
#BiocManager::install("Biostrings")

#' `Biostrings`パッケージの呼び出し:  
# load the "Biostrings" package into R
#suppressMessages(library(Biostrings))

#' ### [Running R](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#running-r)
#' 
#' - [02. R の起動と終了](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/02.html)  
#' 
#' ![](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/image/windows.gif)
#' ![http://cse.naro.affrc.go.jp/takezawa/r-tips/r/02.html](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/image/Mac.gif)
#' 
#' Rを終了:  
# To quit R, type:
#quit()
#q()

#' - https://github.com/haruosuz/books/tree/master/r4all
#' - https://github.com/haruosuz/books/tree/master/r4ds
#' 
#' When you double-click on a script file, it will automatically open in RStudio.
#' 
#' [Pressing Cmd/Ctrl + Enter executes the current R expression in the console.](https://r4ds.had.co.nz/workflow-scripts.html)
#' 
#' ### [A brief introduction to R](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#a-brief-introduction-to-r)
#' 
#' [演算子 | R の代入演算子や理論演算子などについて](https://stats.biopapyrus.jp/r/basic/arithmetic-operator.html)
#' 
#' 算術演算子  
# typing in commands
2*3
10-3

#' 代入演算子  
#' All variables (vectors, etc.) created by R are called objects. 
#' In R, we assign values to variables using an arrow (`<-`).
# assign the value 2*3 to the variable x
x <- 2*3

# To view the contents of any R object, just type its name
x

#' [データ型 | R のデータ型・モード・クラス](https://stats.biopapyrus.jp/r/basic/data-type.html)  
#' 
#' [ベクトル | R のベクトル操作と演算](https://stats.biopapyrus.jp/r/basic/vector.html)  
#' ベクトルの作成は、関数`c()`を用いる。  
#' use the `c()` (combine) function to create a vector
# create a vector called myvector that has elements with values 8, 6, 9, 10, and 5:
myvector <- c(8, 6, 9, 10, 5)

# see the contents of the variable myvector:
myvector

#' ベクトル要素の取得は、角括弧に要素の添字を書く。  
#' extract elements with single square brackets `[index]`.
# get the value of the 4th element in the vector myvector
myvector[4]

#' [23. リスト](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/23.html)  
#' リストは異なる型（数値や文字列）のデータをまとめられる。
#' リストの作成は関数`list()`を用いる。  
#' A list can contain elements of different types (e.g. numeric and character).
# create a list mylist:
mylist <- list(name="Fred", wife="Mary", myvector)
mylist

#' `[[ ]]`はリスト内の要素（ベクトル）を取り出す。  
#' extract elements with double square brackets `[[index]]`.
# extract the second and third elements from mylist:
mylist[[2]]
mylist[[3]]

#' リストの要素に名前が付けられている場合、`$`記号でアクセスする。  
# mylist$wife is the same as mylist[[2]]:
mylist$wife

# find the names of the named elements in a list
attributes(mylist)

#' [table 関数を使ったクロス集計](http://nshi.jp/contents/r/crosstab/)

# produce a table variable that contains the number of bases:
mybases <- c("A", "C", "G", "T", "A")
table(mybases)
# store the table variable produced by the function table(), and call the stored table “mytable”:
mytable <- table(mybases)
mytable
# access the 1st element in the table mytable (the number of base “A”):
mytable[[1]]
mytable[["A"]]

#' [03. 簡単な計算](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/03.html)  
#' 関数

# calculate the log to the base 10 of a number:
log10(100)

#' [07. ヘルプを見る](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/07.html)
#' 
# get help about a particular function
help(log10)

#' 標準偏差 standard deviation を計算する関数を探す

# search for all functions containing the word “deviation” in their description:
#help.search("deviation")
#RSiteSearch("deviation")

#' ベクトルの値の平均

# calculate the average of the values in the vector myvector
mean(myvector)

#' [31. 関数の定義](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/31.html)  

# create a function to calculate the value of 20 plus square of some input number:
myfunction <- function(x) { return(20 + (x*x)) }
# use the function for different input numbers (eg. 10, 25):
myfunction(10)
myfunction(25)

#' ### [Links and Further Reading](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#links-and-further-reading)
#' 
sessionInfo()
