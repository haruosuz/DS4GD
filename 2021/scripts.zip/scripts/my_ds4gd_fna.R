#+ echo = TRUE
# Clear the decks
rm(list = ls())

#+ message = TRUE
# libraries I need (no need to install...)
library(tidyverse)
library(seqinr)
library(Biostrings)
library(DECIPHER)

#' - https://pubmed.ncbi.nlm.nih.gov/32582111/ Front Microbiol. 2020
#' "Determination of Plasmid pSN1216-29 Host Range and the Similarity in Oligonucleotide Composition Between Plasmid and Host Chromosomes"
#' - https://github.com/haruosuz/DS4GD/blob/master/2019giga/CaseStudy.md#fna
# Make a vector containing NCBI accessions
ACCESSIONs <- c("AP018710", "CP014764", "CP015073", "CP020602") # pSN1216-29 and related plasmids

# create a function to retrieve several nucleotide sequences from NCBI
retrieve_ncbi_fna <- function(ACCESSION) seqinr::read.fasta(file = paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text"), seqtype="DNA", strip.desc=TRUE)[[1]]

# Retrieve the sequences and store them in list variable
fna.seqs <- lapply(ACCESSIONs, retrieve_ncbi_fna)
length(fna.seqs)

# Apply a Function over a List
#lapply(fna.seqs, summary)
#sapply(fna.seqs, summary)
Length <- seqinr::getLength(fna.seqs) # get the length of sequences
GCcontent <- round( sapply(fna.seqs, seqinr::GC) , digits=3) # Global G+C content
Annotation <- unlist(seqinr::getAnnot(fna.seqs)) # sequence annotations
d.f <- data.frame(Length, GCcontent, Annotation)
knitr::kable(d.f, caption = "Table. DNA Sequence Statistics.")
#write.csv(d.f, file = "R.ds4gd_fna.statistics.csv", quote=TRUE, row.names=FALSE)

#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#over-represented-and-under-represented-dna-words
myfun_rho <- function(x,k) seqinr::rho(c(x, ' ', rev(comp(x))), wordsize=k)
par(cex=0.9) # Set Graphical Parameters
for(k in 2:3){
  myrho <- sapply(X=fna.seqs, FUN=myfun_rho, k)
  colnames(myrho) <- seqinr::getName(fna.seqs)
  #write.table(myrho, file=paste0("R.ds4gd_fna.rho",k,".tsv"), sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)
  #write.csv(myrho, file=paste0("R.ds4gd_fna.rho",k,".csv"), quote=TRUE, row.names=TRUE)
  hc <- hclust(d=as.dist(1-cor(myrho)), method="average")
  heatmap(t(myrho), Rowv=as.dendrogram(hc), margins=c(1,4), cexCol=1/k, cexRow=1.0, col=rev(gray.colors(12)))
}

# get the reverse complementary strand:
#xx <- fna.seqs[2][[1]]
#xx <- as.SeqFastadna(object=rev(comp(xx)), name=getName(xx), Annot=getAnnot(xx))
#fna.seqs[2][[1]] <- xx

filename <- "mySequences.fna"
# Write sequence(s) into a file in fasta format
write.fasta(sequences=fna.seqs, names=getAnnot(fna.seqs), file.out=filename, nbchar=max(getLength(fna.seqs)))
# read FASTA formatted files
#fna.seqs <- read.fasta(file=filename, seqtype="DNA", strip.desc=TRUE)

# Read an XStringSet object from a file
mySequences <- Biostrings::readDNAStringSet(file=filename)

#' - https://github.com/haruosuz/r4bioinfo/tree/master/R_DECIPHER
#' - https://bioconductor.org/packages/release/bioc/vignettes/DECIPHER/inst/doc/ArtOfAlignmentInR.pdf
# Create a connection to a DBMS
dbConn <- DBI::dbConnect(SQLite(), ":memory:")
# Add Sequences from Text File to Database
DECIPHER::Seqs2DB(seqs=mySequences, type="XStringSet", dbFile=dbConn, identifier=names(mySequences))
# Finds Synteny in a Sequence Database
SyntenyObject <- DECIPHER::FindSynteny(dbFile=dbConn)
# Scatterplot Matrices
pairs(SyntenyObject, boxBlocks=TRUE)

#getwd()
#list.files()
sessionInfo()
Sys.time()
