#' ---
#' title: "[Clustering](https://github.com/haruosuz/DS4GD/blob/master/2017/hclust.md)"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---

# clear the decks
rm(list = ls())

#' # Cluster Analysis
#' ## Cluster analysis with 2 variables
v1 <- c(5,4,1,5,5)
v2 <- c(1,2,5,4,5)
mat <- cbind(v1,v2) # Combine vectors by Columns
rownames(mat) <- LETTERS[1:5] # Row Names

par(mfrow=c(2,3))

plot(mat, type="n", main="data", xlim=c(0,5), ylim=c(0,5))
text(mat, labels=rownames(mat))

# Distance Matrix Computation
d <- dist(mat, method="manhattan")

# Hierarchical Clustering
hc <- hclust(d, method="single")
#hc <- hclust(d, method="complete") # default
#hc <- hclust(d, method="average") # (= UPGMA)

# Cophenetic Distances for a Hierarchical Clustering
#d2 <- cophenetic(hc); cor(d, d2)

# Cluster Dendrogram
plot(hc, hang = -1)

# Draw Rectangles Around Hierarchical Clusters
#rect.hclust(hc, h=5) # cutting at height h
rect.hclust(hc, k=3) # k clusters are produced

# Cut a Tree into Groups of Data
#cutree(hc, h=5) # heights where the tree should be cut
#cutree(hc, k=3) # the desired number of groups
g23 <- cutree(hc, k=c(2,3))
#write.csv(cbind(mat,g23), file="R.ds4gd_hclust.cutree.csv")

mat

#' ### MDS/PCoA
#' Classical Multidimensional Scaling (MDS).
#' a.k.a. Principal Coordinate Analysis (PCoA).
par(mfrow=c(2,3))
#plot(mat, type="n", main="data")
#text(mat, labels=rownames(mat))
d <- dist(mat, method="euclidean")
loc <- cmdscale(d)
#plot(loc[, 1], loc[, 2], type="n", main="cmdscale", xlab="MDS1", ylab="MDS2")
#text(loc[, 1], loc[, 2], labels=rownames(mat))

#' ## Cluster analysis with p variables
mat <- rbind(A=c(1,1,1,1,1,1,0,0,0,0), 
             B=c(1,1,1,1,0,1,1,0,0,0), 
             C=c(1,0,0,0,0,1,1,1,1,1),
             D=c(1,1,1,1,1,1,1,1,1,0), 
             E=c(1,1,1,1,1,1,1,1,1,1)) # Combine vectors by Rows 
hc <- hclust(d=dist(mat, method="manhattan"), method="average") # "binary"
#plot(hc, hang = -1, main="UPGMA", sub="", xlab="", ylab="Distance")
#heatmap(mat, Colv=NA, Rowv=as.dendrogram(hc), col=c("white","black"), scale="none")

#' ### Cluster analysis based on amino-acid or codon counts
library(seqinr) # Loading seqinr package
data(toyaa); mat <- toyaa # A toy example of amino-acid counts in three proteins
data(toycodon); mat <- toycodon # A toy example of codon counts in three coding sequences
par(mfcol=c(1,2))
plot(hclust(dist(mat)),main="euclidean")
plot(hclust(as.dist(1-cor(t(mat)))),main="correlation")

#' # [Heat Map](https://github.com/haruosuz/DS4GD/blob/master/2017/hclust.md#heat-map)
#' 
#example(heatmap)
#' 
#' ## [You probably don’t understand heatmaps](http://www.opiniomics.org/you-probably-dont-understand-heatmaps/)
#' 
#' **tl;dr**  
#' The default in `heatmap()` is to scale by row.
#' To cluster on the "shape" of the "curve" (gene expression profiles), 
#' use one minus Pearson correlation coefficient (1 - r) instead of Euclidean distance.  
#' 
#' `heatmap`関数はデフォルトではデータを行で正規化 (scale) する。
#' 遺伝子発現プロファイルの「形状」に基づいてクラスタリングするには、
#' [ユークリッド距離](https://ja.wikipedia.org/wiki/ユークリッド距離)ではなく、
#' [相関係数](https://ja.wikipedia.org/wiki/相関係数)を利用する。
#' 
#' ### Know your distance measure
#' 
#' Imagine we have measured the gene expression of 4 genes over 8 time points:  
#' 例えば、4つの遺伝子の発現量を8つの時点で測定したとする。 
h1 <- c(10,20,10,20,10,20,10,20)
h2 <- c(20,10,20,10,20,10,20,10)

l1 <- c(1,3,1,3,1,3,1,3)
l2 <- c(3,1,3,1,3,1,3,1)

mat <- rbind(h1,h2,l1,l2)

par(mar=c(4,4,1,1))
plot(1:8,rep(0,8), ylim=c(0,35), pch="", xlab="Time", ylab="Gene Expression")

for (i in 1:nrow(mat)) {
  lines(1:8,mat[i,], lwd=3, col=i)
}

legend(1,35,rownames(mat), 1:4, cex=0.7)
  
#' The two pairs of genes (high and low) have very different shapes.  
#' 高発現遺伝子ペア(h1,h2)の形状は正反対。低発現遺伝子ペア(l1,l2)も同様。
#' 
#' With the default method for the `heatmap()` function,
#' the distance measure is calculated using the `dist()` function,
#' whose own default is euclidean distance.  
#' `heatmap`関数はデフォルトでは`dist()`関数で非類似度（距離）を計算する。
#' `dist()`関数はデフォルトではユークリッド距離（2点間の差の2乗和の平方根）を計算する。

dist(mat)

#' Here we can see that the least distant are l1 and l2 (distance = 5.65), 
#' so they will be clustered together; 
#' next least distant are h1 and h2 (distance = 28.28), 
#' so these will be clustered together next.
#' Then finally the two groups will be joined.
#' This is born out by a naive cluster analysis on the distance matrix:  
#' l1とl2との間の距離が最小(5.65)なので、この2つの遺伝子を結合してクラスター(l1,l2)とする。
#' 次に、h1とh2との間の距離が最小(28.28)なので、この2つの遺伝子を統合してクラスター(h1,h2)とする。
#' 最後に、(l1,l2)と(h1,h2)を結合する。

hc <- hclust(dist(mat))
plot(hc)

#' and a naive heatmap 
#' (I’ve turned off the column tree as in gene expression profiling over time, 
#' we generally want the time points to be in the correct, original order):
heatmap(mat, Colv=NA, col=rev(gray.colors(12))) # Colv = NA で列の樹形図（column dendrogram）を描かない

#' Despite l1 and l2 being clustered together, their colours do not follow the same pattern; 
#' same goes for h1 and h2.
#' l1 and h1 have the same colours despite having VASTLY different expression profiles; 
#' same for l2 and h2.  
#' (h1,h2)は、クラスターを形成するが、色のパターンは正反対。(l1,l2)も同様。
#' 
#' ###  Understand scaling
?heatmap
#' The default in `heatmap()` is to scale by row.  
#' `heatmap`関数はデフォルトではデータを行で正規化する `(scale = "row")`; 
#' 各行の平均が0、標準偏差が1となるように変換する。  
#' 
#' Here is the heatmap clustered by euclidean distance with scaling turned off:  
#' 正規化しない `(scale = "none")` でユークリッド距離でクラスタリングしたヒートマップを作成:  
heatmap(mat, Colv=NA, col=rev(gray.colors(12)), scale="none")

#' Without scaling, both l1 and l2 are “low” (light gray colours); 
#' the highest points of h1 and h2 are “high” (black); 
#' the low points of h1 and h2 are in the middle (dark gray).  
#' 正規化しない場合、l1とl2は低い値（薄い灰色）、h1とh2は高い値（黒色）と中間の値（濃い灰色）。
#' 
#' ### Improving things
#' 
#' From the gene expression profiles, 
#' we know that h1 and l1 have a similar shape, and h2 and l2 have a similar shape, 
#' but Euclidean distance doesn’t care about shape, it only cares about absolute distance.  
#' How do we cluster on “shape”?
#' To do this, we actually start with a similarity measure, the pearson correlation coefficient, 
#' it produces a value between -1 (opposite shapes) and 1 (identical shapes).  
#' 遺伝子発現プロファイルに関して、h1とl1は同じ形状、h2とl2は同じ形状。
#' ユークリッド距離は、2点間の絶対的な距離だけを測定し、形状を考慮しない。  
#' 2つのプロファイルの「形状」でクラスタリングするには、相関係数を利用する。
#' 相関係数は、−1（形状が正反対）から1（形状が同一）までの値をとる。
#' 
#' ![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Correlation_examples2.svg/506px-Correlation_examples2.svg.png)

# correlation matrix
cor(t(mat))

#' For clustering (and heatmaps) we need a distance measure, not a similarity measure, 
#' so we need to subtract all of these values from 1, which gives:
# distance matrix
1 - cor(t(mat))

# cluster analysis
hc <- hclust(as.dist(1-cor(t(mat))))
plot(hc)

# heatmap
heatmap(mat, Rowv=as.dendrogram(hc), Colv=NA, col=rev(gray.colors(12)))
#heatmap(mat, Rowv=as.dendrogram(hc), Colv=NA, col=rev(gray.colors(12)), scale="none")

#' Genes clustered on the shape of their expression profile; 
#' l1 and h1 clustered together, and they have the same colours; and 
#' l2 and h2 clustered together, and they have the same colours.
#' 
#' 
#' # References
#' - https://en.wikipedia.org/wiki/Cluster_analysis
#' - 2018 [Statistical Analysis of Microbiome Data with R | SpringerLink](https://link.springer.com/book/10.1007/978-981-13-1534-3)
#'   - [7 Exploratory Analysis of Microbiome Data and Beyond](https://link.springer.com/chapter/10.1007/978-981-13-1534-3_7)
#'     - 7.3 Clustering | 7.3.2 Clustering
#'     - 7.4 Ordination | 7.4.2 Principal Coordinate Analysis (PCoA)
#' - 2017-12-18 [How to Perform Hierarchical Clustering using R – R-posts.com](https://r-posts.com/how-to-perform-hierarchical-clustering-using-r/)
#' Single/Complete/Average Linkage
#' - [Hierarchical Cluster Analysis · UC Business Analytics R Programming Guide](https://uc-r.github.io/hc_clustering)
#' - [10.2 - Example: Agglomerative Hierarchical Clustering | STAT 555](https://online.stat.psu.edu/stat555/node/86/)
#' - 2017/06/20 [StatQuest: Hierarchical Clustering - YouTube](https://youtu.be/7xHsRkOdVwo)
#' - 
#' - https://en.wikipedia.org/wiki/UPGMA
#' - https://ja.wikipedia.org/wiki/非加重結合法
#' - 11/7/2017 [Module 24: An Intro to Phylogenetic Tree Construction in R](https://fuzzyatelin.github.io/bioanth-stats/module-24/module-24.html)
#'   - [Distance-based methods](https://fuzzyatelin.github.io/bioanth-stats/module-24/module-24.html#distance-based_methods)
#'   The following figure can help visually distinguish UPGMA methods from neighbor-joining methods (you can ignore single linkage and complete linkage)
#' - 
#' - 2015-01-05 [PhyloBotanist: How to root a phylogenetic tree: outgroup, midpoint and other methods](http://phylobotanist.blogspot.com/2015/01/how-to-root-phylogenetic-tree-outgroup.html)
#' Ultrametric trees (UPGMA)
#' 
#' 
