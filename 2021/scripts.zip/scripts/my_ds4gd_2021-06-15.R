#' ---
#' title: "DS4GD_2021"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

rm(list = ls())

# Loading packages
#+ warning = FALSE
#+ message = FALSE

library(seqinr)
library(ape)
library(phangorn)

library(Biostrings)
library(DECIPHER)

library(tidyverse)
require(ggseqlogo)

#' # [Namespace](https://r-pkgs.org/namespace.html)
?translate
?as.alignment

#?Biostrings::translate
#?seqinr::translate

#?ape::as.alignment
#?seqinr::as.alignment

#' # [DECIPHER](https://github.com/haruosuz/r4bioinfo/tree/master/R_DECIPHER)
#' 
#' ## [The Art of Multiple Sequence Alignment in R](https://bioconductor.org/packages/release/bioc/vignettes/DECIPHER/inst/doc/ArtOfAlignmentInR.pdf)
#' 
#' **1 Introduction**
#' 
#' `AlignTranslation`
#' will align DNA/RNA sequences based on their amino acid translation 
#' and then reverse translate them back to DNA/RNA. 
#' Aligning protein sequences is more accurate 
#' since amino acids are more conserved than their corresponding coding sequence.
#' 
#' **3 Alignment Accuracy**
#' 
#' **5 Single Gene Alignment**
#' 
#' **5.1 Example: Protein coding sequences**
#library(DECIPHER)
fas <- system.file("extdata", "50S_ribosomal_protein_L2.fas", package="DECIPHER")
dna <- Biostrings::readDNAStringSet(fas)
dna # the unaligned sequences

#AA <- AlignTranslation(dna, type="AAStringSet", verbose=FALSE) # align the translation
#BrowseSeqs(AA, highlight=1) # view the alignment
#DNA <- AlignSeqs(dna, verbose=FALSE) # align the sequences directly without translation
DNA <- AlignTranslation(dna, verbose=FALSE) # align the translation then reverse translate
#BrowseSeqs(DNA, highlight=NA, threshold=0.5) # view the alignment # ?ConsensusSequence
# write the aligned sequences to a FASTA file
writeXStringSet(DNA, filepath="myAlignTranslationDNA.fasta")

#' # [ggseqlogo: A 'ggplot2' Extension for Drawing Publication-Ready Sequence Logos](https://cran.r-project.org/package=ggseqlogo)
#' 
#' - Vignettes:	[ggseqlogo introduction](https://omarwagih.github.io/ggseqlogo/)
#install.packages("ggseqlogo")
#require(ggplot2)
#require(ggseqlogo)

# This loads three sample data sets: seqs_dna, pfms_dna, seqs_aa
data(ggseqlogo_sample)

# Plot a sequence logo
#ggplot() + geom_logo( seqs_dna$MA0001.1 ) + theme_logo()
?geom_logo

# Using the ggseqlogo wrapper function as a shortcut
#ggseqlogo( seqs_dna$MA0001.1 )

# Creating sequence logos using position frequency matrices
#ggseqlogo( pfms_dna$MA0018.2 )
pfms_dna$MA0018.2

# Using different methods to plot a sequence logo
p1 = ggseqlogo( seqs_dna$MA0001.1, method = 'bits' )
p2 = ggseqlogo( seqs_dna$MA0001.1, method = 'prob' )
gridExtra::grid.arrange(p1, p2)

# An example sequence logo for amino acids
ggseqlogo( seqs_aa$AKT1, seq_type="aa")

#' # [seqinr](https://github.com/haruosuz/r4bioinfo/tree/master/R_seqinR)
#' 
#' - June 2, 2016 http://seqinr.r-forge.r-project.org/seqinr_3_1-5.pdf
#' 
#' ### 3.1.1 FASTA files examples
list.files(path = system.file("sequences", package = "seqinr"), pattern = ".fasta")

#' ### 6.3.1 Sequences as vectors of characters
dnafile <- system.file("sequences/malM.fasta", package = "seqinr")
myseq <- read.fasta(file = dnafile)[[1]]
myseq[1:30]
#' in coding sequences it is very common to focus on third codon positions 
#' where selection is weak. Let’s extract bases from third codon positions:
tcp <- seq(from = 3, to = length(myseq), by = 3)
tcp[1:10]
myseqtcp <- myseq[tcp]
myseqtcp[1:10]

#' ## 7.1 Correspondence analysis
#' This is the most popular multivariate data analysis technique 
#' for amino-acid and codon count tables, 
#' 
#' The physico-chemical classes for amino acids are given in 
#SEQINR.UTIL$AA.PROPERTY

#' ## 7.2 Synonymous and non-synonymous analyses
#' 
#' - https://en.wikipedia.org/wiki/Ka/Ks_ratio
#' - https://genomevolution.org/wiki/index.php/Synonymous/Nonsynonymous_Mutations_(Ks/Ka)
#'   - Neutral selection (Ka/Ks = 1)
#'   - Positive selection (Ka/Ks > 1)
#'   - Purifying selection (Ka/Ks < 1)
#' 
#' The Ka/Ks ratio is used as tool to evaluate selective pressure 
#' (see [36](https://pubmed.ncbi.nlm.nih.gov/12175810/) for a nice back to basics). 
#' Let’s give a simple illustration with three orthologous genes of the thioredoxin familiy 
#' from Homo sapiens, Mus musculus, and Rattus norvegicus species:
ortho <- read.alignment(system.file("sequences/ortho.fasta", package = "seqinr"), format="fasta")
kaks.ortho <- kaks(ortho)
kaks.ortho$ka/kaks.ortho$ks
#' The Ka/Ks ratios are less than 1, 
#' suggesting a selective pressure on those proteins during evolution.
#' 
#' - [Analysis of selection in protein-coding sequences accounting for common biases](https://academic.oup.com/bib/advance-article-abstract/doi/10.1093/bib/bbaa431/6105943) 
#' most of the well-established methodologies to estimate
#' the metric nonsynonymous/synonymous substitution rate ratio (dN/dS) make crucial assumptions, 
#' such as lack of recombination or invariable codon frequencies along genes, which can bias the estimation. 
#' 
#' ## 12.2 Available genetic code numbers
#' The genetic code numbers are those from the NCBI (https://www.ncbi.nlm.nih.gov/Taxonomy/Utils/wprintgc.cgi).
#SEQINR.UTIL$CODES.NCBI
#' 
#' - August 3, 2017 http://seqinr.r-forge.r-project.org/src/mainmatter/introduction.pdf
#' 
# to display a genetic code as in textbooks:
tablecode(numcode=1)

#' # [Emmanuel Paradis (2012) "Analysis of Phylogenetics and Evolution with R"](https://github.com/haruosuz/books/tree/master/aper)
#' - https://link.springer.com/book/10.1007%2F978-1-4614-1743-9
#' 
#' ## 3.4 Manipulating Data
#' ### 3.4.7 Molecular Sequences
#library(seqinr)
x <- c("a", "c", "g", "t", "g", "g", "t", "c", "a", "t")
x
splitseq(x, frame = 0, word = 3)
seqinr::translate(seq=x, frame=0, sens="F", numcode=1)
aaa(seqinr::translate(x))
a(aaa(seqinr::translate(x)))

#library(ape)
#' - `base.freq` computes the proportions of each of the four bases; the results are returned as a table with names "a", "c", "g", and "t". 
#' - `GC.content` is based on the previous function, and computes the proportion of guanine and cytosine; a single numeric value is returned.
#' - `Ftab` computes the contingency table of base frequencies from a pair of sequences.
#example(base.freq) # GC.content # Ftab
#' - `seg.sites` returns the indices of the segregating sites, that is, the sites that are polymorphic.
#example(seg.sites)

#' ## 5.5 Bootstrap Methods and Distances Between Trees
#' ### 5.5.1 Resampling Phylogenetic Data
x <- 1:10
sample(x)
sample(x, replace = TRUE)
#X[, sample(ncol(X), replace = TRUE)]
x <- c("a", "a", "c", "t", "t", "a", "a", "c", "t", "t", "c", "a", "c", "c", "t")
X <- matrix(data = x, nrow = 3, ncol = 5, byrow = TRUE)
X
set.seed(123)
X[, sample(ncol(X), replace = TRUE)]

?ape::boot.phylo
?phangorn::bootstrap.pml
#phangorn::bootstrap.phyDat

#' ### 5.5.2 Bipartitions and Computing Bootstrap Values

#' # [phangorn: Phylogenetic Reconstruction and Analysis](https://github.com/haruosuz/r4bioinfo/tree/master/R_phangorn)
#' 
#' - Vignettes:
#' [Estimating phylogenetic trees with phangorn](https://cran.r-project.org/web/packages/phangorn/vignettes/Trees.html)
#library(phangorn)
data(Laurasiatherian)
dm <- dist.hamming(Laurasiatherian)
tree <- NJ(dm)
# NJ
set.seed(123)
NJtrees <- bootstrap.phyDat(Laurasiatherian,
                            FUN=function(x)NJ(dist.hamming(x)), bs=100)
treeNJ <- plotBS(tree, NJtrees, "phylogram")

#' # [Ziheng Yang (2006) "Computational Molecular Evolution"](http://abacus.gene.ucl.ac.uk/CME/)
#' - [Table of Contents](http://abacus.gene.ucl.ac.uk/CME/TableOfContents.pdf)
#' 
#' **6.4.1 Bootstrap**
#' 
#' **1. Models of Nucleotide Substitution**
#' 
#' # model
#' 
#' ![https://en.wikipedia.org/wiki/Transversion](https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/All_transitions_and_transversions.svg/320px-All_transitions_and_transversions.svg.png)
#' 
#' - [Codes Used in Sequence Description](https://www.ddbj.nig.ac.jp/ddbj/code-e.html)
#' Nucleotide Base Codes
#' ```
#' r	a or g	purine
#' y	c or t	pyrimidine
#' ```
#' 
# vector of chars
chars1 <- c("a","c","g","t", "a","c","g","t", "a","a","c","c","g","g","t","t")
chars2 <- c("a","c","g","t", "g","t","a","c", "c","t","a","g","c","t","a","g")
############################ #-transitions-#  #--------transversions--------#
chars1 <- c("a","c","g","t", "a","c",         "a","a","g","g")
chars2 <- c("a","c","g","t", "g","t",         "c","t","c","t")
mat <- rbind(chars1, chars2)
myDNAbin <- ape::as.DNAbin(mat)
as.character(myDNAbin)
ape::dist.dna(x = myDNAbin, model = "TS") # transitions
ape::dist.dna(x = myDNAbin, model = "TV") # transversions
ape::dist.dna(x = myDNAbin, model = "N")
#' - https://en.wikipedia.org/wiki/Models_of_DNA_evolution#JC69_model_(Jukes_and_Cantor_1969)
#' ![](https://wikimedia.org/api/rest_v1/media/math/render/svg/0e78cfbdcb0ae0efaaf136d9a1f7856a617de5f3)
( p <- ape::dist.dna(x = myDNAbin, model = "raw") )
( d <- -3/4 * log(1 - 4/3 * p) )
ape::dist.dna(x = myDNAbin, model = "JC69") # Jukes and Cantor (1969)

#' # [The Newick tree format](http://evolution.genetics.washington.edu/phylip/newicktree.html)

layout(matrix(1:4, 2, 2))

txt <- "((A,B,C),D);"
tr <- read.tree(text = txt); tr; plot(tr, main = txt)

txt <- "((,,),);"
tr <- read.tree(text = txt); tr; plot(tr, main = txt)

txt <- "((A:0.05,B:0.2,C:0.1):0.3,D:0.4);"
tr <- read.tree(text = txt); tr; plot(tr, main = txt)

txt <- "((A:0.05,B:0.2,C:0.1)Ancestor:0.3,D:0.4)R;"
tr <- read.tree(text = txt); tr
plot.phylo(tr, main = txt)
nodelabels(tr$node.label)
add.scale.bar()

names(tr)
write.tree(tr)
write.tree(tr, file = "myNewick.tre")

#' - http://tree.bio.ed.ac.uk/software/figtree/
#' FigTree is designed as a graphical viewer of phylogenetic trees and as a program for producing publication-ready figures. 

#?ape::ladderize
layout(matrix(1:4, 2, 2))
txt <- "(E, ((C, (A, B)), D));"
txt <- "(Fishes, ((Lizards, (Chimps, Humans)), Frogs));"
tr <- ape::read.tree(text = txt); write.tree(tr); plot(tr, main = "normal")
tr <- ape::ladderize(tr, right=T); write.tree(tr); plot(tr, main="right-ladderized")
tr <- ape::ladderize(tr, right=F); write.tree(tr); plot(tr, main="left-ladderized")
#layout(matrix(1, 1))
txt <- "(Humans, ((Lizards, Snakes), (Crocodiles, Birds)));"
tr <- ape::read.tree(text = txt); plot(tr, type="cladogram", main="Reptiles are not monophyletic.")
ape::is.monophyletic(phy = tr, tips = c("Lizards", "Snakes", "Crocodiles"))
#' 
#' - https://en.wikipedia.org/wiki/Monophyly
#' 
#' [Which came first: the chicken or the egg? - Curious](https://www.science.org.au/curious/earth-environment/which-came-first-chicken-or-egg)
#'  
#' ![https://pubmed.ncbi.nlm.nih.gov/21238242/](https://marlin-prod.literatumonline.com/cms/attachment/534490/3686827/gr1.gif)
#' 
# Print R version and packages
sessionInfo()
Sys.time()

