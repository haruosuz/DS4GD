#' - https://github.com/haruosuz/DS4GD/blob/master/2019giga/CaseStudy.md#e-utilities
#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC99038/ Comparative Biology of IncQ and IncQ-Like Plasmids
#' - https://www.ncbi.nlm.nih.gov/nuccore/M28829 IncQ plasmid RSF1010

# clear the decks
rm(list = ls())

library("seqinr") # Loading seqinr package

# Accession Numbers of Sequence Data
ACCESSION <- "M28829"

## nucleotide FASTA
fna.seqs <- read.fasta(file = paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text"), seqtype="DNA", strip.desc=TRUE)

## CDS nucleotide FASTA
ffn.seqs <- read.fasta(file = paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta_cds_na&retmode=text"), seqtype="DNA", strip.desc=TRUE)

## CDS protein FASTA
faa.seqs <- read.fasta(file = paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta_cds_aa&retmode=text"), seqtype="AA", strip.desc=TRUE)

# get the number of elements
length(fna.seqs)
length(ffn.seqs)
length(faa.seqs)

# Writing sequence data out as a FASTA file
write.fasta(sequences=fna.seqs, names=getAnnot(fna.seqs), file.out=paste0("data/",ACCESSION,".fna"))
write.fasta(sequences=ffn.seqs, names=getAnnot(ffn.seqs), file.out=paste0("data/",ACCESSION,".ffn"))
write.fasta(sequences=faa.seqs, names=getAnnot(faa.seqs), file.out=paste0("data/",ACCESSION,".faa"))

# get sequence annotations
unlist(getAnnot(fna.seqs))
unlist(getAnnot(ffn.seqs))
#unlist(getAnnot(faa.seqs))

# write a function to make a sliding window plot:
slidingwindowplotGC <- function(windowsize, inputseq)
{
  # this function requires the 'zoo' R package #install.packages("zoo")
  require("zoo")
  x <- seq(from = 1, to = length(inputseq)-windowsize, by = windowsize)
  y <- rollapply(data = inputseq, width = windowsize, by = windowsize, FUN = GC)
  plot(x, y, type="l", xlab="Position (bp)", ylab="GC content")
}

# make a sliding window plot of GC content using a window size of 2000 nucleotides:
slidingwindowplotGC(windowsize = 800, inputseq = fna.seqs[[1]])

#getwd()
#list.files()
sessionInfo()
Sys.time()

