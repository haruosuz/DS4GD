#' ---
#' title: "My Report"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---

# clear the decks
rm(list = ls())

#' # [27.4.2 Chunk options](https://r4ds.had.co.nz/r-markdown.html#chunk-options)
#' 
# Load the packages into R:

#+ eval = FALSE
library(tidyverse)

#+ include = FALSE
library(seqinr)

#+ warning = FALSE
#+ message = FALSE
library(zoo)
library(Biostrings)

#+ echo = FALSE
#+ fig.show = "hide"
#+ results = "hide"
# To Get Some Protein Statistics
example(AAstat)

#' # [27.3 Text formatting with Markdown](https://r4ds.had.co.nz/r-markdown.html#text-formatting-with-markdown)
#' 
#' - *italic* or _italic_
#' - **bold** or __bold__
#' - `code`
#' - superscript^2^ and subscript~2~
#' 
#' # Headings
#' 
#' # 1st Level Header
#' ## 2nd Level Header
#' ### 3rd Level Header
#' 
#' # Lists
#' 
#' * Bulleted list item 1
#' * Item 2
#'   * Item 2a
#'   * Item 2b
#' 1.  Numbered list item 1
#' 1.  Item 2. The numbers are incremented automatically in the output.
#' 
#' # Links and images
#' 
#' <https://r4ds.had.co.nz/> 
#' 
#' [R for Data Science](https://r4ds.had.co.nz/)
#' 
#' ![optional caption text](https://images-fe.ssl-images-amazon.com/images/I/91WTLn1DrBL._AC_UL160_.jpg)
#' 
#' ![analysis/Crab_rRNA_NJ_tree.png](analysis/Crab_rRNA_NJ_tree.png)
#' 
#' <img alt="analysis/Crab_rRNA_NJ_tree.png" src="analysis/Crab_rRNA_NJ_tree.png" width=50%>
#' 
#' # Tables 
#' 
#' First Header  | Second Header
#' ------------- | -------------
#' Content Cell  | Content Cell
#' Content Cell  | Content Cell
#' 
#' # [27.4.3 Table](https://r4ds.had.co.nz/r-markdown.html#table)
#' 
seqs <- read.fasta(file="data/myNCBIprotein.fasta", seqtype="AA", strip.desc=TRUE)
Length <- getLength(seqs) # get the length of sequences
Annotation <- unlist(getAnnot(seqs)) # get sequence annotations
d.f <- data.frame(Length, Annotation)
knitr::kable(x = d.f, caption = "Table 1. Sequence data.")

#' # References
#' - https://github.com/haruosuz/introBI/tree/master/2020
#' - https://github.com/haruosuz/DS4GD/tree/master/2020
#' - [Compiling Reports from R Scripts](https://rmarkdown.rstudio.com/articles_report_from_r_script.html)
#' - [R for Data Science](https://r4ds.had.co.nz/)
#'   - [27 R Markdown](https://r4ds.had.co.nz/r-markdown.html#code-chunks)
#'     - [27.3 Text formatting with Markdown](https://r4ds.had.co.nz/r-markdown.html#text-formatting-with-markdown)
#'     - [27.4 Code chunks](https://r4ds.had.co.nz/r-markdown.html#code-chunks)
#'       - [27.4.2 Chunk options](https://r4ds.had.co.nz/r-markdown.html#chunk-options)
#'       - [27.4.3 Table](https://r4ds.had.co.nz/r-markdown.html#table)
#' 
#' # Collect Information About the Current R Session
sessionInfo()
Sys.time()
