#' # assignment
#' ## [多重整列と系統樹](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#multiple-alignment-and-phylogenetic-trees)
#' ## [Multiple Alignment and Phylogenetic trees](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html)
#' - [Exercises](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#exercises)
#' - [Answers to the exercises on Multiple Alignment and Phylogenetic Trees](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#multiple-alignment-and-phylogenetic-trees)

# clear the decks
rm(list = ls())

#library(help="seqinr")
library(seqinr) # ls("package:seqinr")
library(Biostrings)
library(msa)
library(ape)
library(microseq)

#' Answer the following questions. 
#' For each question, please record your answer, and what you typed into R to get this answer.
#' 
#' ### Q1. 
#' Calculate the genetic distances between >3 protein sequences of interest. 
#' Which has the smallest/greatest genetic distance?

# create a function to retrieve several sequences from UniProt
retrieve_seqs_uniprot <- function(ACCESSION) seqinr::read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
#library("seqinr") # This function requires the SeqinR R package

# retrieve several sequences from UniProt
# Make a vector containing the names of the sequences
seqnames <- c("Q9YRR4", "Q9YP96", "B0LSS3", "Q6TFL5"); outgroups <- c("Q6TFL5") # NS1
seqnames <- c("Q9YRR4", "Q9YP96", "B0LSS3", "Q6TFL5", "Q32ZE1"); outgroups <- c("Q32ZE1") # NS1

# Retrieve the sequences and store them in list variable "seqs"
seqs <- lapply(seqnames,  retrieve_seqs_uniprot)

# get the number of elements
length(seqs)

# get the length of sequences
seqinr::getLength(seqs)

# get sequence annotations
unlist(seqinr::getAnnot(seqs))

# write out the sequences to a FASTA file
seqinr::write.fasta(sequences=seqs, names=seqnames, file.out="mySeq.fasta")

# Read an XStringSet object from a file
myAAStringSet <- Biostrings::readAAStringSet(file = "mySeq.fasta")

# Multiple Sequence Alignment using ClustalW
library(msa)
myMsaAAMultipleAlignment <- msa::msa(inputSeqs=myAAStringSet, method="ClustalW")
myMsaAAMultipleAlignment
print(myMsaAAMultipleAlignment, show="complete")

#' The alignment contains a lot of columns with gaps in them. 
#' This could possibly be adding noise to the phylogenetic analysis.

# write an XStringSet object to a file
Biostrings::writeXStringSet(x = unmasked(myMsaAAMultipleAlignment), filepath = "myAln.fasta")

# read the FASTA-format alignment into R
myAln <- seqinr::read.alignment(file = "myAln.fasta", format = "fasta")

# calculate the genetic distances between the protein sequences
mydist <- seqinr::dist.alignment(x = myAln)
as.matrix(mydist)
as.dist(as.matrix(mydist))

#' Based on the distance matrix,
#' B0LSS3 and Q9YP96 has the smallest genetic distance (0.2268713), and
#' Q6TFL5 and Q9YP96 has the greatest genetic distance (0.3328595).  
#' 
#' ### Q2. 
#' Build an unrooted phylogenetic tree of the proteins, using the neighbour-joining algorithm. 
#' Which are grouped together in the tree?

# construct a phylogenetic tree with the neighbor joining algorithm
mytree <- ape::nj(mydist)
ape::plot.phylo(mytree, type = "unrooted")

#' In the tree, B0LSS3 and Q9YP96 are grouped together, and Q6TFL5 and Q9YRR4 are grouped together.
#' 
#' ### Q3. 
#' Build an unrooted phylogenetic tree of the proteins, based on a trimmed alignment of the proteins. 
#' Does this differ from the tree based on the untrimmed alignment (in Q2)?

# Trimming a multiple sequence alignment by discarding columns with too many gaps.
#library(microseq)
msa.untrimmed <- microseq::readFasta(in.file = "myAln.fasta")
print(nchar(msa.untrimmed$Sequence))
msa.trimmed <- microseq::msaTrim(msa = msa.untrimmed, gap.end = 0.3, gap.mid = 0.9)
print(nchar(msa.trimmed$Sequence))
microseq::writeFasta(fdta = msa.trimmed, out.file = "myAln.trimmed.fasta", width = 80)

# read the FASTA-format alignment into R
myAln <- seqinr::read.alignment(file = "myAln.trimmed.fasta", format = "fasta")
unlist(myAln$seq)

# calculate the genetic distances between the protein sequences
mydist <- seqinr::dist.alignment(x = myAln)
mydist

# construct a phylogenetic tree
mytree <- ape::nj(mydist)
ape::plot.phylo(mytree, type = "unrooted", main="unrooted tree")

#' We find that B0LSS3 and Q9YRR4 are grouped together. 
#' This disagrees with what we found in the phylogenetic tree 
#' based on the unfiltered alignment (in Q2), in which B0LSS3 was grouped with Q9YP96.
#' 
#' It is likely that the gappy columns in the original unfiltered alignment were adding noise to the phylogenetic analysis.
#' 
#' ### Q4. 
#' Build a rooted phylogenetic tree of the proteins, based on a trimmed alignment, using an outgroup. 
#' Which are the most closely related proteins, based on the tree? 
#' What extra information does this tree tell you, compared to the unrooted tree in Q3?
mydist <- seqinr::dist.alignment(x = myAln)
mytree <- ape::nj(mydist)
mytree <- ape::root(phy = mytree, outgroup = outgroups, r=T)
mytree <- ape::ladderize(mytree, right = FALSE)
ape::plot.phylo(mytree, type="phylogram", main="rooted tree")

#' **Figure. Evolutionary relationships of the four Dengue virus NS1 proteins.**
#' The phylogenetic tree was inferred with the Neighbor-Joining algorithm using the "nj" function of the "ape" package (version 5.5). 
#' The evolutionary distances were computed using "dist.alignment" function of the "seqinr" package (version 4.2-5). 
#' The analysis was carried out in the R version 4.0.5.
#' The phylogeny indicated that B0LSS3 and Q9YRR4 formed a monophyletic group or clade, joined by Q9YP96, followed by Q6TFL5, and finally Q32ZE1 (outgroup).
#' 
#' -----
#' 
#' We see in this tree that B0LSS3 and Q9YRR4 are grouped together. 
#' The next closest sequence is Q9YP96.
#' The Q6TFL5 sequence diverged earliest of the four proteins.
#' 
#' Note that in Q3, Q9YP96 and Q6TFL5 were grouped together in an unrooted tree.
#' 
#' Thus, the rooted tree tells you 
#' which of the proteins branched off the earliest from the ancestors of the other proteins, 
#' and which branched off next, and so on... We were not able to tell this from the unrooted tree.
#' 
# Saving a phylogenetic tree as a Newick-format tree file
ape::write.tree(phy = mytree, file = "myNJ.tre")

# Print R version and packages
sessionInfo()
Sys.time()

