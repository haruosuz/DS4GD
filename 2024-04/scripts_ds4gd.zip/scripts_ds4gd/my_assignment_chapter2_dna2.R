#' # assignment
#' ## [DNA配列の統計 (2)](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#dna-sequence-statistics-2)
#' ## [DNA Sequence Statistics (2)](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html)
#' - [Exercises](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#exercises)
#' - [Answers to the exercises on DNA Sequence Statistics (2)](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#dna-sequence-statistics-2)

# Clear R's environment
rm(list = ls())

# Load the packages into R
library(ape)
library(seqinr)
library(zoo)

#' Download the DNA sequence of your genome of interest. Answer the following questions. 
#' For each question, please record your answer, and what you typed to get this answer.

# Retrieving a DNA sequence from NCBI
ACCESSION <- "NC_001477" # Modify the accession number
filename <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text")
filename <- paste0("http://togows.org/entry/nucleotide/",ACCESSION,".fasta")
#ape::write.FASTA(x=ape::read.GenBank(ACCESSION), file="myNT.fasta"); filename <- "myNT.fasta"
seqs <- read.fasta(file=filename, seqtype="DNA", strip.desc=TRUE)
#write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=paste0(ACCESSION,".fasta") )
seq1 <- seqs[[1]] # extract the 1st element from list
getAnnot(seq1) # get sequence annotations
getLength(seq1) # get the length of sequences

#' ### Q1. 
#' Write a function to calculate the AT content of a DNA sequence 
#' (ie. the fraction of the nucleotides in the sequence that are As or Ts). 
#' What is the AT content of the genome?

# Here is a function to calculate the AT content of a genome sequence:
AT <- function(x){ library("seqinr"); 1 - GC(x) }

# use the function to calculate the AT content of the genome:
AT(seq1)

# AT = 1 - GC, ie. (AT + GC = 1):
GC(seq1)
AT(seq1) + GC(seq1)

#' ### Q2. 
#' Draw a sliding window plot of GC content in the genome sequence, 
#' using different window sizes; e.g. 500, 1000, 10000 nucleotides. 
#' Do you see any regions of unusual DNA content in the genome (eg. a high peak or low trough)?
  
# write a function to make a sliding window plot:
slidingwindowplotGC <- function(windowsize, inputseq)
{
  # this function requires the 'zoo' R package #install.packages("zoo")
  require("zoo")
  x <- seq(from = 1, to = length(inputseq)-windowsize, by = windowsize)
  y <- rollapply(data = inputseq, width = windowsize, by = windowsize, FUN = GC)
  plot(x, y, type="l", xlab="Position (bp)", ylab="GC content")
  }

# make a sliding window plot of GC content using a window size of 2000 nucleotides:
window_size <- 2000 # Adjust the window size as needed
slidingwindowplotGC(windowsize = window_size, inputseq = seq1)

#' The GC content is relatively high from around 4000-7000 bases, 
#' and lower on either side (from 2500-3500 and 7000-9000 bases).
#' 
#' ### Q3. 
#' Write a function to draw a sliding window plot of AT content.

# write a function to make a sliding window plot:
slidingwindowplotAT <- function(windowsize, inputseq)
{
  require("zoo")
  x <- seq(from = 1, to = length(inputseq)-windowsize, by = windowsize)
  AT <- function(x){ library("seqinr"); 1 - GC(x) }
  y <- rollapply(data = inputseq, width = windowsize, by = windowsize, FUN = AT)
  plot(x, y, type="l", xlab="Position (bp)", ylab="AT content")
  }

#' Use it to make a sliding window plot of AT content along the genome, 
#' using a window size of 2000 nucleotides. 
par(mfrow=c(2,1), mgp=c(1.7, 0.5, 0), mar=c(3, 3, 1, 1), cex=0.9) # c(bottom, left, top, right)
# make a sliding window plot of AT content:
slidingwindowplotAT(windowsize = window_size, inputseq = seq1)
# This is the mirror image of the plot of GC content (because AT equals 1 minus GC):
slidingwindowplotGC(windowsize = window_size, inputseq = seq1)

#' ### Q4. 
#' Is the 3-nucleotide word GAC over-represented or under-represented in the genome sequence?
# rho > 1: over-represented
# rho < 1: under-represented

# calculate Rho for words of length 3 in the genome
rho(sequence = seq1, wordsize=3)

#' The Rho value for "gac" is given as 1.0681595.
#' This means that the DNA word "GAC" is about 1.068 
#' times as common in the genome sequence than expected.
#' That is, it seems to be slightly over-represented.
#' 
# Print R version and packages
sessionInfo()
Sys.time()

#' - http://www.ncbi.nlm.nih.gov/genome/browse/
#' - https://www.ncbi.nlm.nih.gov/datasets/genome/
#' - https://www.ncbi.nlm.nih.gov/nuccore/NC_001477
#' Dengue virus 1, complete genome
#' 
