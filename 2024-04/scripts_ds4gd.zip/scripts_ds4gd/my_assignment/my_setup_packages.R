#' [Omit `#` to execute.](https://r4ds.hadley.nz/workflow-basics.html#comments)
#R.version

#' - https://cran.r-project.org/mirrors.html
# URLs of the repositories for use by install.packages
#options(repos="https://cran.ism.ac.jp/")

#' Rパッケージのインストール:  
#' Installing the R packages:  
#install.packages("tidyverse")
#install.packages("seqinr")
#install.packages("zoo")
#install.packages("ape")
#install.packages("phangorn")
#install.packages("phytools")
#install.packages("geiger")
#install.packages("ggseqlogo")
#install.packages("microseq")
#install.packages("rentrez")

#' Bioconductorパッケージのインストール:  
#' Installing the Bioconductor packages:  
#if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
#BiocManager::install("Biostrings")
#BiocManager::install("msa")
#BiocManager::install("DECIPHER")

#' ```
#' Update all/some/none? [a/s/n]:
#' n
#' ```
#' 
#' Rパッケージのバージョンを確認:  
#' Print the versions of these packages:  
packageVersion("tidyverse")
packageVersion("seqinr")
packageVersion("zoo")
packageVersion("ape")
packageVersion("phangorn")
packageVersion("phytools")
packageVersion("geiger")
packageVersion("ggseqlogo")
packageVersion("microseq")
packageVersion("rentrez")
packageVersion("Biostrings")
packageVersion("msa")
packageVersion("DECIPHER")

#' Rパッケージの呼び出し:  
#' Load the packages into R:  
library(tidyverse)
library(seqinr)
library(zoo)
library(ape)
library(phangorn)
library(phytools)
library(geiger)
library(ggseqlogo)
library(microseq)
library(rentrez)
library(Biostrings)
library(msa)
library(DECIPHER)

#' Get and report version information about R, the OS and attached or loaded packages.
sessionInfo()

