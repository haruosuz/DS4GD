#' ---
#' title: "Inferring Phylogenetic Trees"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      theme: united
#'      highlight: tango
#'      toc: true
#' ---
#' 
# clear the decks
rm(list = ls())

# Load the required packages
#+ warning = FALSE
#+ message = FALSE
library(rentrez)
library(seqinr)
library(ape)
library(phangorn)
library(phytools)
library(microseq)
library(Biostrings)
library(DECIPHER)
library(ggseqlogo)
library(tidyverse)

#' # Acquiring the Sequences
#' - https://cran.r-project.org/package=seqinr
#' - https://seqinr.r-forge.r-project.org/
#library(seqinr)

database <- "uniprot"
database <- "ncbi_protein"
download <- FALSE
#download <- TRUE
UPGMA_NJ <- "UPGMA"
#UPGMA_NJ <- "NJ"

file.fasta <- "myAA.fasta" # FASTA file of protein (amino acid) sequences
# Retrieve the sequences and store them in list variable "seqs"
if(download){
  if (database == "ncbi_protein") {
    ACCESSIONs <- c("NP_001393", "WP_011012522", "WP_001040724", "NP_001952", "WP_011013157", "NP_387993") # elongation factor
    seqs <- lapply(ACCESSIONs, function(x) rentrez::entrez_fetch(db="protein", id=x, rettype="fasta"))
    write(unlist(seqs), file=file.fasta)
  } else if (database == "uniprot") {
    ACCESSIONs <- c("P68104", "Q8U152", "P33166", "P13639", "P61877", "P80868") # Elongation factor
    #ACCESSIONs <- c("P01958", "P69905", "P69907", "P02062", "P68871", "P68873") # Hemoglobin subunit
    # Create a function to retrieve several sequences from UniProt
    read.fasta.uniprot <- function(ACCESSION) seqinr::read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
    seqs <- lapply(ACCESSIONs, read.fasta.uniprot)
    # Write sequence(s) in FASTA formatted files
    write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=file.fasta, nbchar=max(getLength(seqs)))
  }
}

#' Read amino-acid sequences from a file in FASTA format.
#file.fasta <- "data/my_ncbi_protein.fasta" # NCBI Protein
#file.fasta <- "data/my_uniprot.fasta" # UniProt
file.fasta <- "myAA.fasta" # Replace this FASTA file with your own data.
seqs <- read.fasta(file=file.fasta, seqtype="AA", strip.desc=TRUE)

# Get sequence length and annotations
Length <- getLength(seqs) # get the length of sequences
Annotation <- unlist(getAnnot(seqs)) # get sequence annotations

# Pattern Matching and Replacement
if (database == "ncbi_protein") {
  Accession <- gsub(pattern="^([^ ]+) .+", replacement="\\1", x=Annotation)
  ProteinName <- gsub(pattern="^([^ ]+)\\.[0-9]+ (.+) \\[(.+)\\]", replacement="\\2", x=Annotation)
  OrganismName <- gsub(pattern=".+\\[(.+)\\]", replacement="\\1", x=Annotation)
} else if (database == "uniprot") {
  Annotation <- gsub(pattern="^UniRef[0-9]+_", replacement="", x=Annotation)
  #Accession <- gsub(pattern="^(sp|tr)\\|([^ ]+)\\|.+", replacement="\\2", x=Annotation)
  Accession <- gsub(pattern="^((sp|tr)\\|)*([^ ]+).+", replacement="\\3", x=Annotation)
  Accession <- gsub(pattern="\\|.+", replacement="", x=Accession)
  ProteinName <- gsub(pattern="^([^ ]+) (.+) (OS|n)=.+", replacement="\\2", x=Annotation)
  OrganismName <- gsub(pattern=".+ (OS|Tax)=(.+) (OX|TaxID)=.+", replacement="\\2", x=Annotation)
}

# Creates data frame (table)
d.f <- data.frame(Length, Accession, ProteinName, OrganismName, Annotation) %>% arrange(desc(`Length`))
knitr::kable(x = d.f, caption = "Table 1. Sequence data.")

# Filter sequences based on length criteria
#hist(d.f$Length) # Histograms
summary(d.f$Length) # Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
length_min <- min(Length); length_min # Replace this value with your own criteria.
length_max <- max(Length); length_max # Replace this value with your own criteria.
TF <- length_min <= Length & Length <= length_max; summary(TF); seqs <- seqs[TF]
#TF <- grepl(pattern="Fragment|Isoform", x=getAnnot(seqs), ignore.case=TRUE); summary(TF); seqs <- seqs[!TF]
# Write sequence(s) in FASTA formatted files
file.fasta <- "myAA_filtered.fasta"
write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=file.fasta, nbchar=max(getLength(seqs)))

#' # Aligning the Sequences
#' 
#' - https://github.com/haruosuz/r4bioinfo/tree/master/R_DECIPHER
#'   - Vignettes: [The Art of Multiple Sequence Alignment in R](https://bioconductor.org/packages/release/bioc/vignettes/DECIPHER/inst/doc/ArtOfAlignmentInR.pdf)
#library(DECIPHER)
myAAStringSet <- Biostrings::readAAStringSet(filepath=file.fasta)
myAlignAA <- DECIPHER::AlignSeqs(myAAStringSet)
#myAlignAA <- subseq(myAlignAA, start=73, end=162)
myAlignAA
#DECIPHER::BrowseSeqs(myAlignAA, threshold = 0.5) # ?ConsensusSequence

# write an XStringSet object to a file
file.align.untrimmed <- "myAlign.fasta"
Biostrings::writeXStringSet(x=myAlignAA, filepath=file.align.untrimmed)

#' ## Trimming multiple sequence alignments
#' - https://cran.r-project.org/package=microseq
#library(microseq)
msa.untrimmed <- microseq::readFasta(in.file = file.align.untrimmed)
print(nchar(msa.untrimmed$Sequence))
msa.trimmed <- microseq::msaTrim(msa = msa.untrimmed, gap.end = 0, gap.mid = 0)
print(nchar(msa.trimmed$Sequence))
file.align.trimmed <- "myAlignTrim.fasta"
microseq::writeFasta(fdta = msa.trimmed, out.file = file.align.trimmed, width = 80)

# read the FASTA-format alignment into R
file_align <- file.align.untrimmed
#file_align <- file.align.trimmed
myAln <- seqinr::read.alignment(file=file_align, format="fasta")
unlist(myAln$seq)

#' ## Sequence Logos
#' - https://cran.r-project.org/package=ggseqlogo
#require(ggplot2) #require(ggseqlogo) #?geom_logo
mydata <- toupper(myAln$seq)
mydata <- substr(x=mydata, start=1, stop=20)
ggseqlogo(data=mydata, seq_type='aa', method='bits') # method='prob'

#' ## Check Average Identity to Estimate Reliability of the Alignment
# squared root of pairwise distances from aligned sequences
mydist <- seqinr::dist.alignment(x=myAln, matrix="identity")
mean(mydist ^ 2)
#' - [Phylogenetic Trees Made Easy: A How-To Manual (5th edition)](https://github.com/haruosuz/DS4GD/blob/master/2021/CaseStudy.md#ptme5)
#' (p.60) *Codons: Pairwise amino acid identity* | 
#' The p-distance is 1–amino acid identity; thus 
#' if the average p-distance is <0.7 the alignment is acceptable; 
#' if ≥0.7 it is unreliable.
#' 
#' # Estimating Phylogenetic Trees
#' - https://github.com/haruosuz/r4bioinfo/tree/master/R_phangorn
#'   - Vignettes: [Estimating phylogenetic trees with phangorn](https://cran.r-project.org/web/packages/phangorn/vignettes/Trees.html)
#library(phangorn)
myphyDat <- read.phyDat(file=file_align, format="fasta", type="AA")
mymodel <- "JTT" # "WAG", "JTT", "LG", "Dayhoff", 
if(UPGMA_NJ == "UPGMA") myfun <- function(x) upgma(dist.ml(x, model=mymodel))
if(UPGMA_NJ == "NJ") myfun <- function(x) NJ(dist.ml(x, model=mymodel))
mytree <- myfun(myphyDat)
set.seed(123)
mytrees_bs <- bootstrap.phyDat(myphyDat, FUN=myfun, bs=100, multicore=TRUE)
pdf("myTree.pdf", pointsize=10, width=15, height=9)
mycex <- 0.95 # Graphical Parameters
par(mfrow=c(1,1), mgp=c(1.7, 0.5, 0), mar=c(1.3, 0.5, 1, 5), cex=mycex) # c(bottom, left, top, right)
mytree <- plotBS(type="phylogram", tree=mytree, BStrees=mytrees_bs, underscore=TRUE) # further parameters used by `plot.phylo`.
dev.off()
if(UPGMA_NJ == "NJ") mytree <- phangorn::midpoint(mytree)
#if(UPGMA_NJ == "NJ") mytree <- phytools::midpoint.root(mytree)
mytree <- ladderize(mytree, right=TRUE)
mytree$tip.label <- gsub(pattern="^(UniRef[0-9]+_)*([^ ]+) .+", replacement="\\2", x=mytree$tip.label)
#mytree$tip.label <- sapply(mytree$tip.label, function(x) paste(d.f[grepl(pattern=x, x=d.f[,"Accession"]),c("Accession","ProteinName","OrganismName")],collapse="~") )
par(mfrow=c(1,1), mgp=c(1.7, 0.5, 0), mar=c(1.3, 0.5, 1, 5), cex=mycex) # c(bottom, left, top, right)
plot.phylo(x=mytree, show.node.label=TRUE, main=paste0(UPGMA_NJ," tree"), underscore=TRUE); axisPhylo(); ape::add.scale.bar()

# Table sorted by tree $tip.label
mytree$tip.label <- sapply(mytree$tip.label, function(x) d.f[grepl(pattern=x, x=d.f[,"Accession"]),"Accession"] )
# write.tree / read.tree
write.tree(phy = mytree, file = "myTree.tre")
mytree <- read.tree(file = "myTree.tre")
#plot.phylo(mytree, type="phylogram") #tiplabels(); #nodelabels(); #edgelabels();
mylevels <- mytree$tip.label
fct.ordered <- factor(d.f$Accession, levels=mylevels, ordered=TRUE)
#sort(fct.ordered)
d.f <- d.f[order(fct.ordered, decreasing=TRUE), ]
write_tsv(x=d.f, file="myTable.tsv")

#' **Figure. Evolutionary relationships of some organisms' proteins.**  
#' Phylogenetic tree involving `print(nchar(msa.trimmed$Sequence))` sites in the alignment of amino acid sequences of `length(seqs)` proteins.
#' The analyses were implemented in `R.version.string`.  
#' Multiple sequence alignments of amino acid sequences were performed using the "DECIPHER" package (version `packageVersion("DECIPHER")`) (http://www2.decipher.codes/Citation.html).  
#' All positions containing gaps were eliminated using the "microseq" package (version `packageVersion("microseq")`) (https://cran.r-project.org/package=microseq).  
#' Sequence logos were drawn using the "ggseqlogo" package (version `packageVersion("ggseqlogo")`) (https://cran.r-project.org/package=ggseqlogo).  
#' The phylogenetic tree was estimated from the aligned sequences using the distance-based method 
#' [UPGMA (unweighted pair group method with arithmetic mean) or Neighbor Joining (NJ)] 
#' with the amino acid substitution model `mymodel`, and bootstrap percentages at nodes were calculated with 100 replicates, 
#' using the "phangorn" package (version `packageVersion("phangorn")`) (https://cran.r-project.org/package=phangorn).  
#' The tree is drawn to scale, with branch lengths measured in the number of substitutions per site (indicated by horizontal scale bars).  
#' Use `sessionInfo()` to print version information about R and packages.

#getwd()
#list.files()
sessionInfo()
Sys.time()

#' # References
#' 
#' - http://togows.dbcls.jp/site/en/rest.html
#' TogoWS REST service
#' - 
#' - https://ja.wikipedia.org/wiki/EF-Tu
#' - https://ja.wikipedia.org/wiki/EF-G
#' - https://en.wikipedia.org/wiki/Elongation_factor
#'   - https://en.wikipedia.org/wiki/EEF-1
#'     - https://en.wikipedia.org/wiki/Eukaryotic_translation_elongation_factor_1_alpha_1
#'   - https://en.wikipedia.org/wiki/EEF2
#' - https://www.brh.co.jp/research/formerlab/miyata/2005/post_000008.php
#' 【生物最古の枝分かれ：問題点と重複遺伝子による解決】 | JT生命誌研究館
#'  | 遺伝子重複 | ポリペプチド伸長因子（EF-1a/Tu）（EF-2/G）
#'  | 図3．重複遺伝子EF-Tu/1aとEF-G/2に基づく超生物界の複合系統樹
#' - 
#' - 2010.4. 動物の系統分類と進化（藤田敏彦 著）
#'   - https://www.shokabo.co.jp/mybooks/ISBN978-4-7853-5842-6.htm
#'   - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/188bto4/alma9926405490104034
#' Maruzen eBook Library
#'  | p.65-66 | 遺伝子重複(gene duplication)
#'  | ヘモグロビン α 鎖と β 鎖は，ヒト，ウマ，チンパンジーが共有
#'  | パラローガス(paralogous) | オーソローガス(orthologous)
