#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#over-represented-and-under-represented-dna-words
#' 
#' # Oligonucleotide (k-mer) frequences
#' 2連続塩基・ジヌクレオチド (2-mer) "aa" "ac" "ag" "at" "ca" "cc" "cg" "ct" "ga" "gc" "gg" "gt" "ta" "tc" "tg" "tt" の相対量を計算:  
#' Calculate relative abundances of dinucleotides (2-mer): "aa" "ac" "ag" "at" "ca" "cc" "cg" "ct" "ga" "gc" "gg" "gt" "ta" "tc" "tg" "tt":  

# seqinr パッケージを R に読み込む
# Load the seqinr package into R
library("seqinr")

# DNA配列のテストデータを作成する（`seqinr`パッケージの`s2c`関数は文字列を文字ベクトルに変換する）
# Create test data for a DNA sequence (convert a single string into a vector of characters using the `s2c` function of the `seqinr` package)
myseq <- s2c("acgtt")

# Rオブジェクト（文字ベクトル）の内容を表示する
# Print out the content of the R object (a vector of characters)
myseq

#' ## `count` function
#' 
#' 2連続塩基・ジヌクレオチド (2-mer) "cg" の相対量を計算:  
#' Get the relative abundance of the dinucleotide (2-mer) "cg":

# 各塩基 "a" "t" "g" "c" の絶対度数を計算:  
# Get absolute frequencies of 4 mononucleotides (1-mer):  
count(myseq, 1) 

# 塩基 "c" の相対度数を計算:  
# Get the relative frequency of the 1-mer "c":  
1/(1+1+1+2)

# 塩基 "g" の相対度数を計算:  
# Get the relative frequency of the 1-mer "g":  
1/(1+1+1+2)

# 2連続塩基 (4^2=) 16種類の絶対度数を計算:  
# Get absolute frequencies of 16 dinucleotides (2-mer):  
count(myseq, 2) 

# 2連続塩基 "cg" の相対度数を計算:  
# Get the relative frequency of the 2-mer "cg":  
1/(0+1+0+0+0+0+1+0+0+0+0+1+0+0+0+1)

# 2連続塩基 "cg" のρ値（観測値/期待値）を計算:  
# Calculate the rho statistic, which is defined as the ratio of observed to expected frequency, for the 2-mer "cg":  
0.25/(0.2*0.2)

#' ## `apply` function
#' 2連続塩基 (4^2=) 16種類のρ値を計算:  
#' Calculate the rho statistic of 16 dinucleotides (2-mer):  
( af1 <- count(myseq, wordsize = 1) ) # absolute frequencies of 1-mer
( rf1 <- af1 / sum(af1) )             # relative frequencies of 1-mer
( af2 <- count(myseq, wordsize = 2) ) # absolute frequencies of 2-mer
( rf2 <- af2 / sum(af2) )             # relative frequencies of 2-mer
( oe.2 <- rf2 / apply(expand.grid(rf1, rf1), 1, prod) ) # observed / expected

#' ## `rho` function
#' `rho`関数を用いて、2連続塩基 (4^2=) 16種類のρ値を計算:  
#' Using the `rho` function to compute on each of the 16 dinucleotides:  
rho(sequence = myseq, wordsize = 2)
