#' # assignment
#' ## [ドットプロットで2つの配列を比較](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#comparing-two-sequences-using-a-dotplot)
#' ## [Comparing two sequences using a dotplot](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#comparing-two-sequences-using-a-dotplot)

rm(list = ls()) # Clear R's environment
library(seqinr) # Loading the "seqinr" package 

#' Answer the following questions. 
#' For each question, please record your answer, and what you typed to get this answer.
#' 
#' ### Q1. 
#' Download FASTA-format files of two protein sequences from databases.

# Generate URLs to access NCBI protein data.
accession1 <- "NP_001393" # elongation factor [Homo sapiens]
accession2 <- "WP_011012522" # elongation factor [Pyrococcus furiosus]
url1 <- paste0("http://togows.dbcls.jp/entry/protein/",accession1,".fasta")
url2 <- paste0("http://togows.dbcls.jp/entry/protein/",accession2,".fasta")

# Generate URLs to access UniProt data.
accession1 <- "Q9CD83" # Chorismate pyruvate-lyase OS=Mycobacterium leprae
accession2 <- "A0PQ23" # Chorismate pyruvate-lyase OS=Mycobacterium ulcerans
url1 <- paste0("http://www.uniprot.org/uniprot/",accession1,".fasta")
url2 <- paste0("http://www.uniprot.org/uniprot/",accession2,".fasta")

# read FASTA formatted files
chars1 <- read.fasta(file=url1, seqtype="AA", strip.desc=TRUE)[[1]]
chars2 <- read.fasta(file=url2, seqtype="AA", strip.desc=TRUE)[[1]]

# Write sequence(s) into a file in fasta format
#write.fasta(sequences=chars1, names=getAnnot(chars1), file.out=paste0("./",accession1,".fasta") )
#write.fasta(sequences=chars2, names=getAnnot(chars2), file.out=paste0("./",accession2,".fasta") )

# get sequence length and annotation
length(chars1); getAnnot(chars1)
length(chars2); getAnnot(chars2)

#' ### Q2. 
#' Create a dotplot for two sequences.
#' In the dotplot, the 1st sequence is plotted along the x-axis (horizontal axis), 
#' and the 2nd sequence is plotted along the y-axis (vertical axis). 
#' The dotplot displays a dot at points where there is an identical amino acid in the two sequences.

par(mfrow=c(1,2))
dotPlot(seq1 = chars1, seq2 = chars2)

#' There are many dots along a diagonal line, indicating that the two protein 
#' sequences contain many identical amino acids at the same (or similar) positions along their lengths. 
#' This suggests that these two proteins are *homologues*, 
#' meaning they are related proteins derived from a common ancestor.
#' 
#' ### Q3. 
#' Create a self-similarity dot-plot. i.e. Compare the sequence against itself.
#' Sequences may contain regions of self-similarity (internal repeats).

par(mfrow=c(1,2))
dotPlot(chars1, chars1)
dotPlot(chars2, chars2)

# Print R version and packages
sessionInfo()
Sys.time()
