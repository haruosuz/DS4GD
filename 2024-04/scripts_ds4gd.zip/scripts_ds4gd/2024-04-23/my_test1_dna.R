#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#dna-sequence-statistics-1
#' 
library("seqinr") # Load the seqinr package into R
myseq <- s2c("acgt") # Create test data for a DNA sequence (convert a single string into a vector of characters)
myseq # Print out the content of the R object (a vector of characters)
length(myseq) # Determine the length of the DNA sequence (number of elements in the vector)
table(myseq) # Calculate the base composition of the DNA sequence (number of unique characters in the vector)
GC(myseq) # Calculate the GC content of the DNA sequence (G+C)/(A+C+G+T)
count(myseq, wordsize = 2) # Count dinucleotide (2-mer) frequencies in the sequence

