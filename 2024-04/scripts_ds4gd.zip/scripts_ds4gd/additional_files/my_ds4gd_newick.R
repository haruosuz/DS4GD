#' ---
#' title: "DS4GD_newick"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

rm(list = ls())
library(ape)
#?plot.phylo

#' # newick
#' - https://en.wikipedia.org/wiki/Newick_format
#?ape::read.tree
layout(matrix(1:4, 2, 2))

nwk <- "((A,B,C),D);"
my.tree <- read.tree(text=nwk); plot(my.tree, main=nwk)

nwk <- "((A:0.05,B:0.2,C:0.1):0.3,D:0.4);"
my.tree <- read.tree(text=nwk); plot(my.tree, main=nwk)
add.scale.bar()

nwk <- "((A:0.05,B:0.2,C:0.1)Ancestor:0.3,D:0.4)R;"
my.tree <- read.tree(text=nwk); plot(my.tree, main=nwk)
nodelabels(my.tree$node.label)
#names(my.tree)
#write.tree(my.tree)
#write.tree(my.tree, file="myNewick.tre")
#read.tree(file="myNewick.tre")

#' - http://tree.bio.ed.ac.uk/software/figtree/
#' 
#' # rotate
#' - https://yulab-smu.top/treedata-book/faq.html#branch-setting
#?ape::ladderize
layout(matrix(1:4, 2, 2))
nwk <- "(E, ((C, (A, B)), D));"
nwk <- "(Fishes, ((Lizards, (Chimps, Humans)), Frogs));"
my.tree <- read.tree(text=nwk); plot(my.tree, main="normal")
my.tree <- ladderize(my.tree, right=T); plot(my.tree, main="right-ladderized")
my.tree <- ladderize(my.tree, right=F); plot(my.tree, main="left-ladderized")
my.tree <- rotateConstr(my.tree, constraint=read.tree(text=nwk)$tip.label); plot(my.tree, main="rotateConstr")
write.tree(my.tree)

#' # root
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/188bto4/alma99275963904031
#' Welcome to the Microbiome
#' - https://www.brh.co.jp/research/formerlab/miyata/2005/post_000008.php
#?ape::root
layout(matrix(1:4, 2, 2))
nwk <- "(Eukarotes, Archaea, Bacteria);"
my.tree <- read.tree(text=nwk)
mytype <- "unrooted"; plot(my.tree, type=mytype, main=mytype)
out <- "Eukarotes"; my.tree <- root(my.tree, outgroup=out, r=TRUE); plot(my.tree, main=paste("outgroup:",out))
out <- "Archaea"; my.tree <- root(my.tree, outgroup=out, r=TRUE); plot(my.tree, main=paste("outgroup:",out))
out <- "Bacteria"; my.tree <- root(my.tree, outgroup=out, r=TRUE); plot(my.tree, main=paste("outgroup:",out))
#is.rooted(my.tree)

#' # monophyletic
#' - https://en.wikipedia.org/wiki/Monophyly
#' - https://en.wikipedia.org/wiki/Paraphyly
#' ![https://www.numerade.com/ask/question/the-phylogenetic-tree-below-shows-the-relationship-between-bacteria-archaea-and-eukaryotes-select-the-wrong-statement-about-the-tree-from-the-following-bacteria-prokaryotes-archaea-eukaryote-78113/](https://cdn.numerade.com/ask_images/da888612ab4943e3acffead35b71f637.jpg)
#ape::is.monophyletic(phy = my.tree, tips = c("Archaea", "Bacteria"))

# Print R version, OS and loaded packages.
sessionInfo()
Sys.time()
