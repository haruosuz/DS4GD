#' ---
#' title: "DS4GD_newick"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

rm(list = ls())
library(ape)
#?plot.phylo

#' # newick
#' - https://en.wikipedia.org/wiki/Newick_format
#?ape::read.tree
layout(matrix(1:4, 2, 2))

nwk <- "((A,B,C),D);"
mytree <- read.tree(text=nwk); plot(mytree, main=nwk)

nwk <- "((A:0.05,B:0.2,C:0.1):0.3,D:0.4);"
mytree <- read.tree(text=nwk); plot(mytree, main=nwk)
add.scale.bar()

nwk <- "((A:0.05,B:0.2,C:0.1)Ancestor:0.3,D:0.4)R;"
mytree <- read.tree(text=nwk); plot(mytree, main=nwk)
nodelabels(mytree$node.label)
#names(mytree)

#' # rotate
#' - https://yulab-smu.top/treedata-book/faq.html#branch-setting
#?ape::ladderize
layout(matrix(1:4, 2, 2))
nwk <- "(E, ((C, (A, B)), D));"
nwk <- "(Fishes, ((Lizards, (Chimps, Humans)), Frogs));"
mytree <- read.tree(text=nwk); plot(mytree, main="initial")
mytree <- ladderize(mytree, right=T); plot(mytree, main="right-ladderized")
mytree <- ladderize(mytree, right=F); plot(mytree, main="left-ladderized")
mytree <- rotateConstr(mytree, constraint=read.tree(text=nwk)$tip.label); plot(mytree, main="rotateConstr")
write.tree(mytree)
#write.tree(mytree, file="myNewick.tre")
#read.tree(file="myNewick.tre")
#' - https://doua.prabi.fr/software/seaview
#'   - macOS X https://doua.prabi.fr/software/seaview_data/seaview5.zip
#'   - MS Windows https://doua.prabi.fr/software/seaview_data/seaview5.exe
#' - http://tree.bio.ed.ac.uk/software/figtree/
#' Compiled binaries (for Mac, Windows and Linux) are available from the FigTree GitHub repository.
#' 
#' # root
#' - https://search.lib.keio.ac.jp/permalink/81SOKEI_KEIO/188bto4/alma99275963904031
#' Welcome to the Microbiome
#' - https://www.brh.co.jp/research/formerlab/miyata/2005/post_000008.php
#?ape::root
layout(matrix(1:4, 2, 2))
nwk <- "(Eukarotes, Archaea, Bacteria);"
mytree <- read.tree(text=nwk)
mytype <- "unrooted"; plot(mytree, type=mytype, main=mytype)
out <- "Eukarotes"; mytree <- root(mytree, outgroup=out, r=TRUE); plot(mytree, main=paste("outgroup:",out))
out <- "Archaea"; mytree <- root(mytree, outgroup=out, r=TRUE); plot(mytree, main=paste("outgroup:",out))
out <- "Bacteria"; mytree <- root(mytree, outgroup=out, r=TRUE); plot(mytree, main=paste("outgroup:",out))
#is.rooted(mytree)

#' # monophyletic
#' - https://en.wikipedia.org/wiki/Monophyly
#' - https://en.wikipedia.org/wiki/Paraphyly
#' ![https://www.numerade.com/ask/question/the-phylogenetic-tree-below-shows-the-relationship-between-bacteria-archaea-and-eukaryotes-select-the-wrong-statement-about-the-tree-from-the-following-bacteria-prokaryotes-archaea-eukaryote-78113/](https://cdn.numerade.com/ask_images/da888612ab4943e3acffead35b71f637.jpg)
#ape::is.monophyletic(phy = mytree, tips = c("Archaea", "Bacteria"))

# Print R version, OS and loaded packages.
sessionInfo()
Sys.time()
