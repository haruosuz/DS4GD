# Load the "SeqinR" R package
library(seqinr)
# Create test data of DNA sequences
s2c("tgca")
# Graphical Parameters
par(mfrow=c(2,3))
# Identity is on the main diagonal:
dotPlot(s2c("tgca"), s2c("tgca"))
# Insertion in the 2nd sequence yields a vertical jump:
dotPlot(s2c("tgca"), s2c("tgnca"))
# Insertion in the 1st sequence yields an horizontal jump:
dotPlot(s2c("tgnca"), s2c("tgca"))
# complementary strand:
dotPlot(s2c("tgca"), comp(s2c("tgca")))
# reverse complementary strand:
dotPlot(s2c("tgca"), rev(comp(s2c("tgca"))))
# Internal repeats are off the main diagonal:
dotPlot(rep(s2c("tgca"),2), rep(s2c("tgca"),2))
#' [回文配列](https://ja.wikipedia.org/wiki/回文配列)
#' [Palindromic sequence](https://en.wikipedia.org/wiki/Palindromic_sequence)
#' 
#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#comparing-two-sequences-using-a-dotplot
#' - https://www.jsbi.org/activity/nintei/sankou_mondai_kako/
#' バイオインフォマティクス技術者認定試験 参考問題・過去問題
#' 2019年度（平成31年度） 問題 解説
#'   - https://www.jsbi.org/media/files/activity/nintei/sankou_mondai_kako/2019_mondai.pdf
#' 問 44
#' ドットプロット

