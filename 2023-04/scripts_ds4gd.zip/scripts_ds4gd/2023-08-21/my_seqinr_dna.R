# Haruo Suzuki
# 2023-05-21
# This script is for DNA sequence analysis using the seqinR package

#' # DNA Sequence Statistics
#' ## [DNA配列の統計 (1)](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#dna-sequence-statistics-1)

rm(list = ls()) # Clear R's environment
library(seqinr) # Loading the "seqinr" package 

# Retrieving a DNA sequence from NCBI
ACCESSION <- "NC_045512" # Change the accession number
url <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text")
filename <- paste0(ACCESSION,".fna")
if(!file.exists(filename)) download.file(url = url, destfile = filename)
seqs <- read.fasta(file=filename)
seq1 <- seqs[[1]]
getAnnot(seq1) # get sequence annotations
#seq1 <- s2c("acgt") # create a test DNA sequence
length(seq1) # length of the DNA sequence
table(seq1)  # base composition
GC(seq1)     # GC content = (G+C)/(A+T+G+C)

#' # References
#' - https://github.com/haruosuz/r4bioinfo/tree/master/R_seqinR
#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md
#' - https://github.com/haruosuz/DS4GD/blob/master/2023-04/README.md
#' - https://github.com/haruosuz/DS4GD/blob/master/2018/CaseStudy.md#genome-signature

