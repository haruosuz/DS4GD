# Haruo Suzuki
# 2023-07-09
# This script is for setting up the environment, including package installation and data import into R

# Install R packages
options(repos="https://cran.ism.ac.jp/")
install.packages("seqinr")

# Load R packages
library(seqinr)

#' # References
#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#installing-r-packages
