# Get Current Date and Time
Sys.time()

#' - https://cran.r-project.org/mirrors.html
# URLs of the repositories for use by update.packages
options(repos="https://cran.ism.ac.jp/")

#' Rパッケージのインストール:  
# Installing the R packages:
install.packages("tidyverse")
install.packages("seqinr")
install.packages("zoo")
install.packages("ape")
install.packages("phangorn")
install.packages("phytools")
install.packages("ggseqlogo")
install.packages("microseq")

#' Bioconductorパッケージのインストール:  
# Installing the Bioconductor packages:
if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
#BiocManager::install("ggtree")
BiocManager::install("Biostrings")
BiocManager::install("msa")
BiocManager::install("DECIPHER")

#' ```
#' Update all/some/none? [a/s/n]:
#' n
#' ```
#' 
#' [Update all/some/none? [a/s/n]: と聞かれることもありますが基本はnでいいです。](http://www.iu.a.u-tokyo.ac.jp/~kadota/bioinfo_ngs_sokushu_2014/R_install.pdf)  
#' [At any point (especially if you’ve used R/Bioconductor in the past), 
#' R may ask you if you want to update any old packages by asking `Update all/some/none? [a/s/n]:`. 
#' If you see this, type](http://bioconnector.github.io/bims8382/setup-r.html)
#' `n`
#' 
#' Rパッケージのバージョンを確認:  
# Print the versions of these packages:
packageVersion("tidyverse")
packageVersion("seqinr")
packageVersion("zoo")
packageVersion("ape")
packageVersion("phangorn")
packageVersion("phytools")
packageVersion("ggseqlogo")
packageVersion("microseq")
#packageVersion("ggtree")
packageVersion("Biostrings")
packageVersion("msa")
packageVersion("DECIPHER")

#' Rパッケージの呼び出し:  
# Load the packages into R:
library(tidyverse)
library(seqinr)
library(zoo)
library(ape)
library(phangorn)
library(phytools)
library(ggseqlogo)
library(microseq)
#library(ggtree)
library(Biostrings)
library(msa)
library(DECIPHER)

#' Rのバージョンを確認:  
# Print detailed information about the version of R running.
R.version
R.version.string

# Print version information about R, the OS and attached or loaded packages.
sessionInfo()

