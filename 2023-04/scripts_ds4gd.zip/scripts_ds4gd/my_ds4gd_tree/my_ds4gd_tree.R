#' ---
#' title: "Inferring Phylogenetic Trees"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      theme: united
#'      highlight: tango
#'      toc: true
#' ---
#' 
# clear the decks
rm(list = ls())

# Load the required packages
#+ warning = FALSE
#+ message = FALSE
library(seqinr)
library(ape)
library(phangorn)
library(phytools)
library(microseq)
library(Biostrings)
library(DECIPHER)
library(ggseqlogo)
library(tidyverse)

#' # References
#' - https://www.datadreaming.org/post/r-markdown-theme-gallery/
#' - http://togows.dbcls.jp/site/en/rest.html
#' TogoWS REST service
#' - https://en.wikipedia.org/wiki/Elongation_factor
#'   - https://en.wikipedia.org/wiki/EEF-1
#'     - https://en.wikipedia.org/wiki/Eukaryotic_translation_elongation_factor_1_alpha_1
#'   - https://en.wikipedia.org/wiki/EEF2
#'   
#' # Acquiring the Sequences
#' - https://cran.r-project.org/package=seqinr
#' - https://seqinr.r-forge.r-project.org/
#library(seqinr)

database <- "ncbi_protein"
database <- "uniprot"
download <- TRUE
download <- FALSE

# Retrieve the sequences and store them in list variable "seqs"
if(download){
  if (database == "ncbi_protein") {
    ACCESSIONs <- c("NP_001393", "WP_011012522", "WP_001040724", "NP_001952", "WP_011013157", "NP_387993")
    # Create a function to retrieve several protein sequences from NCBI
    read.fasta.protein <- function(ACCESSION) seqinr::read.fasta(file = paste0("http://togows.dbcls.jp/entry/protein/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
    seqs <- lapply(ACCESSIONs, read.fasta.protein)
  } else if (database == "uniprot") {
    ACCESSIONs <- c("P68104", "Q8U152", "P33166", "P13639", "P61877", "P80868")
    # Create a function to retrieve several sequences from UniProt
    read.fasta.uniprot <- function(ACCESSION) seqinr::read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
    seqs <- lapply(ACCESSIONs, read.fasta.uniprot)
  }
  # Write sequence(s) in FASTA formatted files
  file.fasta <- "myAA.fasta" # FASTA file of amino acid (protein) sequences
  write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=file.fasta, nbchar=max(getLength(seqs)))
}

#' Read amino-acid sequences from a file in FASTA format.
#file.fasta <- "data/my_ncbi_protein.fasta" # NCBI Protein
#file.fasta <- "data/my_uniprot.fasta" # UniProt
file.fasta <- "myAA.fasta" # Replace this FASTA file with your own data.
seqs <- read.fasta(file=file.fasta, seqtype="AA", strip.desc=TRUE)

# Get sequence length and annotations
Length <- getLength(seqs) # get the length of sequences
Annotation <- unlist(getAnnot(seqs)) # get sequence annotations

# Pattern Matching and Replacement
if (database == "ncbi_protein") {
  Accession <- gsub(pattern="^([^ ]+) .+", replacement="\\1", x=Annotation)
  ProteinName <- gsub(pattern="^([^ ]+)\\.[0-9]+ (.+) \\[(.+)\\]", replacement="\\2", x=Annotation)
  OrganismName <- gsub(pattern=".+\\[(.+)\\]", replacement="\\1", x=Annotation)
} else if (database == "uniprot") {
  Accession <- gsub(pattern="^(sp|tr)\\|([^ ]+)\\|.+", replacement="\\2", x=Annotation)
  ProteinName <- gsub(pattern="^([^ ]+) (.+) OS=.+", replacement="\\2", x=Annotation)
  OrganismName <- gsub(pattern=".+ OS=(.+) OX=.+", replacement="\\1", x=Annotation)
}

# Creates data frame (table)
d.f <- data.frame(Length, Accession, ProteinName, OrganismName, Annotation) %>% arrange(desc(`Length`))
knitr::kable(x = d.f, caption = "Table 1. Sequence data.")

# Histograms
hist(d.f$Length)

#' # Aligning the Sequences
#' 
#' - https://github.com/haruosuz/r4bioinfo/tree/master/R_DECIPHER
#'   - Vignettes: [The Art of Multiple Sequence Alignment in R](https://bioconductor.org/packages/release/bioc/vignettes/DECIPHER/inst/doc/ArtOfAlignmentInR.pdf)
#library(DECIPHER)
myAAStringSet <- Biostrings::readAAStringSet(filepath=file.fasta)
myAlignAA <- DECIPHER::AlignSeqs(myAAStringSet)
#myAlignAA <- subseq(myAlignAA, start=73, end=162)
myAlignAA
#DECIPHER::BrowseSeqs(myAlignAA, threshold = 0.5) # ?ConsensusSequence

# write an XStringSet object to a file
file.align.untrimmed <- "myAlign.fasta"
Biostrings::writeXStringSet(x=myAlignAA, filepath=file.align.untrimmed)

#' ## Trimming multiple sequence alignments
#' - https://cran.r-project.org/package=microseq
#library(microseq)
msa.untrimmed <- microseq::readFasta(in.file = file.align.untrimmed)
print(nchar(msa.untrimmed$Sequence))
msa.trimmed <- microseq::msaTrim(msa = msa.untrimmed, gap.end = 0, gap.mid = 0)
print(nchar(msa.trimmed$Sequence))
file.align.trimmed <- "myAlignTrim.fasta"
microseq::writeFasta(fdta = msa.trimmed, out.file = file.align.trimmed, width = 80)

file_align <- file.align.untrimmed
#file_align <- file.align.trimmed

#' ## Sequence Logos
#' - https://cran.r-project.org/package=ggseqlogo
#'   - Vignettes: https://omarwagih.github.io/ggseqlogo/
#require(ggplot2)
#require(ggseqlogo)
#?geom_logo
# read the FASTA-format alignment into R
myAln <- seqinr::read.alignment(file=file_align, format="fasta")
unlist(myAln$seq)
mydata <- toupper(myAln$seq)
#mydata <- as.character(myAlignAA) # untrimmed ?
mydata <- substr(x=mydata, start=20, stop=40)
#ggseqlogo(data=mydata, seq_type='aa', method='prob')
ggseqlogo(data=mydata, seq_type='aa', method='bits')

#' ## Check Average Identity to Estimate Reliability of the Alignment
# squared root of pairwise distances from aligned sequences
mydist <- seqinr::dist.alignment(x=myAln, matrix="identity")
#max(mydist ^ 2)
mean(mydist ^ 2)
#' - [Phylogenetic Trees Made Easy: A How-To Manual (5th edition)](https://github.com/haruosuz/DS4GD/blob/master/2021/CaseStudy.md#ptme5)
#' (p.60) *Codons: Pairwise amino acid identity* | 
#' The p-distance is 1–amino acid identity; thus 
#' if the average p-distance is <0.7 the alignment is acceptable; 
#' if ≥0.7 it is unreliable.
#' 
#' # Estimating Phylogenetic Trees
#' - https://github.com/haruosuz/r4bioinfo/tree/master/R_phangorn
#'   - Vignettes: [Estimating phylogenetic trees with phangorn](https://cran.r-project.org/web/packages/phangorn/vignettes/Trees.html)
#library(phangorn)
myphyDat <- read.phyDat(file=file_align, format="fasta", type="AA")
mymodel <- "JTT" # "WAG", "JTT", "LG", "Dayhoff", 
dm  <- dist.ml(myphyDat, model=mymodel)
treeUPGMA  <- upgma(dm)
treeNJ  <- NJ(dm)

set.seed(123)
bs_upgma <- bootstrap.phyDat(myphyDat, FUN=function(x) upgma(dist.ml(x, model=mymodel)), bs=100, multicore=TRUE)
bs_NJ <- bootstrap.phyDat(myphyDat, FUN=function(x) NJ(dist.ml(x, model=mymodel)), bs=100, multicore=TRUE)

par(mfrow=c(1,1), mgp=c(1.7, 0.5, 0), mar=c(1, 0.5, 1, 5), cex=0.75) # c(bottom, left, top, right)
#?phangorn::plotBS #p=0 # only plot support values higher than this percentage number (default is 0).
#?ape::plot.phylo #underscore=TRUE
treeBS <- plotBS(underscore=TRUE, type="phylogram", tree=treeUPGMA, BStrees=bs_upgma, main="UPGMA tree"); ape::add.scale.bar()
#treeBS <- plotBS(underscore=TRUE, type="phylogram", tree=treeNJ, BStrees=bs_NJ, main="NJ tree"); ape::add.scale.bar()
#treeBS  <- phangorn::midpoint(treeBS)
#treeBS  <- phytools::midpoint.root(treeBS)
treeBS <- ladderize(treeBS, right=FALSE)

treeBS$tip.label <- gsub(pattern="^([^ ]+) .+", replacement="\\1", x=treeBS$tip.label)
#treeBS$tip.label <- sapply(treeBS$tip.label, function(x) paste(d.f[grepl(pattern=x, x=d.f[,"Accession"]),c("Accession","ProteinName","OrganismName")],collapse="~") )
plot.phylo(treeBS, show.node.label=TRUE, main="Phylogenetic tree", underscore=TRUE); ape::add.scale.bar()

#' Table sorted by tree $tip.label
treeBS$tip.label <- sapply(treeBS$tip.label, function(x) d.f[grepl(pattern=x, x=d.f[,"Accession"]),"Accession"] )
# write.tree / read.tree
write.tree(phy = treeBS, file = "myTree.tre")
mytree <- read.tree(file = "myTree.tre")
#plot.phylo(mytree, type="phylogram") #tiplabels(); #nodelabels(); #edgelabels();
mylevels <- mytree$tip.label
fct.ordered <- factor(d.f$Accession, levels=mylevels, ordered=TRUE)
#sort(fct.ordered)
d.f <- d.f[order(fct.ordered, decreasing=TRUE), ]
write_tsv(x=d.f, file="myTable.tsv")

#getwd()
#list.files()
sessionInfo()
Sys.time()
