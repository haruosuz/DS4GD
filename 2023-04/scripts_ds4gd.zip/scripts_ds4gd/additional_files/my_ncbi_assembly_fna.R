#+ echo = TRUE
rm(list = ls())
#+ message = FALSE
library(seqinr)

# Dengue virus

#' Severe acute respiratory syndrome coronavirus 2
#' - https://www.ncbi.nlm.nih.gov/assembly/GCA_009858895.3
#' Organism name: Severe acute respiratory syndrome coronavirus 2 (viruses)
#' FTP directory for GenBank assembly
#' 
#' Ideonella sakaiensis
#' - https://www.ncbi.nlm.nih.gov/genome/browse/#!/prokaryotes/Ideonella%20sakaiensis
#' - https://www.ncbi.nlm.nih.gov/assembly/GCA_001293525.1
#' FTP directory for GenBank assembly
#' - https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/001/293/525/GCA_001293525.1_ASM129352v1/
#' 
# Download File from the Internet
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/001/293/525/GCA_001293525.1_ASM129352v1/GCA_001293525.1_ASM129352v1_genomic.fna.gz"
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)
#if(!file.exists(filename)){ download.file(url = url, destfile = filename); untar(tarfile = filename, exdir = "APER2_Online_Material") }

seqs <- read.fasta(file=filename, seqtype="DNA", strip.desc=TRUE)
length(seqs)
seq1 <- seqs[[1]]
getAnnot(seq1) # Get sequence annotations

#' # References
#' 
#' - https://github.com/haruosuz/introBI/blob/master/2020/CaseStudy.md#ncbi-genome-list
#' 
#' - https://github.com/haruosuz/DS4GD/tree/master/2023-04
#' - https://github.com/haruosuz/DS4GD/blob/master/2021/CaseStudy.md#ncbi-genome-list
#' - https://github.com/haruosuz/DS4GD/blob/master/2019giga/CaseStudy.md#ncbi-assembly_reports
#' 
#' - https://www.ncbi.nlm.nih.gov/genome/doc/ftpfaq/
#' Genomes Download FAQ
#' 
#' 

#getwd()
#list.files()
#sessionInfo()
#Sys.time()

