#' - https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#comparing-two-sequences-using-a-dotplot

# Loading Package "seqinr"
library(seqinr)
# Create tests
s2c("tgca")
# Identity is on the main diagonal:
dotPlot(s2c("tgca"), s2c("tgca"))
# Gap in the 2nd sequence yields a vertical jump:
dotPlot(s2c("tgca"), s2c("tg-ca"))
# Gap in the 1st sequence yields an horizontal jump:
dotPlot(s2c("tg-ca"), s2c("tgca"))

